(function () {
    'use strict';

    angular.module('ariaNg').config(['$routeProvider', function ($routeProvider) {
        $routeProvider
            .when('/downloading', {
                templateUrl: 'views/list.html',
                controller: 'DownloadListController'
            })
            .when('/waiting', {
                templateUrl: 'views/list.html',
                controller: 'DownloadListController'
            })
            .when('/stopped', {
                templateUrl: 'views/list.html',
                controller: 'DownloadListController'
            })
            .when('/new', {
                templateUrl: 'views/new.html',
                controller: 'NewTaskController'
            })
            .when('/new/:url', {
                template: '',
                controller: 'CommandController'
            })
            .when('/task/detail/:gid', {
                templateUrl: 'views/task-detail.html',
                controller: 'TaskDetailController'
            })
            .otherwise({
                redirectTo: '/downloading'
            });
    }]);
}());
