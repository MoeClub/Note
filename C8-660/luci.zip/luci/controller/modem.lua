module("luci.controller.modem", package.seeall)

function index()
	entry({"admin", "modem"}, firstchild(), _("蜂窝"), 25).dependent=false
	entry({"admin", "modem", "status"}, template("modem/status"), _("信号状态"), 97)
	entry({"admin", "modem", "at"}, template("modem/at"), _("调试工具"), 98)
	entry({"admin", "modem", "modem"}, cbi("modem"), _("模块设置"), 99) 
	entry({"admin", "modem", "get_status"}, call("action_status"))
	entry({"admin", "modem", "send_at"}, call("action_at"))
end

function action_at()
	local ret ={}
	local at = luci.http.formvalue("at")
	ret["at"] = string.gsub(at, "\"", "\\\"")

	local handle=io.popen("/bin/sendat 2 \"" .. ret["at"] .. "\"")
	ret["result"] = handle:read("*a")
	handle:close()

	luci.http.prepare_content("application/json")
	luci.http.write_json(ret)
end

function action_status()
	local handle=io.popen("/bin/sh /usr/libexec/modemStatus.sh")
	ret = handle:read("*a")
	handle:close()

	luci.http.prepare_content("application/json")
	luci.http.write(ret)
end