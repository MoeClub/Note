module("luci.controller.modem", package.seeall)

function index()
	entry({"admin", "modem"}, firstchild(), _("蜂窝"), 25).dependent=false
	entry({"admin", "modem", "status"}, template("modem/Status"), _("信号状态"), 95)
	entry({"admin", "modem", "sms_read"}, template("modem/SMSRead"), _("查看短信"), 96)
	entry({"admin", "modem", "sms_send"}, template("modem/SMSSend"), _("发送短信"), 97)
	entry({"admin", "modem", "at"}, template("modem/AT"), _("调试工具"), 98)
	entry({"admin", "modem", "modem"}, cbi("modem"), _("模块设置"), 99) 
	entry({"admin", "modem", "get_status"}, call("action_status"))
	entry({"admin", "modem", "send_at"}, call("action_at"))
	entry({"admin", "modem", "action_sms_read"}, call("action_sms_read"))
	entry({"admin", "modem", "action_sms_del"}, call("action_sms_del"))
	entry({"admin", "modem", "action_sms_send"}, call("action_sms_send"))
end

function action_at()
	local ret ={}
	local at = luci.http.formvalue("at")
	ret["at"] = string.gsub(at, "\"", "\\\"")

	local handle=io.popen("/bin/sendat 2 \"" .. ret["at"] .. "\" 2>/dev/null")
	ret["result"] = handle:read("*a")
	handle:close()

	luci.http.prepare_content("application/json")
	luci.http.write_json(ret)
end

function action_status()
	local handle=io.popen("/bin/sh /usr/libexec/modemStatus.sh 2>/dev/null")
	ret = handle:read("*a")
	handle:close()

	luci.http.prepare_content("application/json")
	luci.http.write(ret)
end

function action_sms_read()
	local handle=io.popen("/bin/sms_tool -f '%Y/%m/%d %H:%M:%S' -j recv 2>/dev/null")
	ret = handle:read("*a")
	handle:close()
	
	luci.http.prepare_content("application/json")
	luci.http.write(ret)
end

function action_sms_del()
	local handle=io.popen("/bin/sms_tool delete all 2>/dev/null")
	ret = handle:read("*a")
	handle:close()
	
	ret = "{}"
	luci.http.prepare_content("application/json")
	luci.http.write(ret)
end

function action_sms_send()
    local ret = luci.http.formvalue()
	local number = luci.http.urldecode(ret["number"])
	local text = luci.http.urldecode(ret["text"])
	
	local result = {}
    local handle=io.popen("/bin/sms_tool send \"" .. number .. "\" \"" .. text .. "\" 2>&1")
	result["status"] = handle:read("*a")
	handle:close()
	
	luci.http.prepare_content("application/json")
	luci.http.write_json(result)
end
