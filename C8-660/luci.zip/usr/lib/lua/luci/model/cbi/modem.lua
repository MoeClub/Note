local modem, section, simIndex, pinCode, cellMode, bandLTE, bandNR5G, staticPCI, lockPCINR5G, customIMEI

modem = Map("modem", translate("移动网络"))
section = modem:section(TypedSection, "network", translate("蜂窝设置"))
section.anonymous = true
section.addremove = false
	section:tab("general", translate("常规设置"))
	section:tab("advanced", translate("高级设置"))

SIMCard = section:taboption("general", ListValue, "SIMCard", translate("SIM卡槽"))
SIMCard:value("0", translate("内置eSIM"))
SIMCard:value("1", translate("外置SIM卡"))
SIMCard.rmempty = false

PINCode = section:taboption("general", Value, "PINCode", translate("PIN密码"))
PINCode.validate = function(self, value)
    if not value:match("^%d%d%d%d$") then
        return nil, translate("Invalid PIN Code")
    end
    return value
end

BarkURL = section:taboption("general", Value, "BarkURL", translate("Bark推送短信"))

CustomIMEI = section:taboption("general", Value, "CustomIMEI", translate("自定义IMEI"))
CustomIMEI.validate = function(self, value)
    if not value:match("^%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d$") then
        return nil, translate("Invalid IMEI")
    end
    return value
end

CellMode = section:taboption("advanced", ListValue, "CellMode", translate("网络制式"))
CellMode.default = "NR5G:LTE:WCDMA"
CellMode:value("NR5G:LTE:WCDMA", translate("5G优先"))
CellMode:value("LTE:NR5G:WCDMA", translate("4G优先"))
CellMode:value("NR5G", translate("5G网络"))
CellMode:value("LTE", translate("4G网络"))
CellMode:value("WCDMA", translate("3G网络"))

BandLTE = section:taboption("advanced", ListValue, "BandLTE", translate("LTE频段"))
BandLTE.default = ""
BandLTE:value("", translate("自动"))
BandLTE:value("1", translate("BAND 1"))
BandLTE:value("3", translate("BAND 3"))
BandLTE:value("5", translate("BAND 5"))
BandLTE:value("8", translate("BAND 8"))
BandLTE:value("34", translate("BAND 34"))
BandLTE:value("38", translate("BAND 38"))
BandLTE:value("39", translate("BAND 39"))
BandLTE:value("40", translate("BAND 40"))
BandLTE:value("41", translate("BAND 41"))
BandLTE:depends("CellMode", "LTE")

BandNR5G = section:taboption("advanced", ListValue, "BandNR5G", translate("NR5G频段"))
BandNR5G.default = ""
BandNR5G:value("", translate("自动"))
BandNR5G:value("1", translate("BAND 1"))
BandNR5G:value("3", translate("BAND 3"))
BandNR5G:value("8", translate("BAND 8"))
BandNR5G:value("28", translate("BAND 28"))
BandNR5G:value("41", translate("BAND 41"))
BandNR5G:value("78", translate("BAND 78"))
BandNR5G:value("79", translate("BAND 79"))
BandNR5G:depends("CellMode", "NR5G")

StaticPCI = section:taboption("advanced", ListValue, "StaticPCI", translate("静态小区"))
StaticPCI:value("0", translate("关闭"))
StaticPCI:value("1", translate("打开"))
StaticPCI:depends("CellMode", "NR5G")

LockPCINR5G = section:taboption("advanced", Value, "LockPCINR5G", translate("锁定小区"))
LockPCINR5G:depends("StaticPCI", "1")
LockPCINR5G.validate = function(self, value)
    if not value:match("^%d+,%d+,%d+,%d+$") then
        return nil, translate("<PCI>,<RFCN>,<BAND>,<SCS>")
    end
    return value
end


local apply = luci.http.formvalue("cbi.apply")
if apply then
  luci.sys.exec("/bin/sh /usr/libexec/modemApply.sh 7 >/dev/null 2>&1 &")
end

return modem
