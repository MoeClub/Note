<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pt_BR">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../gui/aboutdialog.ui" line="15"/>
        <source>About qBittorrent</source>
        <translation>Sobre o qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="52"/>
        <source>About</source>
        <translation>Sobre</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="81"/>
        <source>Authors</source>
        <translation>Autores</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="87"/>
        <source>Current maintainer</source>
        <translation>Responsável atual</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="93"/>
        <source>Greece</source>
        <translation>Grécia</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="113"/>
        <location filename="../gui/aboutdialog.ui" line="204"/>
        <source>Nationality:</source>
        <translation>Nacionalidade:</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="120"/>
        <location filename="../gui/aboutdialog.ui" line="197"/>
        <source>E-mail:</source>
        <translation>E-mail:</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="127"/>
        <location filename="../gui/aboutdialog.ui" line="190"/>
        <source>Name:</source>
        <translation>Nome:</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="157"/>
        <source>Original author</source>
        <translation>Autor original</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="163"/>
        <source>France</source>
        <translation>França</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="241"/>
        <source>Special Thanks</source>
        <translation>Agradecimentos Especiais</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="267"/>
        <source>Translators</source>
        <translation>Tradutores</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="296"/>
        <source>License</source>
        <translation>Licença</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="322"/>
        <source>Software Used</source>
        <translation>Softwares Usados</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="328"/>
        <source>qBittorrent was built with the following libraries:</source>
        <translation>O qBittorrent foi construído com as seguintes bibliotecas:</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.cpp" line="68"/>
        <source>An advanced BitTorrent client programmed in C++, based on Qt toolkit and libtorrent-rasterbar.</source>
        <translation>Um cliente BitTorrent avançado programado em C++, baseado no Qt toolkit e libtorrent-rasterbar.</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.cpp" line="70"/>
        <source>Copyright %1 2006-2022 The qBittorrent project</source>
        <translation>Copyright %1 2006-2022 O Projeto do qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.cpp" line="71"/>
        <source>Home Page:</source>
        <translation>Home Page:</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.cpp" line="72"/>
        <source>Forum:</source>
        <translation>Fórum:</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.cpp" line="73"/>
        <source>Bug Tracker:</source>
        <translation>Rastreador de Bugs:</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.cpp" line="112"/>
        <source>The free IP to Country Lite database by DB-IP is used for resolving the countries of peers. The database is licensed under the Creative Commons Attribution 4.0 International License</source>
        <translation>O banco de dados grátis do IP to Country Lite da DB-IP é usado pra revelar os países dos peers. O banco de dados está licenciado sob a Licença Internacional da Creative Commons Attribution 4.0</translation>
    </message>
</context>
<context>
    <name>AbstractFileStorage</name>
    <message>
        <location filename="../base/bittorrent/abstractfilestorage.cpp" line="42"/>
        <location filename="../base/bittorrent/abstractfilestorage.cpp" line="68"/>
        <source>The old path is invalid: &apos;%1&apos;.</source>
        <translation>O caminho antigo é inválido: &quot;%1&quot;.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/abstractfilestorage.cpp" line="44"/>
        <location filename="../base/bittorrent/abstractfilestorage.cpp" line="70"/>
        <source>The new path is invalid: &apos;%1&apos;.</source>
        <translation>O novo caminho é inválido: &quot;%1&quot;.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/abstractfilestorage.cpp" line="46"/>
        <location filename="../base/bittorrent/abstractfilestorage.cpp" line="72"/>
        <source>Absolute path isn&apos;t allowed: &apos;%1&apos;.</source>
        <translation>O caminho absoluto não é permitido: &quot;%1&quot;.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/abstractfilestorage.cpp" line="56"/>
        <source>The file already exists: &apos;%1&apos;.</source>
        <translation>O arquivo já existe: &quot;%1&quot;.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/abstractfilestorage.cpp" line="60"/>
        <source>No such file: &apos;%1&apos;.</source>
        <translation>Não há tal arquivo: &quot;%1&quot;.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/abstractfilestorage.cpp" line="84"/>
        <source>The folder already exists: &apos;%1&apos;.</source>
        <translation>A pasta já existe: &quot;%1&quot;.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/abstractfilestorage.cpp" line="88"/>
        <source>No such folder: &apos;%1&apos;.</source>
        <translation>Não há tal pasta: &quot;%1&quot;.</translation>
    </message>
</context>
<context>
    <name>AddNewTorrentDialog</name>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="80"/>
        <source>Save at</source>
        <translation>Salvar em</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="456"/>
        <source>Never show again</source>
        <translation>Nunca mostrar de novo</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="134"/>
        <source>Torrent settings</source>
        <translation>Configurações do torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="167"/>
        <source>Set as default category</source>
        <translation>Definir como categoria padrão</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="142"/>
        <source>Category:</source>
        <translation>Categoria:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="207"/>
        <source>Start torrent</source>
        <translation>Iniciar torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="284"/>
        <source>Torrent information</source>
        <translation>Informações do torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="193"/>
        <source>Skip hash check</source>
        <translation>Ignorar verificação do hash</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="89"/>
        <source>Use another path for incomplete torrent</source>
        <translation>Usar outro caminho pro torrent incompleto</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="176"/>
        <source>When checked, the .torrent file will not be deleted regardless of the settings at the &quot;Download&quot; page of the Options dialog</source>
        <translation>Quando selecionado, o arquivo .torrent não será apagado independente das configurações na página &quot;Download&quot; do diálogo das Opções</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="231"/>
        <source>Content layout:</source>
        <translation>Layout do conteúdo:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="242"/>
        <source>Original</source>
        <translation>Original</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="247"/>
        <source>Create subfolder</source>
        <translation>Criar sub-pasta</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="252"/>
        <source>Don&apos;t create subfolder</source>
        <translation>Não criar sub-pasta</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="290"/>
        <source>Info hash v1:</source>
        <translation>Informações do hash v1:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="358"/>
        <source>Size:</source>
        <translation>Tamanho:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="348"/>
        <source>Comment:</source>
        <translation>Comentário:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="372"/>
        <source>Date:</source>
        <translation>Data:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="41"/>
        <source>Torrent Management Mode:</source>
        <translation>Modo de gerenciamento dos torrents:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="48"/>
        <source>Automatic mode means that various torrent properties(eg save path) will be decided by the associated category</source>
        <translation>O modo automático significa que várias propriedades do torrent (ex: o caminho do salvamento) serão decididas pela categoria associada</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="52"/>
        <source>Manual</source>
        <translation>Manual</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="57"/>
        <source>Automatic</source>
        <translation>Automático</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="122"/>
        <source>Remember last used save path</source>
        <translation>Lembrar o último caminho de salvamento usado</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="179"/>
        <source>Do not delete .torrent file</source>
        <translation>Não apagar arquivo .torrrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="200"/>
        <source>Download in sequential order</source>
        <translation>Baixar em ordem sequencial</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="186"/>
        <source>Download first and last pieces first</source>
        <translation>Baixar primeiro os primeiros e os últimos pedaços</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="379"/>
        <source>Info hash v2:</source>
        <translation>Informações do hash v2:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="402"/>
        <source>Select All</source>
        <translation>Selecionar tudo</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="409"/>
        <source>Select None</source>
        <translation>Não selecionar nenhum</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="508"/>
        <source>Save as .torrent file...</source>
        <translation>Salvar como arquivo .torrent...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="727"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="731"/>
        <source>High</source>
        <translation>Alta</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="735"/>
        <source>Maximum</source>
        <translation>Máxima</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="723"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="744"/>
        <source>Do not download</source>
        <translation>Não baixar</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="583"/>
        <source>I/O Error</source>
        <translation>Erro de E/S</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="358"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="945"/>
        <source>Invalid torrent</source>
        <translation>Torrent inválido</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="884"/>
        <source>Not Available</source>
        <comment>This comment is unavailable</comment>
        <translation>Não disponível</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="885"/>
        <source>Not Available</source>
        <comment>This date is unavailable</comment>
        <translation>Não disponível</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="894"/>
        <source>Not available</source>
        <translation>Não disponível</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="410"/>
        <source>Invalid magnet link</source>
        <translation>Link magnet inválido</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="359"/>
        <source>Failed to load the torrent: %1.
Error: %2</source>
        <comment>Don&apos;t remove the &apos;
&apos; characters. They insert a newline.</comment>
        <translation>Falhou em carregar o torrent: %1
Erro: %2</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="410"/>
        <source>This magnet link was not recognized</source>
        <translation>Este link magnet não foi reconhecido</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="445"/>
        <source>Magnet link</source>
        <translation>Link magnet</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="451"/>
        <source>Retrieving metadata...</source>
        <translation>Recuperando metadados...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="194"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="200"/>
        <source>Choose save path</source>
        <translation>Escolha o caminho do salvamento</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="382"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="388"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="393"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="425"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="431"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="436"/>
        <source>Torrent is already present</source>
        <translation>O torrent já está presente</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="382"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="425"/>
        <source>Torrent &apos;%1&apos; is already in the transfer list. Trackers haven&apos;t been merged because it is a private torrent.</source>
        <translation>O torrent &quot;%1&quot; já está na lista de transferências. Os trackers não foram unidos porque é um torrent privado.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="388"/>
        <source>Torrent &apos;%1&apos; is already in the transfer list. Trackers have been merged.</source>
        <translation>O torrent &quot;%1&quot; já está na lista de transferências. Os trackers foram unidos.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="393"/>
        <source>Torrent is already queued for processing.</source>
        <translation>O torrent já está na fila pra processamento.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="398"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="399"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="452"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="453"/>
        <source>N/A</source>
        <translation>N/D</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="431"/>
        <source>Magnet link &apos;%1&apos; is already in the transfer list. Trackers have been merged.</source>
        <translation>O link magnet &quot;%1&quot; já está na lista de transferências. Os trackers foram unidos.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="436"/>
        <source>Magnet link is already queued for processing.</source>
        <translation>O link magnet já está na fila pra processamento.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="491"/>
        <source>%1 (Free space on disk: %2)</source>
        <translation>%1 (Espaço livre no disco: %2)</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="492"/>
        <source>Not available</source>
        <comment>This size is unavailable.</comment>
        <translation>Não disponível</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="570"/>
        <source>Torrent file (*%1)</source>
        <translation>Arquivo torrent (*%1)</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="572"/>
        <source>Save as torrent file</source>
        <translation>Salvar como arquivo torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="584"/>
        <source>Couldn&apos;t export torrent metadata file &apos;%1&apos;. Reason: %2.</source>
        <translation>Não pôde exportar o arquivo de metadados do torrent &apos;%1&apos;. Motivo: %2.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="740"/>
        <source>By shown file order</source>
        <translation>Pela ordem mostrada dos arquivos</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="748"/>
        <source>Normal priority</source>
        <translation>Prioridade normal</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="752"/>
        <source>High priority</source>
        <translation>Prioridade alta</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="756"/>
        <source>Maximum priority</source>
        <translation>Prioridade máxima</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="761"/>
        <source>Priority by shown file order</source>
        <translation>Prioridade pela ordem mostrada dos arquivos</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="773"/>
        <source>Resize columns</source>
        <translation>Redimensionar colunas</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="781"/>
        <source>Resize all non-hidden columns to the size of their contents</source>
        <translation>Redimensionar todas as colunas não ocultas para o tamanho do conteúdo delas</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="868"/>
        <source>Cannot create v2 torrent until its data is fully downloaded.</source>
        <translation>Não pôde criar o torrent v2 até que seus dados sejam totalmente baixados.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="967"/>
        <source>Cannot download &apos;%1&apos;: %2</source>
        <translation>Não pôde baixar o &quot;%1&quot;: %2</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="719"/>
        <source>Rename...</source>
        <translation>Renomear...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="722"/>
        <source>Priority</source>
        <translation>Prioridade</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="858"/>
        <source>Parsing metadata...</source>
        <translation>Analisando metadados...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="862"/>
        <source>Metadata retrieval complete</source>
        <translation>Recuperação dos metadados completa</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="945"/>
        <source>Failed to load from URL: %1.
Error: %2</source>
        <translation>Falhou em carregar da URL: %1
Erro: %2</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="966"/>
        <source>Download Error</source>
        <translation>Erro do download</translation>
    </message>
</context>
<context>
    <name>AdvancedSettings</name>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="341"/>
        <location filename="../gui/advancedsettings.cpp" line="451"/>
        <location filename="../gui/advancedsettings.cpp" line="492"/>
        <source> MiB</source>
        <translation> MBs</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="586"/>
        <source>Outgoing ports (Min) [0: Disabled]</source>
        <translation>Portas de saída (Mín) [0: Desativado]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="593"/>
        <source>Outgoing ports (Max) [0: Disabled]</source>
        <translation>Portas de saída (Máx) [0: Desativado]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="640"/>
        <source>Recheck torrents on completion</source>
        <translation>Verificar os torrents de novo ao completar</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="646"/>
        <source>Transfer list refresh interval</source>
        <translation>Intervalo de atualização da lista de transferências</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="645"/>
        <location filename="../gui/advancedsettings.cpp" line="709"/>
        <source> ms</source>
        <comment> milliseconds</comment>
        <translation> ms</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="156"/>
        <source>Setting</source>
        <translation>Configuração</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="156"/>
        <source>Value</source>
        <comment>Value set for this setting</comment>
        <translation>Valor</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="337"/>
        <location filename="../gui/advancedsettings.cpp" line="350"/>
        <source> (disabled)</source>
        <translation> (desativado)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="339"/>
        <source> (auto)</source>
        <translation> (auto)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="348"/>
        <source> min</source>
        <comment> minutes</comment>
        <translation> mín</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="361"/>
        <source>All addresses</source>
        <translation>Todos os endereços</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="407"/>
        <source>qBittorrent Section</source>
        <translation>Seção do qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="404"/>
        <location filename="../gui/advancedsettings.cpp" line="412"/>
        <source>Open documentation</source>
        <translation>Abrir documentação</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="362"/>
        <source>All IPv4 addresses</source>
        <translation>Todos os endereços IPv4</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="363"/>
        <source>All IPv6 addresses</source>
        <translation>Todos os endereços IPv6</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="415"/>
        <source>libtorrent Section</source>
        <translation>Seção do libtorrent</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="418"/>
        <source>Fastresume files</source>
        <translation>Resumo rápido dos arquivos</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="418"/>
        <source>SQLite database (experimental)</source>
        <translation>Banco de dados do SQLite (experimental)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="420"/>
        <source>Resume data storage type (requires restart)</source>
        <translation>Tipo de armazenamento dos dados do resumo (requer reiniciar)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="423"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="423"/>
        <source>Below normal</source>
        <translation>Abaixo do normal</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="423"/>
        <source>Medium</source>
        <translation>Média</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="423"/>
        <source>Low</source>
        <translation>Baixa</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="423"/>
        <source>Very low</source>
        <translation>Muito baixa</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="445"/>
        <source>Process memory priority (Windows &gt;= 8 only)</source>
        <translation>Prioridade da memória do processo (só Windows &gt;= 8)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="454"/>
        <source>Physical memory (RAM) usage limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="463"/>
        <source>Asynchronous I/O threads</source>
        <translation>Threads de E/S assíncronos</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="471"/>
        <source>Hashing threads</source>
        <translation>Threads de cálculo do hash</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="479"/>
        <source>File pool size</source>
        <translation>Tamanho do conjunto de arquivos</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="493"/>
        <source>Outstanding memory when checking torrents</source>
        <translation>Memória excelente quando verificar torrents</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="509"/>
        <source>Disk cache</source>
        <translation>Cache do disco</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="515"/>
        <location filename="../gui/advancedsettings.cpp" line="600"/>
        <location filename="../gui/advancedsettings.cpp" line="692"/>
        <location filename="../gui/advancedsettings.cpp" line="783"/>
        <source> s</source>
        <comment> seconds</comment>
        <translation> s</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="516"/>
        <source>Disk cache expiry interval</source>
        <translation>Intervalo de expiração do cache do disco</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="524"/>
        <source>Disk queue size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="528"/>
        <source>Enable OS cache</source>
        <translation>Ativar cache do sistema operacional</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="533"/>
        <source>Coalesce reads &amp; writes</source>
        <translation>Coalescer leituras &amp; gravações</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="538"/>
        <source>Use piece extent affinity</source>
        <translation>Usar afinidade da extensão dos pedaços</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="541"/>
        <source>Send upload piece suggestions</source>
        <translation>Enviar sugestões de pedaços do upload</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="791"/>
        <source>Maximum outstanding requests to a single peer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="523"/>
        <location filename="../gui/advancedsettings.cpp" line="546"/>
        <location filename="../gui/advancedsettings.cpp" line="552"/>
        <source> KiB</source>
        <translation> KBs</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="548"/>
        <source>Send buffer watermark</source>
        <translation>Enviar marca d&apos;água do buffer</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="554"/>
        <source>Send buffer low watermark</source>
        <translation>Enviar marca d&apos;água do buffer baixo</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="560"/>
        <source>Send buffer watermark factor</source>
        <translation>Enviar fator de marca d&apos;água do buffer</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="566"/>
        <source>Outgoing connections per second</source>
        <translation>Conexões de saída por segundo</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="572"/>
        <source>Socket backlog size</source>
        <translation>Tamanho do backlog do soquete</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="601"/>
        <source>UPnP lease duration [0: Permanent lease]</source>
        <translation>Duração do arrendamento do UPnP [0: Arrendamento permanente]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="607"/>
        <source>Type of service (ToS) for connections to peers</source>
        <translation>Tipo de serviço (ToS) para as conexões com os peers</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="610"/>
        <source>Prefer TCP</source>
        <translation>Preferir TCP</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="610"/>
        <source>Peer proportional (throttles TCP)</source>
        <translation>Peer proporcional (sufoca o TCP)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="617"/>
        <source>Support internationalized domain name (IDN)</source>
        <translation>Suporte a nome internacionalizado de domínio (IDN)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="622"/>
        <source>Allow multiple connections from the same IP address</source>
        <translation>Permitir múltiplas conexões do mesmo endereço de IP</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="627"/>
        <source>Validate HTTPS tracker certificates</source>
        <translation>Validar certificados dos trackers HTTPS</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="632"/>
        <source>Server-side request forgery (SSRF) mitigation</source>
        <translation>Atenuação da falsificação da requisição do lado do servidor (SSRF)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="637"/>
        <source>Disallow connection to peers on privileged ports</source>
        <translation>Não permitir conexão com peers em portas privilegiadas</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="652"/>
        <source>Resolve peer host names</source>
        <translation>Revelar nomes dos hospedeiros peers</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="682"/>
        <source>IP address reported to trackers (requires restart)</source>
        <translation>Endereço de IP reportado aos trackers (requer reiniciar)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="708"/>
        <source>System default</source>
        <translation>Padrão do sistema</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="710"/>
        <source>Notification timeout [0: infinite]</source>
        <translation>Tempo limite da notificação [0: infinito]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="714"/>
        <source>Reannounce to all trackers when IP or port changed</source>
        <translation>Re-anunciar pra todos os trackers quando o IP ou porta for mudado</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="728"/>
        <source>Enable icons in menus</source>
        <translation>Ativar ícones nos menus</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="773"/>
        <source>Peer turnover disconnect percentage</source>
        <translation>Porcentagem da desconexão da rotatividade dos peers</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="779"/>
        <source>Peer turnover threshold percentage</source>
        <translation>Porcentagem do limite da rotatividade dos peers</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="785"/>
        <source>Peer turnover disconnect interval</source>
        <translation>Intervalo da desconexão da rotatividade dos peers</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="693"/>
        <source>Stop tracker timeout</source>
        <translation>Parar o tempo pra encerrar o tracker</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="699"/>
        <source>Display notifications</source>
        <translation>Exibir notificações</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="702"/>
        <source>Display notifications for added torrents</source>
        <translation>Exibe notificações pros torrents adicionados</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="717"/>
        <source>Download tracker&apos;s favicon</source>
        <translation>Baixar favicon do tracker</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="721"/>
        <source>Save path history length</source>
        <translation>Tamanho do histórico do caminho do salvamento</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="724"/>
        <source>Enable speed graphs</source>
        <translation>Ativar os gráficos da velocidade</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="739"/>
        <source>Fixed slots</source>
        <translation>Slots fixos</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="739"/>
        <source>Upload rate based</source>
        <translation>Baseado na taxa de upload</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="741"/>
        <source>Upload slots behavior</source>
        <translation>Comportamento dos slots de upload</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="744"/>
        <source>Round-robin</source>
        <translation>Pontos-corridos</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="744"/>
        <source>Fastest upload</source>
        <translation>Upload mais rápido</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="744"/>
        <source>Anti-leech</source>
        <translation>Anti-leech</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="746"/>
        <source>Upload choking algorithm</source>
        <translation>Algorítmo de sufoco do upload</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="751"/>
        <source>Confirm torrent recheck</source>
        <translation>Confirmar nova verificação do torrent</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="755"/>
        <source>Confirm removal of all tags</source>
        <translation>Confirmar remoção de todas as etiquetas</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="759"/>
        <source>Always announce to all trackers in a tier</source>
        <translation>Sempre anunciar em todos os trackers numa camada</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="765"/>
        <source>Always announce to all tiers</source>
        <translation>Sempre anunciar pra todas as camadas</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="654"/>
        <source>Any interface</source>
        <comment>i.e. Any network interface</comment>
        <translation>Qualquer interface</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="581"/>
        <source>Save resume data interval</source>
        <comment>How often the fastresume file is saved.</comment>
        <translation>Salvar o intervalo de dados do resumo</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="612"/>
        <source>%1-TCP mixed mode algorithm</source>
        <comment>uTP-TCP mixed mode algorithm</comment>
        <translation>Algorítmo de modo misto %1-TCP</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="649"/>
        <source>Resolve peer countries</source>
        <translation>Revelar os países dos peers</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="676"/>
        <source>Network interface</source>
        <translation>Interface de rede</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="679"/>
        <source>Optional IP address to bind to</source>
        <translation>Endereço de IP opcional pra se vincular</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="688"/>
        <source>Max concurrent HTTP announces</source>
        <translation>Máximo de anúncios HTTP simultâneos</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="732"/>
        <source>Enable embedded tracker</source>
        <translation>Ativar tracker embutido</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="737"/>
        <source>Embedded tracker port</source>
        <translation>Porta do tracker embutido</translation>
    </message>
</context>
<context>
    <name>Application</name>
    <message>
        <location filename="../app/application.cpp" line="180"/>
        <source>qBittorrent %1 started</source>
        <comment>qBittorrent v3.2.0alpha started</comment>
        <translation>qBittorrent %1 iniciado</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="183"/>
        <source>Running in portable mode. Auto detected profile folder at: %1</source>
        <translation>Executando no modo portátil. Pasta do perfil auto-detectada em: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="185"/>
        <source>Redundant command line flag detected: &quot;%1&quot;. Portable mode implies relative fastresume.</source>
        <translation>Bandeira da linha de comando redundante detectada: &quot;%1&quot;. O modo portátil implica no resumo rápido relativo.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="189"/>
        <source>Using config directory: %1</source>
        <translation>Usando diretório das configurações: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="403"/>
        <source>Torrent: %1, running external program, command: %2</source>
        <translation>Torrent: %1, executando programa externo, comando: %2</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="461"/>
        <source>Torrent name: %1</source>
        <translation>Nome do torrent: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="462"/>
        <source>Torrent size: %1</source>
        <translation>Tamanho do torrent: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="463"/>
        <source>Save path: %1</source>
        <translation>Caminho do salvamento: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="464"/>
        <source>The torrent was downloaded in %1.</source>
        <comment>The torrent was downloaded in 1 hour and 20 seconds</comment>
        <translation>O torrent foi baixado em %1.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="466"/>
        <source>Thank you for using qBittorrent.</source>
        <translation>Obrigado por usar o qBittorrent.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="473"/>
        <source>[qBittorrent] &apos;%1&apos; has finished downloading</source>
        <translation>[qBittorrent] O &quot;%1&quot; terminou de baixar</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="488"/>
        <source>Torrent: %1, sending mail notification</source>
        <translation>Torrent: %1, enviando notificação por e-mail</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="662"/>
        <source>Application failed to start.</source>
        <translation>O aplicativo falhou em iniciar.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="677"/>
        <source>Information</source>
        <translation>Informação</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="678"/>
        <source>To control qBittorrent, access the WebUI at: %1</source>
        <translation>Pra controlar o qBittorrent acesse a interface de usuário da web em: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="683"/>
        <source>The Web UI administrator username is: %1</source>
        <translation>O nome do administrador da interface de usuário da web é: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="684"/>
        <source>The Web UI administrator password has not been changed from the default: %1</source>
        <translation>A senha do administrador da interface de usuário da web não foi alterada do padrão: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="685"/>
        <source>This is a security risk, please change your password in program preferences.</source>
        <translation>Este é um risco de segurança, por favor mude sua senha nas preferências do programa.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="816"/>
        <source>Failed to set physical memory (RAM) usage limit. Error code: %1. Error message: &quot;%2&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="840"/>
        <source>Saving torrent progress...</source>
        <translation>Salvando o progresso do torrent...</translation>
    </message>
</context>
<context>
    <name>AsyncFileStorage</name>
    <message>
        <location filename="../base/asyncfilestorage.cpp" line="45"/>
        <source>Could not create directory &apos;%1&apos;.</source>
        <translation>Não pôde criar o diretório &quot;%1&quot;.</translation>
    </message>
</context>
<context>
    <name>AuthController</name>
    <message>
        <location filename="../webui/api/authcontroller.cpp" line="54"/>
        <source>WebAPI login failure. Reason: IP has been banned, IP: %1, username: %2</source>
        <translation>Falha no login do WebAPI. Motivo: o IP foi banido, IP: %1, nome de usuário: %2</translation>
    </message>
    <message>
        <location filename="../webui/api/authcontroller.cpp" line="58"/>
        <source>Your IP address has been banned after too many failed authentication attempts.</source>
        <translation>Seu endereço de IP foi banido após muitas tentativas de autenticação falhas.</translation>
    </message>
    <message>
        <location filename="../webui/api/authcontroller.cpp" line="74"/>
        <source>WebAPI login success. IP: %1</source>
        <translation>Sucesso do login no WebAPI. IP: %1</translation>
    </message>
    <message>
        <location filename="../webui/api/authcontroller.cpp" line="81"/>
        <source>WebAPI login failure. Reason: invalid credentials, attempt count: %1, IP: %2, username: %3</source>
        <translation>Falha no login do WebAPI. Motivo: credenciais inválidas, contagem de tentativas: %1, IP: %2, nome de usuário: %3</translation>
    </message>
</context>
<context>
    <name>AutomatedRssDownloader</name>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="243"/>
        <source>Save to:</source>
        <translation>Salvar em:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="14"/>
        <source>RSS Downloader</source>
        <translation>Baixador do RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="59"/>
        <source>Download Rules</source>
        <translation>Regras do Download</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="99"/>
        <source>Rule Definition</source>
        <translation>Definição da Regra</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="105"/>
        <source>Use Regular Expressions</source>
        <translation>Usar Expressões Regulares</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="190"/>
        <source>Use Smart Episode Filter</source>
        <translation>Usar Filtro Inteligente dos Episódios</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="114"/>
        <source>Must Contain:</source>
        <translation>Deve Conter:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="28"/>
        <source>Auto downloading of RSS torrents is currently disabled. You can enable it in application settings.</source>
        <translation>O download automático dos torrents do RSS está desativado atualmente. Você pode ativá-lo nas configurações do programa.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="121"/>
        <source>Must Not Contain:</source>
        <translation>Não Deve Conter:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="128"/>
        <source>Episode Filter:</source>
        <translation>Filtro do Episódio:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="186"/>
        <source>Smart Episode Filter will check the episode number to prevent downloading of duplicates.
Supports the formats: S01E01, 1x1, 2017.12.31 and 31.12.2017 (Date formats also support - as a separator)</source>
        <translation>O Filtro Inteligente dos Episódios verificará o número do episódio pra impedir o download de duplicatas.
Suporta os formatos: S01E01, 1x1, 2017.12.31 e 31.12.2017 (Os formatos de data também suportam o - como um separador)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="212"/>
        <source>Category:</source>
        <translation>Categoria:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="231"/>
        <source>Save to a Different Directory</source>
        <translation>Salvar num diretório diferente</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="257"/>
        <source>Ignore Subsequent Matches for (0 to Disable)</source>
        <extracomment>... X days</extracomment>
        <translation>Ignorar combinações subsequentes com (0 pra Desativar)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="267"/>
        <source>Disabled</source>
        <translation>Desativado</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="270"/>
        <source> days</source>
        <translation> dias</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="303"/>
        <source>Add Paused:</source>
        <translation>Adicionar pausado:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="311"/>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="347"/>
        <source>Use global settings</source>
        <translation>Usar configurações globais</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="316"/>
        <source>Always</source>
        <translation>Sempre</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="321"/>
        <source>Never</source>
        <translation>Nunca</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="339"/>
        <source>Torrent content layout:</source>
        <translation>Layout do conteúdo do torrent:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="352"/>
        <source>Original</source>
        <translation>Original</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="357"/>
        <source>Create subfolder</source>
        <translation>Criar sub-pasta</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="362"/>
        <source>Don&apos;t create subfolder</source>
        <translation>Não criar sub-pasta</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="383"/>
        <source>Apply Rule to Feeds:</source>
        <translation>Aplicar a regra aos feeds:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="405"/>
        <source>Matching RSS Articles</source>
        <translation>Combinar artigos do RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="433"/>
        <source>&amp;Import...</source>
        <translation>&amp;Importar...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="443"/>
        <source>&amp;Export...</source>
        <translation>&amp;Exportar...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="91"/>
        <source>Matches articles based on episode filter.</source>
        <translation>Combina artigos baseado no filtro dos episódios.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="91"/>
        <source>Example: </source>
        <translation>Exemplo: </translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="92"/>
        <source> will match 2, 5, 8 through 15, 30 and onward episodes of season one</source>
        <comment>example X will match</comment>
        <translation> combinará nos episódios 2, 5, 8 até 15, 30 e dos episódios posteriores da temporada um</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="93"/>
        <source>Episode filter rules: </source>
        <translation>Regras do filtro dos episódios: </translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="93"/>
        <source>Season number is a mandatory non-zero value</source>
        <translation>O número da temporada é um valor obrigatório não-zero</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="95"/>
        <source>Filter must end with semicolon</source>
        <translation>O filtro deve terminar com ponto e vírgula</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="96"/>
        <source>Three range types for episodes are supported: </source>
        <translation>Três tipos de alcance pros episódios são suportados: </translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="97"/>
        <source>Single number: &lt;b&gt;1x25;&lt;/b&gt; matches episode 25 of season one</source>
        <translation>Número único: &lt;b&gt;1x25;&lt;/b&gt; combina com o episódio 25 da temporada um</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="98"/>
        <source>Normal range: &lt;b&gt;1x25-40;&lt;/b&gt; matches episodes 25 through 40 of season one</source>
        <translation>Alcance normal: &lt;b&gt;1x25-40;&lt;/b&gt; combina com os episódios 25 até 40 da temporada um</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="94"/>
        <source>Episode number is a mandatory positive value</source>
        <translation>O número do episódio é um valor positivo obrigatório</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="64"/>
        <source>Rules</source>
        <translation>Regras</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="65"/>
        <source>Rules (legacy)</source>
        <translation>Regras (legado)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="99"/>
        <source>Infinite range: &lt;b&gt;1x25-;&lt;/b&gt; matches episodes 25 and upward of season one, and all episodes of later seasons</source>
        <translation>Alcance infinito: &lt;b&gt;1x25-;&lt;/b&gt; combina com os episódios 25 e acima da temporada um e todos os episódios das temporadas posteriores</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="286"/>
        <source>Last Match: %1 days ago</source>
        <translation>Última combinação: %1 dias atrás</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="288"/>
        <source>Last Match: Unknown</source>
        <translation>Última combinação: desconhecida</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="380"/>
        <source>New rule name</source>
        <translation>Nome da nova regra</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="380"/>
        <source>Please type the name of the new download rule.</source>
        <translation>Por favor digite o nome da nova regra de download.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="386"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="552"/>
        <source>Rule name conflict</source>
        <translation>Conflito do nome da regra</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="387"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="553"/>
        <source>A rule with this name already exists, please choose another name.</source>
        <translation>Uma regra com este nome já existe, por favor escolha outro nome.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="401"/>
        <source>Are you sure you want to remove the download rule named &apos;%1&apos;?</source>
        <translation>Você tem certeza que você quer remover a regra do download chamada &quot;%1&quot;?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="403"/>
        <source>Are you sure you want to remove the selected download rules?</source>
        <translation>Você tem certeza que você quer remover as regras de download selecionadas?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="404"/>
        <source>Rule deletion confirmation</source>
        <translation>Confirmação de exclusão da regra</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="83"/>
        <source>Destination directory</source>
        <translation>Diretório de destino</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="426"/>
        <source>Invalid action</source>
        <translation>Ação inválida</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="427"/>
        <source>The list is empty, there is nothing to export.</source>
        <translation>A lista está vazia, não há nada pra exportar.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="433"/>
        <source>Export RSS rules</source>
        <translation>Exportar regras do RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="460"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="478"/>
        <source>I/O Error</source>
        <translation>Erro de E/S</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="461"/>
        <source>Failed to create the destination file. Reason: %1</source>
        <translation>Falhou em criar o arquivo de destino. Motivo: %1</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="469"/>
        <source>Import RSS rules</source>
        <translation>Importar regras do RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="479"/>
        <source>Failed to open the file. Reason: %1</source>
        <translation>Falhou em abrir o arquivo. Motivo: %1</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="497"/>
        <source>Import Error</source>
        <translation>Erro de importação</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="498"/>
        <source>Failed to import the selected rules file. Reason: %1</source>
        <translation>Falhou em importar o arquivo de regras selecionado. Motivo: %1</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="507"/>
        <source>Add new rule...</source>
        <translation>Adicionar nova regra...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="516"/>
        <source>Delete rule</source>
        <translation>Apagar regra</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="519"/>
        <source>Rename rule...</source>
        <translation>Renomear regra...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="524"/>
        <source>Delete selected rules</source>
        <translation>Apagar as regras selecionadas</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="529"/>
        <source>Clear downloaded episodes...</source>
        <translation>Limpar episódios baixados...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="545"/>
        <source>Rule renaming</source>
        <translation>Renomear regra</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="545"/>
        <source>Please type the new rule name</source>
        <translation>Por favor digite o novo nome da regra</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="573"/>
        <source>Clear downloaded episodes</source>
        <translation>Limpar episódios baixados</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="574"/>
        <source>Are you sure you want to clear the list of downloaded episodes for the selected rule?</source>
        <translation>Você tem certeza que você quer limpar a lista de episódios baixados da regra selecionada?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="688"/>
        <source>Regex mode: use Perl-compatible regular expressions</source>
        <translation>Modo Regex: usar expressões regulares compatíveis com Perl</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="738"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="785"/>
        <source>Position %1: %2</source>
        <translation>Posição %1: %2</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="692"/>
        <source>Wildcard mode: you can use</source>
        <translation>Modo wildcard: você pode usar</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="693"/>
        <source>? to match any single character</source>
        <translation>? pra combinar com qualquer caractere único</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="694"/>
        <source>* to match zero or more of any characters</source>
        <translation>* pra combinar com zero ou mais de quaisquer caracteres</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="695"/>
        <source>Whitespaces count as AND operators (all words, any order)</source>
        <translation>Espaços em branco contam como operadores AND (todas as palavras, qualquer ordem)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="696"/>
        <source>| is used as OR operator</source>
        <translation>| é usado como operador OR</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="697"/>
        <source>If word order is important use * instead of whitespace.</source>
        <translation>Se as ordem das palavras é importante, use * ao invés de espaço em branco.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="704"/>
        <source>An expression with an empty %1 clause (e.g. %2)</source>
        <comment>We talk about regex/wildcards in the RSS filters section here. So a valid sentence would be: An expression with an empty | clause (e.g. expr|)</comment>
        <translation>Uma expressão com uma cláusula %1 vazia (ex: %2)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="708"/>
        <source> will match all articles.</source>
        <translation> combinará com todos os artigos.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="709"/>
        <source> will exclude all articles.</source>
        <translation> apagará todos os artigos.</translation>
    </message>
</context>
<context>
    <name>BanListOptionsDialog</name>
    <message>
        <location filename="../gui/banlistoptionsdialog.ui" line="14"/>
        <source>List of banned IP addresses</source>
        <translation>Lista de endereços de IP banidos</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptionsdialog.ui" line="80"/>
        <source>Ban IP</source>
        <translation>Banir IP</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptionsdialog.ui" line="87"/>
        <source>Delete</source>
        <translation>Apagar</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptionsdialog.cpp" line="94"/>
        <location filename="../gui/banlistoptionsdialog.cpp" line="106"/>
        <source>Warning</source>
        <translation>Aviso</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptionsdialog.cpp" line="94"/>
        <source>The entered IP address is invalid.</source>
        <translation>O endereço de IP inserido é inválido.</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptionsdialog.cpp" line="106"/>
        <source>The entered IP is already banned.</source>
        <translation>O endereço de IP inserido já está banido.</translation>
    </message>
</context>
<context>
    <name>BitTorrent::BencodeResumeDataStorage</name>
    <message>
        <location filename="../base/bittorrent/bencoderesumedatastorage.cpp" line="102"/>
        <source>Cannot create torrent resume folder: &quot;%1&quot;</source>
        <translation>Não pôde criar a pasta de resumo do torrent: &quot;%1&quot;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/bencoderesumedatastorage.cpp" line="307"/>
        <source>Couldn&apos;t load torrents queue from &apos;%1&apos;. Error: %2</source>
        <translation>Não pôde carregar a fila dos torrents de &apos;%1&apos;. Erro: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/bencoderesumedatastorage.cpp" line="360"/>
        <source>Couldn&apos;t save torrent metadata to &apos;%1&apos;. Error: %2.</source>
        <translation>Não pôde salvar os metadados do torrent em &apos;%1&apos;. Erro: %2.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/bencoderesumedatastorage.cpp" line="385"/>
        <source>Couldn&apos;t save torrent resume data to &apos;%1&apos;. Error: %2.</source>
        <translation>Não pôde salvar os dados de resumo do torrent em &apos;%1&apos;. Erro: %2.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/bencoderesumedatastorage.cpp" line="146"/>
        <location filename="../base/bittorrent/bencoderesumedatastorage.cpp" line="153"/>
        <source>Cannot read file %1: %2</source>
        <translation>Não pôde ler o arquivo &apos;%1&apos;: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/bencoderesumedatastorage.cpp" line="410"/>
        <source>Couldn&apos;t save data to &apos;%1&apos;. Error: %2</source>
        <translation>Não pôde salvar os dados em &apos;%1&apos;. Erro: %2</translation>
    </message>
</context>
<context>
    <name>BitTorrent::DBResumeDataStorage</name>
    <message>
        <location filename="../base/bittorrent/dbresumedatastorage.cpp" line="282"/>
        <source>Not found.</source>
        <translation>Não encontrado.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/dbresumedatastorage.cpp" line="286"/>
        <source>Couldn&apos;t load resume data of torrent &apos;%1&apos;. Error: %2</source>
        <translation>Não pôde carregar os dados do resumo do torrent &apos;%1&apos;. Erro: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/dbresumedatastorage.cpp" line="379"/>
        <location filename="../base/bittorrent/dbresumedatastorage.cpp" line="384"/>
        <source>Database is corrupted.</source>
        <translation>O banco de dados está corrompido.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/dbresumedatastorage.cpp" line="569"/>
        <source>Couldn&apos;t save torrent metadata. Error: %1.</source>
        <translation>Não pôde salvar os metadados do torrent. Erro: %1.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/dbresumedatastorage.cpp" line="619"/>
        <source>Couldn&apos;t store resume data for torrent &apos;%1&apos;. Error: %2</source>
        <translation>Não pôde armazenar os dados do resumo do torrent &apos;%1&apos;. Erro: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/dbresumedatastorage.cpp" line="643"/>
        <source>Couldn&apos;t delete resume data of torrent &apos;%1&apos;. Error: %2</source>
        <translation>Não pôde apagar os dados do resumo do torrent &apos;%1&apos;. Erro: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/dbresumedatastorage.cpp" line="688"/>
        <source>Couldn&apos;t store torrents queue positions. Error: %1</source>
        <translation>Não pôde armazenar as posições da fila dos torrents. Erro: %1</translation>
    </message>
</context>
<context>
    <name>BitTorrent::Session</name>
    <message>
        <source>Restart is required to toggle PeX support</source>
        <translation type="vanished">É requerido reiniciar pra alternar o suporte ao PeX</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2601"/>
        <source>System network status changed to %1</source>
        <comment>e.g: System network status changed to ONLINE</comment>
        <translation>Status da rede do sistema mudado pra %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2601"/>
        <source>ONLINE</source>
        <translation>ONLINE</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2601"/>
        <source>OFFLINE</source>
        <translation>OFFLINE</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2615"/>
        <source>Network configuration of %1 has changed, refreshing session binding</source>
        <comment>e.g: Network configuration of tun0 has changed, refreshing session binding</comment>
        <translation>A configuração de rede do %1 foi mudada, atualizando a vinculação da sessão</translation>
    </message>
    <message>
        <source>Encryption support [%1]</source>
        <translation type="vanished">Suporte a encriptação [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1161"/>
        <location filename="../base/bittorrent/session.cpp" line="2991"/>
        <source>FORCED</source>
        <translation>FORÇADO</translation>
    </message>
    <message>
        <source>Anonymous mode [%1]</source>
        <translation type="vanished">Modo anônimo [%1]</translation>
    </message>
    <message>
        <source>&apos;%1&apos; reached the maximum ratio you set. Removed torrent and its files.</source>
        <translation type="vanished">&apos;%1&apos; alcançou a proporção máxima que você definiu. Removeu o torrent e seus arquivos.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; reached the maximum ratio you set. Enabled super seeding for it.</source>
        <translation type="vanished">&apos;%1&apos; alcançou a proporção máxima que você definiu. O super seeding foi ativado pra ele.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; reached the maximum seeding time you set. Removed torrent and its files.</source>
        <translation type="vanished">&apos;%1&apos; atingiu o tempo máximo de seeding que você definiu. O torrent e seus arquivos foram removidos.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; reached the maximum seeding time you set. Enabled super seeding for it.</source>
        <translation type="vanished">&apos;%1&apos; alcançou o tempo máximo de seeding que você definiu. O super seeding foi ativado pra ele.</translation>
    </message>
    <message>
        <source>Couldn&apos;t load torrent: %1</source>
        <translation type="vanished">Não pôde carregar o torrent: %1</translation>
    </message>
    <message>
        <source>Couldn&apos;t export torrent metadata file &apos;%1&apos;. Reason: %2.</source>
        <translation type="vanished">Não pôde exportar o arquivo de metadados do torrent &apos;%1&apos;. Motivo: %2.</translation>
    </message>
    <message>
        <source>Error: Aborted saving resume data for %1 outstanding torrents.</source>
        <translation type="vanished">Erro: Abortou o salvamento dos dados do resumo pra %1 torrents pendentes.</translation>
    </message>
    <message>
        <source>Configured network interface address %1 isn&apos;t valid.</source>
        <comment>Configured network interface address 124.5.158.1 isn&apos;t valid.</comment>
        <translation type="vanished">O endereço %1 da interface de rede configurada não é válido.</translation>
    </message>
    <message>
        <source>Can&apos;t find the configured address &apos;%1&apos; to listen on</source>
        <comment>Can&apos;t find the configured address &apos;192.168.1.3&apos; to listen on</comment>
        <translation type="vanished">Não pôde achar o endereço configurado &apos;%1&apos; pra escutar</translation>
    </message>
    <message>
        <source>%1 is not a valid IP address and was rejected while applying the list of banned IP addresses.</source>
        <translation type="vanished">%1 não é um endereço de IP válido e foi rejeitado enquanto aplicado a lista de endereços de IP banidos.</translation>
    </message>
    <message>
        <source>Unable to decode &apos;%1&apos; torrent file.</source>
        <translation type="vanished">Incapaz de decodificar o arquivo torrent &apos;%1&apos;.</translation>
    </message>
    <message>
        <source>Cancelled moving &quot;%1&quot; from &quot;%2&quot; to &quot;%3&quot;.</source>
        <translation type="vanished">Cancelada a movimentação do %1&quot; de &quot;%2&quot; pra &quot;%3&quot;.</translation>
    </message>
    <message>
        <source>Couldn&apos;t enqueue move of &quot;%1&quot; to &quot;%2&quot;. Torrent is currently moving to the same destination location.</source>
        <translation type="vanished">Não pôde enfileirar a movimentação do &quot;%1&quot; pra &quot;%2&quot;. O torrent está sendo movido atualmente para o mesmo local de destino.</translation>
    </message>
    <message>
        <source>Couldn&apos;t enqueue move of &quot;%1&quot; from &quot;%2&quot; to &quot;%3&quot;. Both paths point to the same location.</source>
        <translation type="vanished">Não pôde enfileirar a movimentação do &quot;%1&quot; de &quot;%2&quot; pra &quot;%3&quot;. Ambos os caminhos apontam para o mesmo local.</translation>
    </message>
    <message>
        <source>Enqueued to move &quot;%1&quot; from &quot;%2&quot; to &quot;%3&quot;.</source>
        <translation type="vanished">Enfileirado pra mover o &quot;%1&quot; de &quot;%2&quot; pra &quot;%3&quot;.</translation>
    </message>
    <message>
        <source>Moving &quot;%1&quot; to &quot;%2&quot;...</source>
        <translation type="vanished">Movendo &quot;%1&quot; pra &quot;%2&quot;...</translation>
    </message>
    <message>
        <source>Couldn&apos;t store Categories configuration to %1. Error: %2</source>
        <translation type="vanished">Não pôde armazenar a configuração das Categorias em %1. Erro: %2</translation>
    </message>
    <message>
        <source>Couldn&apos;t load Categories from %1. Error: %2</source>
        <translation type="vanished">Não pôde carregar as Categorias de %1. Erro: %2</translation>
    </message>
    <message>
        <source>Couldn&apos;t parse Categories configuration from %1. Error: %2</source>
        <translation type="vanished">Não pôde analisar a configuração das Categorias de %1. Erro: %2</translation>
    </message>
    <message>
        <source>Couldn&apos;t load Categories configuration from %1. Invalid data format.</source>
        <translation type="vanished">Não pôde carregar a configuração das Categorias de %1. Formato dos dados inválido.</translation>
    </message>
    <message>
        <source>Recursive download of file &apos;%1&apos; embedded in torrent &apos;%2&apos;</source>
        <comment>Recursive download of &apos;test.torrent&apos; embedded in torrent &apos;test2&apos;</comment>
        <translation type="vanished">Download recursivo do arquivo &apos;%1&apos; embutido no torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <source>Couldn&apos;t load torrent. Reason: %1.</source>
        <translation type="vanished">Não pôde carregar o torrent. Motivo: %1.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="575"/>
        <location filename="../base/bittorrent/session.cpp" line="1157"/>
        <source>Distributed Hash Table (DHT) support: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="590"/>
        <location filename="../base/bittorrent/session.cpp" line="1158"/>
        <source>Local Peer Discovery support: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="604"/>
        <source>Restart is required to toggle Peer Exchange (PeX) support</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1155"/>
        <source>Peer ID: &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1156"/>
        <source>HTTP User-Agent: &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1159"/>
        <source>Peer Exchange (PeX) support: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1160"/>
        <location filename="../base/bittorrent/session.cpp" line="3589"/>
        <source>Anonymous mode: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1161"/>
        <location filename="../base/bittorrent/session.cpp" line="2990"/>
        <source>Encryption support: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1543"/>
        <source>Could not find GUID of network interface. Interface: &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1558"/>
        <source>Trying to listen on the following list of IP addresses: &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1706"/>
        <source>Torrent reached the share ratio limit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1707"/>
        <location filename="../base/bittorrent/session.cpp" line="1750"/>
        <source>Torrent: &quot;%1&quot;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1711"/>
        <location filename="../base/bittorrent/session.cpp" line="1754"/>
        <source>Removed torrent.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1716"/>
        <location filename="../base/bittorrent/session.cpp" line="1759"/>
        <source>Removed torrent and deleted its content.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1722"/>
        <location filename="../base/bittorrent/session.cpp" line="1765"/>
        <source>Torrent paused.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1727"/>
        <location filename="../base/bittorrent/session.cpp" line="1770"/>
        <source>Super seeding enabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1749"/>
        <source>Torrent reached the seeding time limit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1789"/>
        <location filename="../base/bittorrent/session.cpp" line="4937"/>
        <source>Failed to load torrent. Reason: &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2104"/>
        <source>Downloading torrent, please wait... Source: &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2121"/>
        <source>Failed to load torrent. Source: &quot;%1&quot;. Reason: &quot;%2&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2463"/>
        <source>Failed to export torrent. Torrent: &quot;%1&quot;. Destination: &quot;%2&quot;. Reason: &quot;%3&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2497"/>
        <source>Aborted saving resume data. Number of outstanding torrents: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2633"/>
        <source>The configured network address is invalid. Address: &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2674"/>
        <location filename="../base/bittorrent/session.cpp" line="2708"/>
        <source>Failed to find the configured network address to listen on. Address: &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2687"/>
        <source>The configured network interface is invalid. Interface: &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3121"/>
        <source>Rejected invalid IP address while applying the list of banned IP addresses. IP: &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4086"/>
        <source>Added tracker to torrent. Torrent: &quot;%1&quot;. Tracker: &quot;%2&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4096"/>
        <source>Removed tracker from torrent. Torrent: &quot;%1&quot;. Tracker: &quot;%2&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4111"/>
        <source>Added URL seed to torrent. Torrent: &quot;%1&quot;. URL: &quot;%2&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4117"/>
        <source>Removed URL seed from torrent. Torrent: &quot;%1&quot;. URL: &quot;%2&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4138"/>
        <source>Torrent paused. Torrent: &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4144"/>
        <source>Torrent resumed. Torrent: &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4155"/>
        <source>Torrent download finished. Torrent: &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4176"/>
        <source>Unable to load torrent. File: &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4221"/>
        <source>Torrent move canceled. Torrent: &quot;%1&quot;. Source: &quot;%2&quot;. Destination: &quot;%3&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4240"/>
        <source>Failed to enqueue torrent move. Torrent: &quot;%1&quot;. Source: &quot;%2&quot;. Destination: &quot;%3&quot;. Reason: torrent is currently moving to the destination</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4249"/>
        <source>Failed to enqueue torrent move. Torrent: &quot;%1&quot;. Source: &quot;%2&quot; Destination: &quot;%3&quot;. Reason: both paths point to the same location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4257"/>
        <source>Enqueued torrent move. Torrent: &quot;%1&quot;. Source: &quot;%2&quot;. Destination: &quot;%3&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4274"/>
        <source>Start moving torrent. Torrent: &quot;%1&quot;. Destination: &quot;%2&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4325"/>
        <source>Failed to save Categories configuration. File: &quot;%1&quot;. Error: &quot;%2&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4362"/>
        <source>Failed to load Categories. File: &quot;%1&quot;. Error: &quot;%2&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4371"/>
        <source>Failed to parse Categories configuration. File: &quot;%1&quot;. Error: &quot;%2&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4378"/>
        <source>Failed to load Categories configuration. File: &quot;%1&quot;. Reason: invalid data format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4462"/>
        <source>Recursive download .torrent file within torrent. Source torrent: &quot;%1&quot;. File: &quot;%2&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4473"/>
        <source>Failed to load torrent. Error: &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4538"/>
        <location filename="../base/bittorrent/session.cpp" line="4670"/>
        <source>Failed to resume torrent. Torrent: &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4591"/>
        <location filename="../base/bittorrent/session.cpp" line="4601"/>
        <source>Failed to resume torrent: inconsistent torrent ID is detected. Torrent: &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4639"/>
        <source>Detected inconsistent data: category is missing from the configuration file. Category will be recovered but its settings will be reset to default. Torrent: &quot;%1&quot;. Category: &quot;%2&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4646"/>
        <source>Detected inconsistent data: invalid category. Torrent: &quot;%1&quot;. Category: &quot;%2&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4661"/>
        <source>Detected mismatch between the save paths of the recovered category and the current save path of the torrent. Torrent is now switched to Manual mode. Torrent: &quot;%1&quot;. Category: &quot;%2&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4720"/>
        <source>Successfully parsed the IP filter file. Number of rules applied: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4730"/>
        <source>Failed to parse the IP filter file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4919"/>
        <source>Restored torrent. Torrent: &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4923"/>
        <source>Added new torrent. Torrent: &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4929"/>
        <source>Torrent errored. Torrent: &quot;%1&quot;. Error: &quot;%2&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4968"/>
        <location filename="../base/bittorrent/session.cpp" line="5017"/>
        <source>Removed torrent. Torrent: &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4988"/>
        <source>Removed torrent and deleted its content. Torrent: &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="5011"/>
        <source>Removed torrent but failed to delete its content. Torrent: &quot;%1&quot;. Error: &quot;%2&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="5059"/>
        <source>File error alert. Torrent: &quot;%1&quot;. File: &quot;%2&quot;. Reason: &quot;%3&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="5070"/>
        <source>UPnP/NAT-PMP port mapping failed. Message: &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="5076"/>
        <source>UPnP/NAT-PMP port mapping succeeded. Message: &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="5085"/>
        <source>IP filter</source>
        <comment>this peer was blocked. Reason: IP filter.</comment>
        <translation>Filtro de IP</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="5088"/>
        <source>port filter</source>
        <comment>this peer was blocked. Reason: port filter.</comment>
        <translation>Filtro da porta</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="5091"/>
        <source>%1 mixed mode restrictions</source>
        <comment>this peer was blocked. Reason: I2P mixed mode restrictions.</comment>
        <translation>%1 restrições do modo misto</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="5094"/>
        <source>use of privileged port</source>
        <comment>this peer was blocked. Reason: use of privileged port.</comment>
        <translation>uso da porta privilegiada</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="5097"/>
        <source>%1 is disabled</source>
        <comment>this peer was blocked. Reason: uTP is disabled.</comment>
        <translation>%1 está desativado</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="5100"/>
        <source>%1 is disabled</source>
        <comment>this peer was blocked. Reason: TCP is disabled.</comment>
        <translation>%1 está desativado</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="5124"/>
        <source>URL seed DNS lookup failed. Torrent: &quot;%1&quot;. URL: &quot;%2&quot;. Error: &quot;%3&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="5130"/>
        <source>Received error message from URL seed. Torrent: &quot;%1&quot;. URL: &quot;%2&quot;. Message: &quot;%3&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="5139"/>
        <source>Successfully listening on IP. IP: &quot;%1&quot;. Port: &quot;%2/%3&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="5149"/>
        <source>Failed to listen on IP. IP: &quot;%1&quot;. Port: &quot;%2/%3&quot;. Reason: &quot;%4&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="5157"/>
        <source>Detected external IP. IP: &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="5246"/>
        <source>Error: Internal alert queue is full and alerts are dropped, you might see degraded performance. Dropped alert type: &quot;%1&quot;. Message: &quot;%2&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="5268"/>
        <source>Moved torrent successfully. Torrent: &quot;%1&quot;. Destination: &quot;%2&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="5290"/>
        <source>Failed to move torrent. Torrent: &quot;%1&quot;. Source: &quot;%2&quot;. Destination: &quot;%3&quot;. Reason: &quot;%4&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="5329"/>
        <source>SOCKS5 proxy error. Message: &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Torrent errored. Torrent: &quot;%1&quot;. Error: %2.</source>
        <translation type="vanished">Torrent com erro. Torrent: &quot;%1&quot;. Erro: %2.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from the transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation type="vanished">&apos;%1&apos; foi removido da lista de transferências.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from the transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation type="vanished">&apos;%1&apos; foi removido da lista de transferências e do disco rígido.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; was removed from the transfer list but the files couldn&apos;t be deleted. Error: %2</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation type="vanished">&apos;%1&apos; foi removido da lista de transferências mas os arquivos não puderam ser apagados. Erro: %2</translation>
    </message>
    <message>
        <source>File error alert. Torrent: &quot;%1&quot;. File: &quot;%2&quot;. Reason: %3</source>
        <translation type="vanished">Alerta de erro do arquivo. Torrent: &quot;%1&quot;. Arquivo: &quot;%2&quot;. Motivo: %3</translation>
    </message>
    <message>
        <source>URL seed name lookup failed. Torrent: &quot;%1&quot;. URL: &quot;%2&quot;. Error: &quot;%3&quot;</source>
        <translation type="vanished">A procura de nomes de seeds por URL falhou: Torrent: &apos;%1&apos;, URL: &quot;%2&quot;. Erro: &quot;%3&quot;</translation>
    </message>
    <message>
        <source>Received error message from a URL seed. Torrent: &quot;%1&quot;. URL: &quot;%2&quot;. Message: &quot;%3&quot;</source>
        <translation type="vanished">Mensagem de erro recebida de uma URL do seed. Torrent: &apos;%1&apos;, URL: &quot;%2&quot;. Mensagem: &quot;%3&quot;</translation>
    </message>
    <message>
        <source>Successfully listening on IP: %1, port: %2/%3</source>
        <comment>e.g: Successfully listening on IP: 192.168.0.1, port: TCP/6881</comment>
        <translation type="vanished">Escutando com sucesso o IP: %1, porta: %2/%3</translation>
    </message>
    <message>
        <source>Failed to listen on IP: %1, port: %2/%3. Reason: %4</source>
        <comment>e.g: Failed to listen on IP: 192.168.0.1, port: TCP/6881. Reason: already in use</comment>
        <translation type="vanished">Falhou em escutar o IP: %1, porta: %2/%3. Motivo: %4</translation>
    </message>
    <message>
        <source>Detected external IP: %1</source>
        <comment>e.g. Detected external IP: 1.1.1.1</comment>
        <translation type="vanished">IP externo detectado: %1</translation>
    </message>
    <message>
        <source>Error: Internal alert queue full and alerts were dropped, you might see degraded performance. Dropped alert types: %1. Message: %2</source>
        <translation type="vanished">Erro: a fila de alertas internos está cheia e os alertas foram descartados, você poderia ver uma performance degradada. Tipos de alerta descartados: %1. Mensagem: %2</translation>
    </message>
    <message>
        <source>&quot;%1&quot; is successfully moved to &quot;%2&quot;.</source>
        <translation type="vanished">&quot;%1&quot; foi movido com sucesso pra &quot;%2&quot;.</translation>
    </message>
    <message>
        <source>Failed to move &quot;%1&quot; from &quot;%2&quot; to &quot;%3&quot;. Reason: %4.</source>
        <translation type="vanished">Falhou em mover o &quot;%1&quot; de &quot;%2&quot; pra &quot;%3&quot;. Motivo: %4.</translation>
    </message>
    <message>
        <source>SOCKS5 proxy error. Message: %1</source>
        <translation type="vanished">Erro da proxy SOCKS5. Mensagem: %1</translation>
    </message>
    <message>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation type="vanished">Baixando &apos;%1&apos;, por favor espere...</translation>
    </message>
    <message>
        <source>The network interface defined is invalid: %1</source>
        <translation type="vanished">A interface de rede definida é inválida: %1</translation>
    </message>
    <message>
        <source>Peer ID: </source>
        <translation type="vanished">ID do Peer: </translation>
    </message>
    <message>
        <source>HTTP User-Agent is &apos;%1&apos;</source>
        <translation type="vanished">O usuário agente HTTP é &apos;%1&apos;</translation>
    </message>
    <message>
        <source>DHT support [%1]</source>
        <translation type="vanished">Suporte a DHT [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="575"/>
        <location filename="../base/bittorrent/session.cpp" line="590"/>
        <location filename="../base/bittorrent/session.cpp" line="1157"/>
        <location filename="../base/bittorrent/session.cpp" line="1158"/>
        <location filename="../base/bittorrent/session.cpp" line="1159"/>
        <location filename="../base/bittorrent/session.cpp" line="1160"/>
        <location filename="../base/bittorrent/session.cpp" line="1161"/>
        <location filename="../base/bittorrent/session.cpp" line="2991"/>
        <location filename="../base/bittorrent/session.cpp" line="3589"/>
        <source>ON</source>
        <translation>LIGADO</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="575"/>
        <location filename="../base/bittorrent/session.cpp" line="590"/>
        <location filename="../base/bittorrent/session.cpp" line="1157"/>
        <location filename="../base/bittorrent/session.cpp" line="1158"/>
        <location filename="../base/bittorrent/session.cpp" line="1159"/>
        <location filename="../base/bittorrent/session.cpp" line="1160"/>
        <location filename="../base/bittorrent/session.cpp" line="1161"/>
        <location filename="../base/bittorrent/session.cpp" line="2991"/>
        <location filename="../base/bittorrent/session.cpp" line="3589"/>
        <source>OFF</source>
        <translation>DESLIGADO</translation>
    </message>
    <message>
        <source>Local Peer Discovery support [%1]</source>
        <translation type="vanished">Suporte a descoberta de peers locais [%1]</translation>
    </message>
    <message>
        <source>PeX support [%1]</source>
        <translation type="vanished">Suporte ao PeX [%1]</translation>
    </message>
    <message>
        <source>Could not get GUID of network interface: %1</source>
        <translation type="vanished">Não pôde obter o GUID da interface de rede: %1</translation>
    </message>
    <message>
        <source>Trying to listen on: %1</source>
        <comment>e.g: Trying to listen on: 192.168.0.1:6881</comment>
        <translation type="vanished">Tentando escutar em: %1</translation>
    </message>
    <message>
        <source>&apos;%1&apos; reached the maximum ratio you set. Removed.</source>
        <translation type="vanished">&apos;%1&apos; alcançou a proporção máxima que você definiu. Removido.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; reached the maximum ratio you set. Paused.</source>
        <translation type="vanished">&apos;%1&apos; alcançou a proporção máxima que você definiu. Pausado.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; reached the maximum seeding time you set. Removed.</source>
        <translation type="vanished">&apos;%1&apos; alcançou o tempo máximo de seeding que você definiu. Removido.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; reached the maximum seeding time you set. Paused.</source>
        <translation type="vanished">&apos;%1&apos; alcançou o tempo máximo de seeding que você definiu. Pausado.</translation>
    </message>
    <message>
        <source>Tracker &apos;%1&apos; was added to torrent &apos;%2&apos;</source>
        <translation type="vanished">O tracker &apos;%1&apos; foi adicionado ao torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <source>Tracker &apos;%1&apos; was deleted from torrent &apos;%2&apos;</source>
        <translation type="vanished">O tracker &apos;%1&apos; foi apagado do torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <source>URL seed &apos;%1&apos; was added to torrent &apos;%2&apos;</source>
        <translation type="vanished">A URL do seed &apos;%1&apos; foi adicionada ao torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <source>URL seed &apos;%1&apos; was removed from torrent &apos;%2&apos;</source>
        <translation type="vanished">A URL do seed &apos;%1&apos; foi removida do torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <source>Unable to resume torrent &apos;%1&apos;.</source>
        <comment>e.g: Unable to resume torrent &apos;hash&apos;.</comment>
        <translation type="vanished">Incapaz de resumir o torrent &apos;%1&apos;.</translation>
    </message>
    <message>
        <source>Successfully parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation type="vanished">Analisou com sucesso o filtro de IP fornecido: %1 regras foram aplicadas.</translation>
    </message>
    <message>
        <source>Error: Failed to parse the provided IP filter.</source>
        <translation type="vanished">Erro: Falhou em analisar o filtro de IP fornecido.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; restored.</source>
        <comment>&apos;torrent name&apos; restored.</comment>
        <translation type="vanished">&apos;%1&apos; restaurado.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;torrent name&apos; was added to download list.</comment>
        <translation type="vanished">&apos;%1&apos; adicionado a lista de downloads.</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation type="vanished">UPnP/NAT-PMP: Falha no mapeamento da porta, mensagem: %1</translation>
    </message>
    <message>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation type="vanished">UPnP/NAT-PMP: Mapeamento bem sucedido da porta, mensagem: %1</translation>
    </message>
</context>
<context>
    <name>BitTorrent::TorrentCreatorThread</name>
    <message>
        <location filename="../base/bittorrent/torrentcreatorthread.cpp" line="102"/>
        <source>Operation aborted</source>
        <translation>Operação abortada</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentcreatorthread.cpp" line="219"/>
        <location filename="../base/bittorrent/torrentcreatorthread.cpp" line="223"/>
        <source>Create new torrent file failed. Reason: %1.</source>
        <translation>Falhou em criar um novo arquivo torrent. Motivo: %1.</translation>
    </message>
</context>
<context>
    <name>BitTorrent::TorrentImpl</name>
    <message>
        <location filename="../base/bittorrent/torrentimpl.cpp" line="703"/>
        <source>Failed to add peer &quot;%1&quot; to torrent &quot;%2&quot;. Reason: %3</source>
        <translation>Falhou em adicionar o peer &quot;%1&quot; ao torrent &quot;%2&quot;. Motivo: %3</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentimpl.cpp" line="708"/>
        <source>Peer &quot;%1&quot; is added to torrent &quot;%2&quot;</source>
        <translation>O peer &quot;%1&quot; foi adicionado ao torrent &quot;%2&quot;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentimpl.cpp" line="1053"/>
        <source>Couldn&apos;t write to file.</source>
        <translation>Não pôde gravar no arquivo.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentimpl.cpp" line="1054"/>
        <source>Torrent is now in &quot;upload only&quot; mode.</source>
        <translation>O torrent está agora no modo &quot;somente upload&quot;.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentimpl.cpp" line="1055"/>
        <source>Reason:</source>
        <translation>Motivo:</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentimpl.cpp" line="1459"/>
        <source>Download first and last piece first: %1, torrent: &apos;%2&apos;</source>
        <translation>Baixar primeiro os primeiros e os últimos pedaços: %1, torrent: &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentimpl.cpp" line="1460"/>
        <source>On</source>
        <translation>Ligado</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentimpl.cpp" line="1460"/>
        <source>Off</source>
        <translation>Desligado</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentimpl.cpp" line="1856"/>
        <source>File sizes mismatch for torrent &apos;%1&apos;. Cannot proceed further.</source>
        <translation>O tamanho dos arquivos não combina com o torrent &apos;%1&apos;. Não pôde prosseguir adiante.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentimpl.cpp" line="1860"/>
        <source>Fast resume data was rejected for torrent &apos;%1&apos;. Reason: %2. Checking again...</source>
        <translation>O resumo rápido de dados foi rejeitado pro torrent &apos;%1&apos;. Motivo: %2. Verificando de novo...</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentimpl.cpp" line="1905"/>
        <source>File rename failed. Torrent: &quot;%1&quot;, file: &quot;%2&quot;, reason: &quot;%3&quot;</source>
        <translation>Falhou em renomear o arquivo. Torrent: &quot;%1&quot;, arquivo: &quot;%2&quot;, motivo: &quot;%3&quot;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentimpl.cpp" line="1959"/>
        <source>Performance alert: %1. More info: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Performance alert: </source>
        <translation type="vanished">Alerta de performance: </translation>
    </message>
</context>
<context>
    <name>BitTorrent::Tracker</name>
    <message>
        <location filename="../base/bittorrent/tracker.cpp" line="226"/>
        <source>Embedded Tracker: Now listening on IP: %1, port: %2</source>
        <translation>Tracker embutido: Agora escutando o IP: %1, porta %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/tracker.cpp" line="231"/>
        <source>Embedded Tracker: Unable to bind to IP: %1, port: %2. Reason: %3</source>
        <translation>Tracker embutido: Incapaz de vincular ao IP: %1, porta: %2. Motivo: %3</translation>
    </message>
</context>
<context>
    <name>CategoryFilterModel</name>
    <message>
        <location filename="../gui/categoryfiltermodel.cpp" line="244"/>
        <source>Categories</source>
        <translation>Categorias</translation>
    </message>
    <message>
        <location filename="../gui/categoryfiltermodel.cpp" line="402"/>
        <source>All</source>
        <translation>Tudo</translation>
    </message>
    <message>
        <location filename="../gui/categoryfiltermodel.cpp" line="408"/>
        <source>Uncategorized</source>
        <translation>Sem categoria</translation>
    </message>
</context>
<context>
    <name>CategoryFilterWidget</name>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="112"/>
        <source>Add category...</source>
        <translation>Adicionar categoria...</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="120"/>
        <source>Add subcategory...</source>
        <translation>Adicionar sub-categoria...</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="124"/>
        <source>Edit category...</source>
        <translation>Editar categoria...</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="126"/>
        <source>Remove category</source>
        <translation>Remover categoria</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="130"/>
        <source>Remove unused categories</source>
        <translation>Remover categorias não usadas</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="133"/>
        <source>Resume torrents</source>
        <translation>Resumir torrents</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="135"/>
        <source>Pause torrents</source>
        <translation>Pausar torrents</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="137"/>
        <source>Delete torrents</source>
        <translation>Apagar torrents</translation>
    </message>
</context>
<context>
    <name>CookiesDialog</name>
    <message>
        <location filename="../gui/cookiesdialog.ui" line="14"/>
        <source>Manage Cookies</source>
        <translation>Gerenciar Cookies</translation>
    </message>
</context>
<context>
    <name>CookiesModel</name>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="51"/>
        <source>Domain</source>
        <translation>Domínio</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="53"/>
        <source>Path</source>
        <translation>Caminho</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="55"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="57"/>
        <source>Value</source>
        <translation>Valor</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="59"/>
        <source>Expiration Date</source>
        <translation>Data de expiração</translation>
    </message>
</context>
<context>
    <name>DeletionConfirmationDialog</name>
    <message>
        <location filename="../gui/deletionconfirmationdialog.ui" line="20"/>
        <source>Deletion confirmation</source>
        <translation>Confirmação de exclusão</translation>
    </message>
    <message>
        <location filename="../gui/deletionconfirmationdialog.ui" line="67"/>
        <source>Remember choice</source>
        <translation>Lembrar escolha</translation>
    </message>
    <message>
        <location filename="../gui/deletionconfirmationdialog.ui" line="91"/>
        <source>Also delete the files on the hard disk</source>
        <translation>Apagar também os arquivos no disco rígido</translation>
    </message>
    <message>
        <location filename="../gui/deletionconfirmationdialog.cpp" line="45"/>
        <source>Are you sure you want to delete &apos;%1&apos; from the transfer list?</source>
        <comment>Are you sure you want to delete &apos;ubuntu-linux-iso&apos; from the transfer list?</comment>
        <translation>Você tem certeza que você quer apagar o &apos;%1&apos; da lista de transferências?</translation>
    </message>
    <message>
        <location filename="../gui/deletionconfirmationdialog.cpp" line="47"/>
        <source>Are you sure you want to delete these %1 torrents from the transfer list?</source>
        <comment>Are you sure you want to delete these 5 torrents from the transfer list?</comment>
        <translation>Você tem certeza que você quer apagar estes %1 torrents da lista de transferências?</translation>
    </message>
</context>
<context>
    <name>DownloadFromURLDialog</name>
    <message>
        <location filename="../gui/downloadfromurldialog.ui" line="14"/>
        <source>Download from URLs</source>
        <translation>Baixar das URLs</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldialog.ui" line="26"/>
        <source>Add torrent links</source>
        <translation>Adicionar links dos torrents</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldialog.ui" line="48"/>
        <source>One link per line (HTTP links, Magnet links and info-hashes are supported)</source>
        <translation>Um link por linha (links HTTP, links magnet e hashes das informações são suportados)</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldialog.cpp" line="70"/>
        <source>Download</source>
        <translation>Download</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldialog.cpp" line="123"/>
        <source>No URL entered</source>
        <translation>Nenhuma URL inserida</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldialog.cpp" line="123"/>
        <source>Please type at least one URL.</source>
        <translation>Por favor digite pelo menos uma URL.</translation>
    </message>
</context>
<context>
    <name>DownloadHandlerImpl</name>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="137"/>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="145"/>
        <source>I/O Error: %1</source>
        <translation>Erro de E/S: %1</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="164"/>
        <source>The file size (%1) exceeds the download limit (%2)</source>
        <translation>O tamanho do arquivo (%1) excede o limite de download (%2)</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="175"/>
        <source>Exceeded max redirections (%1)</source>
        <translation>Máximo de redirecionamentos excedidos (%1)</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="191"/>
        <source>Redirected to magnet URI</source>
        <translation>Re-direcionou pra URI magnet</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="224"/>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation>O nome do hospedeiro remoto não foi achado (nome do hospedeiro inválido)</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="226"/>
        <source>The operation was canceled</source>
        <translation>A operação foi cancelada</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="228"/>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation>O servidor remoto fechou a conexão prematuramente antes que a resposta inteira fosse recebida e processada</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="230"/>
        <source>The connection to the remote server timed out</source>
        <translation>Acabou o tempo da conexão com o servidor remoto</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="232"/>
        <source>SSL/TLS handshake failed</source>
        <translation>O handshake do SSL/TLS falhou</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="234"/>
        <source>The remote server refused the connection</source>
        <translation>O servidor remoto recusou a conexão</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="236"/>
        <source>The connection to the proxy server was refused</source>
        <translation>A conexão com o servidor proxy foi recusada</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="238"/>
        <source>The proxy server closed the connection prematurely</source>
        <translation>O servidor proxy fechou a conexão prematuramente</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="240"/>
        <source>The proxy host name was not found</source>
        <translation>O nome do hospedeiro proxy não foi achado</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="242"/>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation>Acabou o tempo da conexão com o proxy ou o proxy não respondeu a tempo a requisição enviada</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="244"/>
        <source>The proxy requires authentication in order to honor the request but did not accept any credentials offered</source>
        <translation>O proxy requer autenticação de modo a honrar a requisição mas não aceitou quaisquer credenciais oferecidas</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="246"/>
        <source>The access to the remote content was denied (401)</source>
        <translation>O acesso ao conteúdo remoto foi negado (401)</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="248"/>
        <source>The operation requested on the remote content is not permitted</source>
        <translation>A operação requisitada no conteúdo remoto não é permitida</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="250"/>
        <source>The remote content was not found at the server (404)</source>
        <translation>O conteúdo remoto não foi achado no servidor (404)</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="252"/>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation>O servidor remoto requer autenticação pra servir o conteúdo mas as credenciais fornecidas não foram aceitas</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="254"/>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation>A API de acesso a rede não pôde honrar a requisição porque o protocolo não é conhecido</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="256"/>
        <source>The requested operation is invalid for this protocol</source>
        <translation>A operação requisitada é inválida pra este protocolo</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="258"/>
        <source>An unknown network-related error was detected</source>
        <translation>Um erro desconhecido relacionado a rede foi detectado</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="260"/>
        <source>An unknown proxy-related error was detected</source>
        <translation>Um erro desconhecido relacionado ao proxy foi detectado</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="262"/>
        <source>An unknown error related to the remote content was detected</source>
        <translation>Um erro desconhecido relacionado ao conteúdo remoto foi detectado</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="264"/>
        <source>A breakdown in protocol was detected</source>
        <translation>Um colapso no protocolo foi detectado</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandlerimpl.cpp" line="266"/>
        <source>Unknown error</source>
        <translation>Erro desconhecido</translation>
    </message>
</context>
<context>
    <name>DownloadedPiecesBar</name>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="193"/>
        <source>Missing pieces</source>
        <translation>Pedaços ausentes</translation>
    </message>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="194"/>
        <source>Partial pieces</source>
        <translation>Pedaços parciais</translation>
    </message>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="195"/>
        <source>Completed pieces</source>
        <translation>Pedaços completados</translation>
    </message>
</context>
<context>
    <name>ExecutionLogWidget</name>
    <message>
        <location filename="../gui/executionlogwidget.ui" line="36"/>
        <source>General</source>
        <translation>Geral</translation>
    </message>
    <message>
        <location filename="../gui/executionlogwidget.ui" line="42"/>
        <source>Blocked IPs</source>
        <translation>IPs Bloqueados</translation>
    </message>
    <message>
        <location filename="../gui/executionlogwidget.cpp" line="95"/>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <location filename="../gui/executionlogwidget.cpp" line="99"/>
        <source>Clear</source>
        <translation>Limpar</translation>
    </message>
</context>
<context>
    <name>FeedListWidget</name>
    <message>
        <location filename="../gui/rss/feedlistwidget.cpp" line="97"/>
        <source>RSS feeds</source>
        <translation>Feeds do RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/feedlistwidget.cpp" line="109"/>
        <location filename="../gui/rss/feedlistwidget.cpp" line="153"/>
        <source>Unread  (%1)</source>
        <translation>Não lidos (%1)</translation>
    </message>
</context>
<context>
    <name>FileLogger</name>
    <message>
        <location filename="../app/filelogger.cpp" line="185"/>
        <source>An error occurred while trying to open the log file. Logging to file is disabled.</source>
        <translation>Um erro ocorreu enquanto tentava abrir o arquivo do log. O registro do log no arquivo está desativado.</translation>
    </message>
</context>
<context>
    <name>FileSystemPathEdit</name>
    <message>
        <location filename="../gui/fspathedit.cpp" line="59"/>
        <source>...</source>
        <comment>Launch file dialog button text (brief)</comment>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit.cpp" line="61"/>
        <source>&amp;Browse...</source>
        <comment>Launch file dialog button text (full)</comment>
        <translation>&amp;Procurar...</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit.cpp" line="63"/>
        <source>Choose a file</source>
        <comment>Caption for file open/save dialog</comment>
        <translation>Escolha um arquivo</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit.cpp" line="65"/>
        <source>Choose a folder</source>
        <comment>Caption for directory open dialog</comment>
        <translation>Escolha uma pasta</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit.cpp" line="104"/>
        <source>Any file</source>
        <translation>Qualquer arquivo</translation>
    </message>
</context>
<context>
    <name>FilterParserThread</name>
    <message>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="132"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="296"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="477"/>
        <source>I/O Error: Could not open IP filter file in read mode.</source>
        <translation>Erro de E/S: Não pôde abrir o arquivo do filtro de IP no modo leitura.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="227"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="372"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="382"/>
        <source>IP filter line %1 is malformed.</source>
        <translation>A linha %1 do filtro de IP está mal formada.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="237"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="392"/>
        <source>IP filter line %1 is malformed. Start IP of the range is malformed.</source>
        <translation>A linha %1 do filtro de IP está mal formada. O IP inicial do alcance está mal formado.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="247"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="402"/>
        <source>IP filter line %1 is malformed. End IP of the range is malformed.</source>
        <translation>A linha %1 do filtro de IP está mal formada. O IP final do alcance está mal formado.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="256"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="411"/>
        <source>IP filter line %1 is malformed. One IP is IPv4 and the other is IPv6!</source>
        <translation>A linha %1 do filtro de IP está mal formada. Um IP é IPv4 e o outro é IPv6!</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="272"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="426"/>
        <source>IP filter exception thrown for line %1. Exception is: %2</source>
        <translation>Exceção do filtro de IP lançada para a linha %1. A exceção é: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="282"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="436"/>
        <source>%1 extra IP filter parsing errors occurred.</source>
        <comment>513 extra IP filter parsing errors occurred.</comment>
        <translation>%1 erros de análise dos filtros extras dos IPs ocorreram.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="489"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="504"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="528"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="539"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="550"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="562"/>
        <location filename="../base/bittorrent/filterparserthread.cpp" line="584"/>
        <source>Parsing Error: The filter file is not a valid PeerGuardian P2B file.</source>
        <translation>Erro de análise: O arquivo de filtro não é um arquivo P2B válido do PeerGuardian.</translation>
    </message>
</context>
<context>
    <name>GeoIPDatabase</name>
    <message>
        <location filename="../base/net/geoipdatabase.cpp" line="96"/>
        <location filename="../base/net/geoipdatabase.cpp" line="130"/>
        <source>Unsupported database file size.</source>
        <translation>Tamanho do arquivo do banco de dados não suportado.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipdatabase.cpp" line="239"/>
        <source>Metadata error: &apos;%1&apos; entry not found.</source>
        <translation>Erro dos metadados: Entrada &apos;%1&apos; não encontrada.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipdatabase.cpp" line="240"/>
        <source>Metadata error: &apos;%1&apos; entry has invalid type.</source>
        <translation>Erro dos metadados: A entrada &apos;%1&apos; tem um tipo inválido.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipdatabase.cpp" line="250"/>
        <source>Unsupported database version: %1.%2</source>
        <translation>Versão do banco de dados não suportada: %1.%2</translation>
    </message>
    <message>
        <location filename="../base/net/geoipdatabase.cpp" line="258"/>
        <source>Unsupported IP version: %1</source>
        <translation>Versão do IP não suportada: %1</translation>
    </message>
    <message>
        <location filename="../base/net/geoipdatabase.cpp" line="266"/>
        <source>Unsupported record size: %1</source>
        <translation>Tamanho de gravação não suportado: %1</translation>
    </message>
    <message>
        <location filename="../base/net/geoipdatabase.cpp" line="297"/>
        <source>Database corrupted: no data section found.</source>
        <translation>Banco de dados corrompido: nenhuma seção de dados achada.</translation>
    </message>
</context>
<context>
    <name>Http::Connection</name>
    <message>
        <location filename="../base/http/connection.cpp" line="82"/>
        <source>Http request size exceeds limitation, closing socket. Limit: %1, IP: %2</source>
        <translation>O tamanho da requisição do HTTP excede o limite, fechando o soquete. Limite: %1, IP: %2</translation>
    </message>
    <message>
        <location filename="../base/http/connection.cpp" line="96"/>
        <source>Bad Http request, closing socket. IP: %1</source>
        <translation>Requisição ruim do HTTP, fechando o soquete. IP: %1</translation>
    </message>
</context>
<context>
    <name>IPSubnetWhitelistOptionsDialog</name>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.ui" line="14"/>
        <source>List of whitelisted IP subnets</source>
        <translation>Lista de sub-redes dos IPs na lista branca</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.ui" line="53"/>
        <source>Example: 172.17.32.0/24, fdff:ffff:c8::/40</source>
        <translation>Exemplo: 172.17.32.0/24, fdff:ffff:c8::/40</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.ui" line="64"/>
        <source>Add subnet</source>
        <translation>Adicionar sub-rede</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.ui" line="71"/>
        <source>Delete</source>
        <translation>Apagar</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.cpp" line="96"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.cpp" line="96"/>
        <source>The entered subnet is invalid.</source>
        <translation>A sub-rede inserida é inválida.</translation>
    </message>
</context>
<context>
    <name>LogPeerModel</name>
    <message>
        <location filename="../gui/log/logmodel.cpp" line="178"/>
        <source>%1 was blocked. Reason: %2.</source>
        <comment>0.0.0.0 was blocked. Reason: reason for blocking.</comment>
        <translation>%1 foi bloqueado. Motivo: %2.</translation>
    </message>
    <message>
        <location filename="../gui/log/logmodel.cpp" line="179"/>
        <source>%1 was banned</source>
        <comment>0.0.0.0 was banned</comment>
        <translation>%1 foi banido</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../gui/mainwindow.ui" line="43"/>
        <source>&amp;Edit</source>
        <translation>&amp;Editar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="68"/>
        <source>&amp;Tools</source>
        <translation>&amp;Ferramentas</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="89"/>
        <source>&amp;File</source>
        <translation>&amp;Arquivo</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="58"/>
        <source>&amp;Help</source>
        <translation>&amp;Ajuda</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="72"/>
        <source>On Downloads &amp;Done</source>
        <translation>Com os &amp;Downloads Concluídos</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="99"/>
        <source>&amp;View</source>
        <translation>&amp;Visualizar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="181"/>
        <source>&amp;Options...</source>
        <translation>&amp;Opções...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="191"/>
        <source>&amp;Resume</source>
        <translation>&amp;Resumir</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="224"/>
        <source>Torrent &amp;Creator</source>
        <translation>Criador de &amp;Torrents</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="286"/>
        <location filename="../gui/mainwindow.ui" line="289"/>
        <source>Alternative Speed Limits</source>
        <translation>Limites de Velocidade Alternativos</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="297"/>
        <source>&amp;Top Toolbar</source>
        <translation>&amp;Barra de Ferramentas no Topo</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="300"/>
        <source>Display Top Toolbar</source>
        <translation>Exibir Barra de Ferramentas no Topo</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="308"/>
        <source>Status &amp;Bar</source>
        <translation>Barra de &amp;Status</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="316"/>
        <source>Filters Sidebar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="324"/>
        <source>S&amp;peed in Title Bar</source>
        <translation>V&amp;elocidade na Barra Título</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="327"/>
        <source>Show Transfer Speed in Title Bar</source>
        <translation>Mostrar Velocidade de Transferência na Barra Título</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="335"/>
        <source>&amp;RSS Reader</source>
        <translation>&amp;Leitor de RSS</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="343"/>
        <source>Search &amp;Engine</source>
        <translation>Motor de &amp;Busca</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="348"/>
        <source>L&amp;ock qBittorrent</source>
        <translation>T&amp;ravar o qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="359"/>
        <source>Do&amp;nate!</source>
        <translation>Do&amp;ar!</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="402"/>
        <source>&amp;Do nothing</source>
        <translation>&amp;Não fazer nada</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="478"/>
        <source>Close Window</source>
        <translation>Fechar Janela</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="201"/>
        <source>R&amp;esume All</source>
        <translation>R&amp;esume Todos</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="430"/>
        <source>Manage Cookies...</source>
        <translation>Gerenciar Cookies...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="433"/>
        <source>Manage stored network cookies</source>
        <translation>Gerenciar cookies armazenados da rede</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="449"/>
        <source>Normal Messages</source>
        <translation>Mensagens normais</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="457"/>
        <source>Information Messages</source>
        <translation>Mensagens de informação</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="465"/>
        <source>Warning Messages</source>
        <translation>Mensagens de aviso</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="473"/>
        <source>Critical Messages</source>
        <translation>Mensagens críticas</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="103"/>
        <source>&amp;Log</source>
        <translation>&amp;Log</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="234"/>
        <source>Set Global Speed Limits...</source>
        <translation>Definir limites globais de velocidade...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="239"/>
        <source>Bottom of Queue</source>
        <translation>Final da fila</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="242"/>
        <source>Move to the bottom of the queue</source>
        <translation>Mover para o final da fila</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="250"/>
        <source>Top of Queue</source>
        <translation>Topo da fila</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="253"/>
        <source>Move to the top of the queue</source>
        <translation>Mover para o topo da fila</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="261"/>
        <source>Move Down Queue</source>
        <translation>Mover pra baixo na fila</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="264"/>
        <source>Move down in the queue</source>
        <translation>Mover pra baixo na fila</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="272"/>
        <source>Move Up Queue</source>
        <translation>Mover pra cima na fila</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="275"/>
        <source>Move up in the queue</source>
        <translation>Mover pra cima na fila</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="370"/>
        <source>&amp;Exit qBittorrent</source>
        <translation>&amp;Sair do qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="378"/>
        <source>&amp;Suspend System</source>
        <translation>&amp;Suspender o sistema</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="386"/>
        <source>&amp;Hibernate System</source>
        <translation>&amp;Hibernar o sistema</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="394"/>
        <source>S&amp;hutdown System</source>
        <translation>D&amp;esligar o sistema</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="417"/>
        <source>&amp;Statistics</source>
        <translation>&amp;Estatísticas</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="422"/>
        <source>Check for Updates</source>
        <translation>Procurar atualizações</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="425"/>
        <source>Check for Program Updates</source>
        <translation>Procurar atualizações do programa</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="186"/>
        <source>&amp;About</source>
        <translation>&amp;Sobre</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="196"/>
        <source>&amp;Pause</source>
        <translation>&amp;Pausar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="211"/>
        <source>&amp;Delete</source>
        <translation>&amp;Apagar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="206"/>
        <source>P&amp;ause All</source>
        <translation>P&amp;ausar Todos</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="168"/>
        <source>&amp;Add Torrent File...</source>
        <translation>&amp;Adicionar arquivo torrent...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="171"/>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="176"/>
        <source>E&amp;xit</source>
        <translation>S&amp;air</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="219"/>
        <source>Open URL</source>
        <translation>Abrir URL</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="229"/>
        <source>&amp;Documentation</source>
        <translation>&amp;Documentação</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="351"/>
        <source>Lock</source>
        <translation>Travar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="407"/>
        <location filename="../gui/mainwindow.ui" line="441"/>
        <location filename="../gui/mainwindow.cpp" line="1778"/>
        <source>Show</source>
        <translation>Mostrar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1937"/>
        <source>Check for program updates</source>
        <translation>Procurar atualizações do programa</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="216"/>
        <source>Add Torrent &amp;Link...</source>
        <translation>Adicionar Link do &amp;Torrent...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="362"/>
        <source>If you like qBittorrent, please donate!</source>
        <translation>Se você gosta do qBittorrent por favor doe!</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2015"/>
        <location filename="../gui/mainwindow.cpp" line="2017"/>
        <source>Execution Log</source>
        <translation>Log da Execução</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="663"/>
        <source>Clear the password</source>
        <translation>Limpar a senha</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="179"/>
        <source>&amp;Set Password</source>
        <translation>&amp;Definir senha</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="150"/>
        <source>Preferences</source>
        <translation>Preferências</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="180"/>
        <source>&amp;Clear Password</source>
        <translation>&amp;Limpar senha</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="211"/>
        <source>Filter torrent names...</source>
        <translation>Filtrar nomes dos torrents...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="234"/>
        <source>Transfers</source>
        <translation>Transferências</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="407"/>
        <location filename="../gui/mainwindow.cpp" line="1299"/>
        <source>qBittorrent is minimized to tray</source>
        <translation>O qBittorrent está minimizado no tray</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="407"/>
        <location filename="../gui/mainwindow.cpp" line="1202"/>
        <location filename="../gui/mainwindow.cpp" line="1299"/>
        <source>This behavior can be changed in the settings. You won&apos;t be reminded again.</source>
        <translation>Este comportamento pode ser mudado nas configurações. Você não será lembrado de novo.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="463"/>
        <source>Torrent file association</source>
        <translation>Associação com o arquivo torrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="561"/>
        <source>Icons Only</source>
        <translation>Só ícones</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="562"/>
        <source>Text Only</source>
        <translation>Só texto</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="563"/>
        <source>Text Alongside Icons</source>
        <translation>Texto junto dos ícones</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="564"/>
        <source>Text Under Icons</source>
        <translation>Texto sob os ícones</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="565"/>
        <source>Follow System Style</source>
        <translation>Seguir estilo do sistema</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="646"/>
        <location filename="../gui/mainwindow.cpp" line="1046"/>
        <source>UI lock password</source>
        <translation>Senha da tranca da IU</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="647"/>
        <location filename="../gui/mainwindow.cpp" line="1047"/>
        <source>Please type the UI lock password:</source>
        <translation>Por favor digite a senha da tranca da IU:</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="664"/>
        <source>Are you sure you want to clear the password?</source>
        <translation>Você tem certeza que você quer limpar a senha?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="723"/>
        <source>Use regular expressions</source>
        <translation>Usar expressões regulares</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="745"/>
        <source>Search</source>
        <translation>Busca</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="762"/>
        <source>Transfers (%1)</source>
        <translation>Transferências (%1)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="856"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="856"/>
        <source>Failed to add torrent: %1</source>
        <translation>Falhou em adicionar o torrent: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="863"/>
        <source>Torrent added</source>
        <translation>Torrent adicionado</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="863"/>
        <source>&apos;%1&apos; was added.</source>
        <comment>e.g: xxx.avi was added.</comment>
        <translation>&apos;%1&apos; foi adicionado.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="875"/>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation>Erro de E/S</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="970"/>
        <source>Recursive download confirmation</source>
        <translation>Confirmação do download recursivo</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="976"/>
        <source>Yes</source>
        <translation>Sim</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="977"/>
        <source>No</source>
        <translation>Não</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="978"/>
        <source>Never</source>
        <translation>Nunca</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1069"/>
        <source>qBittorrent was just updated and needs to be restarted for the changes to be effective.</source>
        <translation>O qBittorrent foi atualizado e precisa ser reiniciado para as mudanças serem efetivas.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1202"/>
        <source>qBittorrent is closed to tray</source>
        <translation>O qBittorrent está fechado no tray</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1217"/>
        <source>Some files are currently transferring.</source>
        <translation>Alguns arquivos estão atualmente sendo transferidos.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1217"/>
        <source>Are you sure you want to quit qBittorrent?</source>
        <translation>Você tem certeza que você quer sair do qBittorrent?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1219"/>
        <source>&amp;No</source>
        <translation>&amp;Não</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1220"/>
        <source>&amp;Yes</source>
        <translation>&amp;Sim</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1221"/>
        <source>&amp;Always Yes</source>
        <translation>&amp;Sempre sim</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1242"/>
        <source>qBittorrent is shutting down...</source>
        <translation>O qBittorrent está fechando...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1464"/>
        <source>Options saved.</source>
        <translation>Opções salvas.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1636"/>
        <source>%1/s</source>
        <comment>s is a shorthand for seconds</comment>
        <translation>%1/segs</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1752"/>
        <source>System tray icon is not available, retrying...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1761"/>
        <source>System tray icon is still not available after retries. Disabling it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1874"/>
        <location filename="../gui/mainwindow.cpp" line="1880"/>
        <source>Missing Python Runtime</source>
        <translation>Runtime do python ausente</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1952"/>
        <source>qBittorrent Update Available</source>
        <translation>Atualização do qBittorent disponível</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="869"/>
        <source>&apos;%1&apos; has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation>&apos;%1&apos; terminou de ser baixado.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="876"/>
        <source>An I/O error occurred for torrent &apos;%1&apos;.
 Reason: %2</source>
        <comment>e.g: An error occurred for torrent &apos;xxx.avi&apos;.
 Reason: disk is full.</comment>
        <translation>Ocorreu um erro de E/S no torrent &apos;%1&apos;.
Motivo: %2</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="971"/>
        <source>The torrent &apos;%1&apos; contains torrent files, do you want to proceed with their download?</source>
        <translation>O torrent &apos;%1&apos; contém arquivos torrents, você quer prosseguir com o download deles?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="993"/>
        <source>Couldn&apos;t download file at URL &apos;%1&apos;, reason: %2.</source>
        <translation>Não pôde baixar o arquivo na URL &apos;%1&apos;, motivo: %2.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1875"/>
        <source>Python is required to use the search engine but it does not seem to be installed.
Do you want to install it now?</source>
        <translation>O Python é requerido pra usar o motor de busca mas ele não parece estar instalado.
Você quer instalá-lo agora?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1881"/>
        <source>Python is required to use the search engine but it does not seem to be installed.</source>
        <translation>O Python é requerido pra usar o motor de busca mas ele não parece estar instalado.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1893"/>
        <location filename="../gui/mainwindow.cpp" line="1900"/>
        <source>Old Python Runtime</source>
        <translation>Runtime do python antigo</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1949"/>
        <source>A new version is available.</source>
        <translation>Uma nova versão está disponível.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1950"/>
        <source>Do you want to download %1?</source>
        <translation>Você quer baixar o %1?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1951"/>
        <source>Open changelog...</source>
        <translation>Abrir changelog...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1972"/>
        <source>No updates available.
You are already using the latest version.</source>
        <translation>Não há atualizações disponíveis.
Você já está usando a versão mais recente.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1936"/>
        <source>&amp;Check for Updates</source>
        <translation>&amp;Procurar atualizações</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1894"/>
        <source>Your Python version (%1) is outdated. Minimum requirement: %2.
Do you want to install a newer version now?</source>
        <translation>A sua versão do Python (%1) está desatualizada. Requerimento mínimo: %2.
Você quer instalar uma versão mais nova agora?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1901"/>
        <source>Your Python version (%1) is outdated. Please upgrade to latest version for search engines to work.
Minimum requirement: %2.</source>
        <translation>A sua versão do Python (%1) está desatualizada. Por favor atualize pra versão mais recente pras engines de busca funcionarem.
Requerimento mínimo: %2.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2107"/>
        <source>Checking for Updates...</source>
        <translation>Procurar atualizações...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2108"/>
        <source>Already checking for program updates in the background</source>
        <translation>Já procurando por atualizações do programa em segundo plano</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2141"/>
        <source>Download error</source>
        <translation>Erro do download</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2142"/>
        <source>Python setup could not be downloaded, reason: %1.
Please install it manually.</source>
        <translation>A instalação do Python não pôde ser baixada, motivo: %1.
Por favor instale-o manualmente.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="653"/>
        <location filename="../gui/mainwindow.cpp" line="1055"/>
        <source>Invalid password</source>
        <translation>Senha inválida</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="464"/>
        <source>qBittorrent is not the default application for opening torrent files or Magnet links.
Do you want to make qBittorrent the default application for these?</source>
        <translation>O qBittorrent não é o aplicativo padrão pra abrir arquivos torrent ou links magnet.
Você quer tornar o qBittorrent o aplicativo padrão para estes?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="653"/>
        <source>The password must be at least 3 characters long</source>
        <translation>A senha deve ter pelo menos 3 caracteres</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="689"/>
        <location filename="../gui/mainwindow.cpp" line="702"/>
        <location filename="../gui/mainwindow.cpp" line="704"/>
        <source>RSS (%1)</source>
        <translation>RSS (%1)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="869"/>
        <source>Download completed</source>
        <translation>Download completado</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="992"/>
        <source>URL download error</source>
        <translation>Erro de download da URL</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1055"/>
        <source>The password is invalid</source>
        <translation>A senha é inválida</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1647"/>
        <source>DL speed: %1</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation>Velocidade de download: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1648"/>
        <source>UP speed: %1</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation>Velocidade de upload: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1655"/>
        <source>[D: %1, U: %2] qBittorrent %3</source>
        <comment>D = Download; U = Upload; %3 is qBittorrent version</comment>
        <translation>[D: %1, U: %2] qBittorrent %3</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1778"/>
        <source>Hide</source>
        <translation>Esconder</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1215"/>
        <source>Exiting qBittorrent</source>
        <translation>Saindo do qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1430"/>
        <source>Open Torrent Files</source>
        <translation>Abrir Arquivos Torrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1431"/>
        <source>Torrent Files</source>
        <translation>Arquivos Torrent</translation>
    </message>
</context>
<context>
    <name>Net::DNSUpdater</name>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="187"/>
        <source>Your dynamic DNS was successfully updated.</source>
        <translation>Seu DNS dinâmico foi atualizado com sucesso.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="193"/>
        <source>Dynamic DNS error: The service is temporarily unavailable, it will be retried in 30 minutes.</source>
        <translation>Erro do DNS dinâmico: O serviço está temporariamente indisponível, será tentado de novo em 30 minutos.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="204"/>
        <source>Dynamic DNS error: hostname supplied does not exist under specified account.</source>
        <translation>Erro do DNS dinâmico: o nome do hospedeiro suprido não existe na conta especificada.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="211"/>
        <source>Dynamic DNS error: Invalid username/password.</source>
        <translation>Erro do DNS dinâmico: Nome de usuário/senha inválidos.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="218"/>
        <source>Dynamic DNS error: qBittorrent was blacklisted by the service, please submit a bug report at http://bugs.qbittorrent.org.</source>
        <translation>Erro do DNS dinâmico: o qBittorrent está na lista negra deste serviço. Por favor submeta um relatório do bug em http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="226"/>
        <source>Dynamic DNS error: %1 was returned by the service, please submit a bug report at http://bugs.qbittorrent.org.</source>
        <translation>Erro do DNS dinâmico: %1 foi retornado pelo serviço. Por favor submeta um relatório do bug em http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="234"/>
        <source>Dynamic DNS error: Your username was blocked due to abuse.</source>
        <translation>Erro do DNS dinâmico: Seu nome de usuário foi bloqueado devido a abuso.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="257"/>
        <source>Dynamic DNS error: supplied domain name is invalid.</source>
        <translation>Erro do DNS dinâmico: O nome do domínio suprido é inválido.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="270"/>
        <source>Dynamic DNS error: supplied username is too short.</source>
        <translation>Erro do DNS dinâmico: O nome do usuário suprido é muito curto.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="283"/>
        <source>Dynamic DNS error: supplied password is too short.</source>
        <translation>Erro do DNS dinâmico: A senha suprida é muito curta.</translation>
    </message>
</context>
<context>
    <name>Net::DownloadManager</name>
    <message>
        <location filename="../base/net/downloadmanager.cpp" line="296"/>
        <source>Ignoring SSL error, URL: &quot;%1&quot;, errors: &quot;%2&quot;</source>
        <translation>Ignorando erro do SSL, URL: &quot;%1&quot;, erros: &quot;%2&quot;</translation>
    </message>
</context>
<context>
    <name>Net::GeoIPManager</name>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="390"/>
        <source>Venezuela, Bolivarian Republic of</source>
        <translation>Venezuela, República Bolivariana da</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="403"/>
        <location filename="../base/net/geoipmanager.cpp" line="406"/>
        <source>N/A</source>
        <translation>N/D</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="153"/>
        <source>Andorra</source>
        <translation>Andorra</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="98"/>
        <location filename="../base/net/geoipmanager.cpp" line="451"/>
        <source>IP geolocation database loaded. Type: %1. Build time: %2.</source>
        <translation>Banco de dados da geo-localização dos IPs carregado. Tipo: %1. Data do build: %2.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="104"/>
        <location filename="../base/net/geoipmanager.cpp" line="477"/>
        <source>Couldn&apos;t load IP geolocation database. Reason: %1</source>
        <translation>Não pôde carregar o banco de dados da geo-localização dos IPs. Motivo: %1</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="154"/>
        <source>United Arab Emirates</source>
        <translation>Emirados Árabes Unidos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="155"/>
        <source>Afghanistan</source>
        <translation>Afeganistão</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="156"/>
        <source>Antigua and Barbuda</source>
        <translation>Antígua e Barbuda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="157"/>
        <source>Anguilla</source>
        <translation>Anguilla</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="158"/>
        <source>Albania</source>
        <translation>Albânia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="159"/>
        <source>Armenia</source>
        <translation>Armênia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="160"/>
        <source>Angola</source>
        <translation>Angola</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="161"/>
        <source>Antarctica</source>
        <translation>Antártica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="162"/>
        <source>Argentina</source>
        <translation>Argentina</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="163"/>
        <source>American Samoa</source>
        <translation>Samoa Americana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="164"/>
        <source>Austria</source>
        <translation>Áustria</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="165"/>
        <source>Australia</source>
        <translation>Austrália</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="166"/>
        <source>Aruba</source>
        <translation>Aruba</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="168"/>
        <source>Azerbaijan</source>
        <translation>Azerbaijão</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="169"/>
        <source>Bosnia and Herzegovina</source>
        <translation>Bósnia-Herzegovina</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="170"/>
        <source>Barbados</source>
        <translation>Barbados</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="171"/>
        <source>Bangladesh</source>
        <translation>Bangladesh</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="172"/>
        <source>Belgium</source>
        <translation>Bélgica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="173"/>
        <source>Burkina Faso</source>
        <translation>Burkina Faso</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="174"/>
        <source>Bulgaria</source>
        <translation>Bulgária</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="175"/>
        <source>Bahrain</source>
        <translation>Barém</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="176"/>
        <source>Burundi</source>
        <translation>Burundi</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="177"/>
        <source>Benin</source>
        <translation>Benin</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="179"/>
        <source>Bermuda</source>
        <translation>Bermudas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="180"/>
        <source>Brunei Darussalam</source>
        <translation>Brunei</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="183"/>
        <source>Brazil</source>
        <translation>Brasil</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="184"/>
        <source>Bahamas</source>
        <translation>Bahamas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="185"/>
        <source>Bhutan</source>
        <translation>Butão</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="186"/>
        <source>Bouvet Island</source>
        <translation>Ilha Bouvet</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="187"/>
        <source>Botswana</source>
        <translation>Botsuana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="188"/>
        <source>Belarus</source>
        <translation>Belarus</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="189"/>
        <source>Belize</source>
        <translation>Belize</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="190"/>
        <source>Canada</source>
        <translation>Canadá</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="191"/>
        <source>Cocos (Keeling) Islands</source>
        <translation>Ilhas Cocos (Keeling)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="192"/>
        <source>Congo, The Democratic Republic of the</source>
        <translation>Congo, República Democrática do</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="193"/>
        <source>Central African Republic</source>
        <translation>República Centro-Africana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="194"/>
        <source>Congo</source>
        <translation>Congo</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="195"/>
        <source>Switzerland</source>
        <translation>Suíça</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="197"/>
        <source>Cook Islands</source>
        <translation>Ilhas Cook</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="198"/>
        <source>Chile</source>
        <translation>Chile</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="199"/>
        <source>Cameroon</source>
        <translation>Camarões</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="200"/>
        <source>China</source>
        <translation>China</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="201"/>
        <source>Colombia</source>
        <translation>Colômbia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="202"/>
        <source>Costa Rica</source>
        <translation>Costa Rica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="203"/>
        <source>Cuba</source>
        <translation>Cuba</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="204"/>
        <source>Cape Verde</source>
        <translation>Cabo Verde</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="205"/>
        <source>Curacao</source>
        <translation>Curaçao</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="206"/>
        <source>Christmas Island</source>
        <translation>Ilha Christmas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="207"/>
        <source>Cyprus</source>
        <translation>Chipre</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="208"/>
        <source>Czech Republic</source>
        <translation>República Tcheca</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="209"/>
        <source>Germany</source>
        <translation>Alemanha</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="210"/>
        <source>Djibouti</source>
        <translation>Djibuti</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="211"/>
        <source>Denmark</source>
        <translation>Dinamarca</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="212"/>
        <source>Dominica</source>
        <translation>Dominica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="213"/>
        <source>Dominican Republic</source>
        <translation>República Dominicana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="214"/>
        <source>Algeria</source>
        <translation>Argélia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="215"/>
        <source>Ecuador</source>
        <translation>Equador</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="216"/>
        <source>Estonia</source>
        <translation>Estônia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="217"/>
        <source>Egypt</source>
        <translation>Egito</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="218"/>
        <source>Western Sahara</source>
        <translation>Saara Ocidental</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="219"/>
        <source>Eritrea</source>
        <translation>Eritréia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="220"/>
        <source>Spain</source>
        <translation>Espanha</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="221"/>
        <source>Ethiopia</source>
        <translation>Etiópia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="222"/>
        <source>Finland</source>
        <translation>Finlândia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="223"/>
        <source>Fiji</source>
        <translation>Fiji</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="224"/>
        <source>Falkland Islands (Malvinas)</source>
        <translation>Ilhas Falkland (Malvinas)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="225"/>
        <source>Micronesia, Federated States of</source>
        <translation>Micronésia, Estados Federados da</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="226"/>
        <source>Faroe Islands</source>
        <translation>Ilhas Faroe</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="227"/>
        <source>France</source>
        <translation>França</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="228"/>
        <source>Gabon</source>
        <translation>Gabão</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="229"/>
        <source>United Kingdom</source>
        <translation>Reino Unido</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="230"/>
        <source>Grenada</source>
        <translation>Granada</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="231"/>
        <source>Georgia</source>
        <translation>Geórgia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="232"/>
        <source>French Guiana</source>
        <translation>Guiana Francesa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="234"/>
        <source>Ghana</source>
        <translation>Gana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="235"/>
        <source>Gibraltar</source>
        <translation>Gibraltar</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="236"/>
        <source>Greenland</source>
        <translation>Groenlândia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="237"/>
        <source>Gambia</source>
        <translation>Gâmbia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="238"/>
        <source>Guinea</source>
        <translation>Guiné</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="239"/>
        <source>Guadeloupe</source>
        <translation>Guadalupe</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="240"/>
        <source>Equatorial Guinea</source>
        <translation>Guiné-Equatorial</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="241"/>
        <source>Greece</source>
        <translation>Grécia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="242"/>
        <source>South Georgia and the South Sandwich Islands</source>
        <translation>Ilhas Geórgia do Sul e Sandwich do Sul</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="243"/>
        <source>Guatemala</source>
        <translation>Guatemala</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="244"/>
        <source>Guam</source>
        <translation>Guam</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="245"/>
        <source>Guinea-Bissau</source>
        <translation>Guiné-Bissau</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="246"/>
        <source>Guyana</source>
        <translation>Guiana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="247"/>
        <source>Hong Kong</source>
        <translation>Hong Kong</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="248"/>
        <source>Heard Island and McDonald Islands</source>
        <translation>Ilha Heard e Ilhas McDonald</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="249"/>
        <source>Honduras</source>
        <translation>Honduras</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="250"/>
        <source>Croatia</source>
        <translation>Croácia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="251"/>
        <source>Haiti</source>
        <translation>Haiti</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="252"/>
        <source>Hungary</source>
        <translation>Hungria</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="253"/>
        <source>Indonesia</source>
        <translation>Indonésia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="254"/>
        <source>Ireland</source>
        <translation>Irlanda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="255"/>
        <source>Israel</source>
        <translation>Israel</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="257"/>
        <source>India</source>
        <translation>Índia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="258"/>
        <source>British Indian Ocean Territory</source>
        <translation>Território Britânico do Oceano Índico</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="259"/>
        <source>Iraq</source>
        <translation>Iraque</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="260"/>
        <source>Iran, Islamic Republic of</source>
        <translation>Irã, República Islâmica do</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="261"/>
        <source>Iceland</source>
        <translation>Islândia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="262"/>
        <source>Italy</source>
        <translation>Itália</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="264"/>
        <source>Jamaica</source>
        <translation>Jamaica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="265"/>
        <source>Jordan</source>
        <translation>Jordânia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="266"/>
        <source>Japan</source>
        <translation>Japão</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="267"/>
        <source>Kenya</source>
        <translation>Quênia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="268"/>
        <source>Kyrgyzstan</source>
        <translation>Quirguistão</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="269"/>
        <source>Cambodia</source>
        <translation>Camboja</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="270"/>
        <source>Kiribati</source>
        <translation>Kiribati</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="271"/>
        <source>Comoros</source>
        <translation>Comores</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="272"/>
        <source>Saint Kitts and Nevis</source>
        <translation>São Cristóvão e Nevis</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="273"/>
        <source>Korea, Democratic People&apos;s Republic of</source>
        <translation>Coréia do Norte</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="274"/>
        <source>Korea, Republic of</source>
        <translation>Coréia do Sul</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="275"/>
        <source>Kuwait</source>
        <translation>Kuwait</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="276"/>
        <source>Cayman Islands</source>
        <translation>Ilhas Cayman</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="277"/>
        <source>Kazakhstan</source>
        <translation>Cazaquistão</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="278"/>
        <source>Lao People&apos;s Democratic Republic</source>
        <translation>República Democrática do Povo do Laos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="279"/>
        <source>Lebanon</source>
        <translation>Líbano</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="280"/>
        <source>Saint Lucia</source>
        <translation>Santa Lúcia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="281"/>
        <source>Liechtenstein</source>
        <translation>Liechtenstein</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="282"/>
        <source>Sri Lanka</source>
        <translation>Sri Lanka</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="283"/>
        <source>Liberia</source>
        <translation>Libéria</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="284"/>
        <source>Lesotho</source>
        <translation>Lesoto</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="285"/>
        <source>Lithuania</source>
        <translation>Lituânia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="286"/>
        <source>Luxembourg</source>
        <translation>Luxemburgo</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="287"/>
        <source>Latvia</source>
        <translation>Letônia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="289"/>
        <source>Morocco</source>
        <translation>Marrocos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="290"/>
        <source>Monaco</source>
        <translation>Mônaco</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="291"/>
        <source>Moldova, Republic of</source>
        <translation>Moldávia, República da</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="294"/>
        <source>Madagascar</source>
        <translation>Madagáscar</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="295"/>
        <source>Marshall Islands</source>
        <translation>Ilhas Marshall</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="297"/>
        <source>Mali</source>
        <translation>Mali</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="298"/>
        <source>Myanmar</source>
        <translation>Mianmar</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="299"/>
        <source>Mongolia</source>
        <translation>Mongólia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="301"/>
        <source>Northern Mariana Islands</source>
        <translation>Ilhas Marianas do Norte</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="302"/>
        <source>Martinique</source>
        <translation>Martinica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="303"/>
        <source>Mauritania</source>
        <translation>Mauritânia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="304"/>
        <source>Montserrat</source>
        <translation>Montserrat</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="305"/>
        <source>Malta</source>
        <translation>Malta</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="306"/>
        <source>Mauritius</source>
        <translation>Maurício</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="307"/>
        <source>Maldives</source>
        <translation>Maldivas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="308"/>
        <source>Malawi</source>
        <translation>Malauí</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="309"/>
        <source>Mexico</source>
        <translation>México</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="310"/>
        <source>Malaysia</source>
        <translation>Malásia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="311"/>
        <source>Mozambique</source>
        <translation>Moçambique</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="312"/>
        <source>Namibia</source>
        <translation>Namíbia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="313"/>
        <source>New Caledonia</source>
        <translation>Nova Caledônia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="314"/>
        <source>Niger</source>
        <translation>Níger</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="315"/>
        <source>Norfolk Island</source>
        <translation>Ilha Norfolk</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="316"/>
        <source>Nigeria</source>
        <translation>Nigéria</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="317"/>
        <source>Nicaragua</source>
        <translation>Nicarágua</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="318"/>
        <source>Netherlands</source>
        <translation>Holanda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="319"/>
        <source>Norway</source>
        <translation>Noruega</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="320"/>
        <source>Nepal</source>
        <translation>Nepal</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="321"/>
        <source>Nauru</source>
        <translation>Nauru</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="322"/>
        <source>Niue</source>
        <translation>Niue</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="323"/>
        <source>New Zealand</source>
        <translation>Nova Zelândia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="324"/>
        <source>Oman</source>
        <translation>Omã</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="325"/>
        <source>Panama</source>
        <translation>Panamá</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="326"/>
        <source>Peru</source>
        <translation>Peru</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="327"/>
        <source>French Polynesia</source>
        <translation>Polinésia Francesa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="328"/>
        <source>Papua New Guinea</source>
        <translation>Papua Nova Guiné</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="329"/>
        <source>Philippines</source>
        <translation>Filipinas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="330"/>
        <source>Pakistan</source>
        <translation>Paquistão</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="331"/>
        <source>Poland</source>
        <translation>Polônia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="332"/>
        <source>Saint Pierre and Miquelon</source>
        <translation>São Pierre e Miquelão</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="334"/>
        <source>Puerto Rico</source>
        <translation>Porto Rico</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="336"/>
        <source>Portugal</source>
        <translation>Portugal</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="337"/>
        <source>Palau</source>
        <translation>Palau</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="338"/>
        <source>Paraguay</source>
        <translation>Paraguai</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="339"/>
        <source>Qatar</source>
        <translation>Catar</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="340"/>
        <source>Reunion</source>
        <translation>Reunião</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="341"/>
        <source>Romania</source>
        <translation>Romênia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="343"/>
        <source>Russian Federation</source>
        <translation>Federação Russa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="344"/>
        <source>Rwanda</source>
        <translation>Ruanda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="345"/>
        <source>Saudi Arabia</source>
        <translation>Arábia Saudita</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="346"/>
        <source>Solomon Islands</source>
        <translation>Ilhas Salomão</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="347"/>
        <source>Seychelles</source>
        <translation>Seicheles</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="348"/>
        <source>Sudan</source>
        <translation>Sudão</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="349"/>
        <source>Sweden</source>
        <translation>Suécia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="350"/>
        <source>Singapore</source>
        <translation>Singapura</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="352"/>
        <source>Slovenia</source>
        <translation>Eslovênia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="353"/>
        <source>Svalbard and Jan Mayen</source>
        <translation>Svalbard e Jan Mayen</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="354"/>
        <source>Slovakia</source>
        <translation>Eslováquia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="355"/>
        <source>Sierra Leone</source>
        <translation>Serra Leoa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="356"/>
        <source>San Marino</source>
        <translation>San Marino</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="357"/>
        <source>Senegal</source>
        <translation>Senegal</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="358"/>
        <source>Somalia</source>
        <translation>Somália</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="359"/>
        <source>Suriname</source>
        <translation>Suriname</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="361"/>
        <source>Sao Tome and Principe</source>
        <translation>São Tomé e Príncipe</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="362"/>
        <source>El Salvador</source>
        <translation>El Salvador</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="364"/>
        <source>Syrian Arab Republic</source>
        <translation>Síria, República Árabe da</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="365"/>
        <source>Swaziland</source>
        <translation>Suazilândia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="366"/>
        <source>Turks and Caicos Islands</source>
        <translation>Ilhas Turks e Caicos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="367"/>
        <source>Chad</source>
        <translation>Chade</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="368"/>
        <source>French Southern Territories</source>
        <translation>Territórios Franceses do Sul</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="369"/>
        <source>Togo</source>
        <translation>Togo</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="370"/>
        <source>Thailand</source>
        <translation>Tailândia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="371"/>
        <source>Tajikistan</source>
        <translation>Tadjiquistão</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="372"/>
        <source>Tokelau</source>
        <translation>Toquelau</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="374"/>
        <source>Turkmenistan</source>
        <translation>Turcomenistão</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="375"/>
        <source>Tunisia</source>
        <translation>Tunísia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="376"/>
        <source>Tonga</source>
        <translation>Tonga</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="393"/>
        <source>Vietnam</source>
        <translation>Vietnã</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="431"/>
        <source>Couldn&apos;t download IP geolocation database file. Reason: %1</source>
        <translation>Não pôde baixar o banco de dados da geo-localização dos IPs. Motivo: %1</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="439"/>
        <source>Could not decompress IP geolocation database file.</source>
        <translation>Não pôde descompactar o arquivo do banco de dados da geo-localização dos IPs.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="466"/>
        <source>Couldn&apos;t save downloaded IP geolocation database file. Reason: %1</source>
        <translation>Não pôde salvar o arquivo do banco de dados da geolocalização dos IPs. Motivo: %1</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="462"/>
        <source>Successfully updated IP geolocation database.</source>
        <translation>Banco de dados da geo-localização dos IPs atualizado com sucesso.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="373"/>
        <source>Timor-Leste</source>
        <translation>Timor Leste</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="181"/>
        <source>Bolivia, Plurinational State of</source>
        <translation>Bolívia, Estado Plurinacional da</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="182"/>
        <source>Bonaire, Sint Eustatius and Saba</source>
        <translation>Bonaire, Santo Eustáquio e Saba</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="196"/>
        <source>Cote d&apos;Ivoire</source>
        <translation>Costa do Marfim</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="288"/>
        <source>Libya</source>
        <translation>Líbia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="293"/>
        <source>Saint Martin (French part)</source>
        <translation>Saint Martin (Parte Francesa)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="296"/>
        <source>Macedonia, The Former Yugoslav Republic of</source>
        <translation>Macedônia, A República Iugoslava Formal da</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="300"/>
        <source>Macao</source>
        <translation>Macau</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="333"/>
        <source>Pitcairn</source>
        <translation>Pitcairn</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="335"/>
        <source>Palestine, State of</source>
        <translation>Palestina, Estado da</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="351"/>
        <source>Saint Helena, Ascension and Tristan da Cunha</source>
        <translation>Santa Helena, Ascensão e Tristão da Cunha</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="360"/>
        <source>South Sudan</source>
        <translation>Sudão do Sul</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="363"/>
        <source>Sint Maarten (Dutch part)</source>
        <translation>Sint Maarten (Parte Holandesa)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="377"/>
        <source>Turkey</source>
        <translation>Turquia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="378"/>
        <source>Trinidad and Tobago</source>
        <translation>Trinidad e Tobago</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="379"/>
        <source>Tuvalu</source>
        <translation>Tuvalu</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="380"/>
        <source>Taiwan</source>
        <translation>Taiwan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="381"/>
        <source>Tanzania, United Republic of</source>
        <translation>Tanzânia, República Unida da</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="382"/>
        <source>Ukraine</source>
        <translation>Ucrânia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="383"/>
        <source>Uganda</source>
        <translation>Uganda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="384"/>
        <source>United States Minor Outlying Islands</source>
        <translation>Ilhas Menores Periféricas dos Estados Unidos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="385"/>
        <source>United States</source>
        <translation>Estados Unidos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="386"/>
        <source>Uruguay</source>
        <translation>Uruguai</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="387"/>
        <source>Uzbekistan</source>
        <translation>Uzbequistão</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="388"/>
        <source>Holy See (Vatican City State)</source>
        <translation>Santa Sé (Cidade-Estado do Vaticano)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="389"/>
        <source>Saint Vincent and the Grenadines</source>
        <translation>São Vicente e Granadinas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="391"/>
        <source>Virgin Islands, British</source>
        <translation>Ilhas Virgens Britânicas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="392"/>
        <source>Virgin Islands, U.S.</source>
        <translation>Ilhas Virgens, EUA.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="394"/>
        <source>Vanuatu</source>
        <translation>Vanuatu</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="395"/>
        <source>Wallis and Futuna</source>
        <translation>Wallis e Futuna</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="396"/>
        <source>Samoa</source>
        <translation>Samoa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="397"/>
        <source>Yemen</source>
        <translation>Iêmen</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="398"/>
        <source>Mayotte</source>
        <translation>Mayotte</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="342"/>
        <source>Serbia</source>
        <translation>Sérvia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="399"/>
        <source>South Africa</source>
        <translation>África do Sul</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="400"/>
        <source>Zambia</source>
        <translation>Zâmbia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="292"/>
        <source>Montenegro</source>
        <translation>Montenegro</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="401"/>
        <source>Zimbabwe</source>
        <translation>Zimbábue</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="167"/>
        <source>Aland Islands</source>
        <translation>Ilhas Aland</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="233"/>
        <source>Guernsey</source>
        <translation>Guernsey</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="256"/>
        <source>Isle of Man</source>
        <translation>Ilha de Man</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="263"/>
        <source>Jersey</source>
        <translation>Jersey</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="178"/>
        <source>Saint Barthelemy</source>
        <translation>São Bartolomeu</translation>
    </message>
</context>
<context>
    <name>Net::Smtp</name>
    <message>
        <source>Email Notification Error:</source>
        <translation type="vanished">E-mail de Notificação do Erro:</translation>
    </message>
    <message>
        <location filename="../base/net/smtp.cpp" line="211"/>
        <source>Connection failed, unrecognized reply: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/smtp.cpp" line="251"/>
        <source>Authentication failed, msg: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/smtp.cpp" line="264"/>
        <source>&lt;mail from&gt; was rejected by server, msg: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/smtp.cpp" line="277"/>
        <source>&lt;Rcpt to&gt; was rejected by server, msg: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/smtp.cpp" line="290"/>
        <source>&lt;data&gt; was rejected by server, msg: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/smtp.cpp" line="304"/>
        <source>Message was rejected by the server, error: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/smtp.cpp" line="392"/>
        <source>Both EHLO and HELO failed, msg: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/smtp.cpp" line="473"/>
        <source>The SMTP server does not seem to support any of the authentications modes we support [CRAM-MD5|PLAIN|LOGIN], skipping authentication, knowing it is likely to fail... Server Auth Modes: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/smtp.cpp" line="561"/>
        <source>Email Notification Error: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <location filename="../gui/optionsdialog.ui" line="14"/>
        <source>Options</source>
        <translation>Opções</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="52"/>
        <source>Behavior</source>
        <translation>Comportamento</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="57"/>
        <source>Downloads</source>
        <translation>Downloads</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="62"/>
        <source>Connection</source>
        <translation>Conexão</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="67"/>
        <source>Speed</source>
        <translation>Velocidade</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="72"/>
        <source>BitTorrent</source>
        <translation>BitTorrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="77"/>
        <source>RSS</source>
        <translation>RSS</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="82"/>
        <source>Web UI</source>
        <translation>Interface de usuário da web</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="87"/>
        <source>Advanced</source>
        <translation>Avançado</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="219"/>
        <source>Transfer List</source>
        <translation>Lista de Transferência</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="228"/>
        <source>Confirm when deleting torrents</source>
        <translation>Confirmar quando apagar torrents</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="238"/>
        <source>Use alternating row colors</source>
        <extracomment>In table elements, every other row will have a grey background.</extracomment>
        <translation>Usar cores alternantes nas linhas</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="250"/>
        <source>Hide zero and infinity values</source>
        <translation>Ocultar valores zero e infinito</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="258"/>
        <source>Always</source>
        <translation>Sempre</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="263"/>
        <source>Paused torrents only</source>
        <translation>Só torrents pausados</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="286"/>
        <source>Action on double-click</source>
        <translation>Ação do duplo clique</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="292"/>
        <source>Downloading torrents:</source>
        <translation>Baixando torrents:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="303"/>
        <location filename="../gui/optionsdialog.ui" line="339"/>
        <source>Start / Stop Torrent</source>
        <translation>Iniciar / Parar Torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="308"/>
        <location filename="../gui/optionsdialog.ui" line="344"/>
        <source>Open destination folder</source>
        <translation>Abrir pasta de destino</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="323"/>
        <location filename="../gui/optionsdialog.ui" line="359"/>
        <source>No action</source>
        <translation>Nenhuma ação</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="331"/>
        <source>Completed torrents:</source>
        <translation>Torrents completados:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="386"/>
        <source>Desktop</source>
        <translation>Área de trabalho</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="392"/>
        <source>Start qBittorrent on Windows start up</source>
        <translation>Iniciar o qBittorrent quando o Windows inicializar</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="399"/>
        <source>Show splash screen on start up</source>
        <translation>Mostrar a tela de inicialização ao inicializar</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="412"/>
        <source>Start qBittorrent minimized</source>
        <translation>Iniciar o qBittorrent minimizado</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="422"/>
        <source>Confirmation on exit when torrents are active</source>
        <translation>Confirmação ao sair quando os torrents estão ativos</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="432"/>
        <source>Confirmation on auto-exit when downloads finish</source>
        <translation>Confirmação ao auto-sair quando os downloads concluírem</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="620"/>
        <source> KiB</source>
        <translation> KBs</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="798"/>
        <source>Torrent content layout:</source>
        <translation>Layout do conteúdo do torrent:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="809"/>
        <source>Original</source>
        <translation>Original</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="814"/>
        <source>Create subfolder</source>
        <translation>Criar sub-pasta</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="819"/>
        <source>Don&apos;t create subfolder</source>
        <translation>Não criar sub-pasta</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1220"/>
        <source>Add...</source>
        <translation>Adicionar...</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1230"/>
        <source>Options..</source>
        <translation>Opções..</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1240"/>
        <source>Remove</source>
        <translation>Remover</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1267"/>
        <source>Email notification &amp;upon download completion</source>
        <translation>Notificação por e-mail &amp;ao completar o download</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1368"/>
        <source>Run e&amp;xternal program on torrent completion</source>
        <translation>Executar p&amp;rograma externo ao completar o torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1437"/>
        <source>Peer connection protocol:</source>
        <translation>Protocolo de conexão com os peers:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1496"/>
        <source>Any</source>
        <translation>Qualquer um</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1815"/>
        <source>IP Fi&amp;ltering</source>
        <translation>Filtra&amp;gem dos IPs</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2009"/>
        <source>Schedule &amp;the use of alternative rate limits</source>
        <translation>Agendar &amp;o uso de limites alternativos das taxas</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2024"/>
        <source>From:</source>
        <comment>From start time</comment>
        <translation>De:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2051"/>
        <source>To:</source>
        <comment>To end time</comment>
        <translation>Até:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2256"/>
        <source>Find peers on the DHT network</source>
        <translation>Achar peers na rede DHT</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2304"/>
        <source>Allow encryption: Connect to peers regardless of setting
Require encryption: Only connect to peers with protocol encryption
Disable encryption: Only connect to peers without protocol encryption</source>
        <translation>Permitir encriptação: Conexão com os peers independente da configuração
Requer encriptação: Só conectar com os peers com encriptação do protocolo
Desativar encriptação: Só conectar com os peers sem encriptação do protocolo</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2310"/>
        <source>Allow encryption</source>
        <translation>Permitir encriptação</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2355"/>
        <source>(&lt;a href=&quot;https://github.com/qbittorrent/qBittorrent/wiki/Anonymous-Mode&quot;&gt;More information&lt;/a&gt;)</source>
        <translation>(&lt;a href=&quot;https://github.com/qbittorrent/qBittorrent/wiki/Anonymous-Mode&quot;&gt;Mais informações&lt;/a&gt;)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2385"/>
        <source>Maximum active checking torrents:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2420"/>
        <source>&amp;Torrent Queueing</source>
        <translation>&amp;Torrents na Fila</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2713"/>
        <source>A&amp;utomatically add these trackers to new downloads:</source>
        <translation>A&amp;utomaticamente adicionar estes trackers aos novos downloads:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2779"/>
        <source>RSS Reader</source>
        <translation>Leitor do RSS</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2785"/>
        <source>Enable fetching RSS feeds</source>
        <translation>Ativar a busca de feeds do RSS</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2794"/>
        <source>Feeds refresh interval:</source>
        <translation>Intervalo de atualização dos feeds:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2811"/>
        <source>Maximum number of articles per feed:</source>
        <translation>Número máximo de artigos por feed:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2617"/>
        <location filename="../gui/optionsdialog.ui" line="2818"/>
        <source> min</source>
        <extracomment>minutes</extracomment>
        <translation> min</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2608"/>
        <source>Seeding Limits</source>
        <translation>Limites do Seeding</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2630"/>
        <source>When seeding time reaches</source>
        <translation>Quando o tempo do seeding alcançar</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2651"/>
        <source>Pause torrent</source>
        <translation>Pausar torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2656"/>
        <source>Remove torrent</source>
        <translation>Remover torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2661"/>
        <source>Remove torrent and its files</source>
        <translation>Remover o torrent e seus arquivos</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2666"/>
        <source>Enable super seeding for torrent</source>
        <translation>Ativar o super seeding pro torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2674"/>
        <source>When ratio reaches</source>
        <translation>Quando a proporção alcançar</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2852"/>
        <source>RSS Torrent Auto Downloader</source>
        <translation>Auto-Baixador de Torrents do RSS</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2858"/>
        <source>Enable auto downloading of RSS torrents</source>
        <translation>Ativar auto-download dos torrents do RSS</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2865"/>
        <source>Edit auto downloading rules...</source>
        <translation>Editar regras de auto-download...</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2875"/>
        <source>RSS Smart Episode Filter</source>
        <translation>Filtro inteligente de episódios do RSS</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2881"/>
        <source>Download REPACK/PROPER episodes</source>
        <translation>Baixar episódios REPACK/PROPER</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2888"/>
        <source>Filters:</source>
        <translation>Filtros:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2949"/>
        <source>Web User Interface (Remote control)</source>
        <translation>Interface de Usuário da Web (Controle remoto)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2963"/>
        <source>IP address:</source>
        <translation>Endereço de IP:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2970"/>
        <source>IP address that the Web UI will bind to.
Specify an IPv4 or IPv6 address. You can specify &quot;0.0.0.0&quot; for any IPv4 address,
&quot;::&quot; for any IPv6 address, or &quot;*&quot; for both IPv4 and IPv6.</source>
        <translation>Endereço IP com o qual a Interface de usuário da web se vinculará.
Especifique um endereço IPv4 ou IPv6. Você pode especificar &quot;0.0.0.0&quot; pra qualquer endereço IPv4,
&quot;::&quot; pra qualquer endereço IPv6 ou &quot;*&quot; pra ambos IPv4 e IPv6.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3128"/>
        <source>Ban client after consecutive failures:</source>
        <translation>Banir cliente após falhas consecutivas:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3148"/>
        <source>Never</source>
        <translation>Nunca</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3158"/>
        <source>ban for:</source>
        <translation>banir por:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3185"/>
        <source>Session timeout:</source>
        <translation>Tempo pra esgotar a sessão:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3192"/>
        <source>Disabled</source>
        <translation>Desativado</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3268"/>
        <source>Enable cookie Secure flag (requires HTTPS)</source>
        <translation>Ativar bandeira segura do cookie (requer HTTPS)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3286"/>
        <source>Server domains:</source>
        <translation>Domínios do servidor:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3293"/>
        <source>Whitelist for filtering HTTP Host header values.
In order to defend against DNS rebinding attack,
you should put in domain names used by WebUI server.

Use &apos;;&apos; to split multiple entries. Can use wildcard &apos;*&apos;.</source>
        <translation>A lista branca pra filtrar valores do cabeçalho do hospedeiro HTTP.
De modo que pra se defender contra o ataque de re-vinculação do DNS,
você deve colocar nomes de domínio usados pelo servidor WebUI.

Use &apos;;&apos; pra dividir múltiplas entradas. Pode usar o wildcard &apos;*&apos;.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3011"/>
        <source>&amp;Use HTTPS instead of HTTP</source>
        <translation>&amp;Usar HTTPS ao invés do HTTP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3099"/>
        <source>Bypass authentication for clients on localhost</source>
        <translation>Ignorar autenticação pra clientes no hospedeiro local</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3106"/>
        <source>Bypass authentication for clients in whitelisted IP subnets</source>
        <translation>Ignorar autenticação pra clientes em sub-redes com IPs na lista branca</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3119"/>
        <source>IP subnet whitelist...</source>
        <translation>Lista branca de sub-redes dos IPs...</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3364"/>
        <source>Upda&amp;te my dynamic domain name</source>
        <translation>Atualiz&amp;ar meu nome de domínio dinâmico</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="454"/>
        <source>Minimize qBittorrent to notification area</source>
        <translation>Minimizar o qBittorrent na área de notificação</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="133"/>
        <source>Interface</source>
        <translation>Interface</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="174"/>
        <source>Language:</source>
        <translation>Idioma:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="476"/>
        <source>Tray icon style:</source>
        <translation>Estilo do ícone do tray:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="484"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="520"/>
        <source>File association</source>
        <translation>Associação de arquivo</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="526"/>
        <source>Use qBittorrent for .torrent files</source>
        <translation>Usar qBittorrent pra arquivos .torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="533"/>
        <source>Use qBittorrent for magnet links</source>
        <translation>Usar qBittorrent pra links magnet</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="543"/>
        <source>Check for program updates</source>
        <translation>Procurar atualizações do programa</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="553"/>
        <source>Power Management</source>
        <translation>Gerenciamento de Energia</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="596"/>
        <source>Save path:</source>
        <translation>Caminho do salvamento:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="613"/>
        <source>Backup the log file after:</source>
        <translation>Fazer backup do arquivo de log após:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="653"/>
        <source>Delete backup logs older than:</source>
        <translation>Apagar logs de backup mais velhos do que:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="768"/>
        <source>When adding a torrent</source>
        <translation>Quando adicionar um torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="783"/>
        <source>Bring torrent dialog to the front</source>
        <translation>Trazer o diálogo do torrent para a frente</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="867"/>
        <source>Also delete .torrent files whose addition was cancelled</source>
        <translation>Também apagar arquivos .torrent cuja adição foi cancelada</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="870"/>
        <source>Also when addition is cancelled</source>
        <translation>Também quando a adição for cancelada</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="892"/>
        <source>Warning! Data loss possible!</source>
        <translation>Aviso! Perda de dados possível!</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="934"/>
        <source>Saving Management</source>
        <translation>Gerenciamento do salvamento</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="942"/>
        <source>Default Torrent Management Mode:</source>
        <translation>Modo de gerenciamento padrão dos torrents:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="959"/>
        <source>Manual</source>
        <translation>Manual</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="964"/>
        <source>Automatic</source>
        <translation>Automático</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="987"/>
        <source>When Torrent Category changed:</source>
        <translation>Quando a categoria do torrent for mudada:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="997"/>
        <source>Relocate torrent</source>
        <translation>Re-alocar torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1002"/>
        <source>Switch torrent to Manual Mode</source>
        <translation>Trocar o torrent pro modo manual</translation>
    </message>
    <message>
        <source>When Default Save Path changed:</source>
        <translation type="vanished">Quando o caminho padrão do salvamento for mudado:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1038"/>
        <location filename="../gui/optionsdialog.ui" line="1079"/>
        <source>Relocate affected torrents</source>
        <translation>Re-alocar torrents afetados</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1043"/>
        <location filename="../gui/optionsdialog.ui" line="1084"/>
        <source>Switch affected torrents to Manual Mode</source>
        <translation>Trocar os torrents afetados pro modo manual</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1109"/>
        <source>Use Subcategories</source>
        <translation>Usar sub-categorias</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1128"/>
        <source>Default Save Path:</source>
        <translation>Caminho padrão do salvamento:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1148"/>
        <source>Copy .torrent files to:</source>
        <translation>Copiar os arquivos .torrent pra:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="442"/>
        <source>Show &amp;qBittorrent in notification area</source>
        <translation>Mostrar o &amp;qBittorrent na área de notificação</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="576"/>
        <source>&amp;Log file</source>
        <translation>&amp;Arquivo do log</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="774"/>
        <source>Display &amp;torrent content and some options</source>
        <translation>Exibir &amp;conteúdo do torrent e algumas opções</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="855"/>
        <source>De&amp;lete .torrent files afterwards </source>
        <translation>Ap&amp;agar os arquivos .torrent mais tarde </translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1161"/>
        <source>Copy .torrent files for finished downloads to:</source>
        <translation>Copiar os arquivos .torrent dos downloads concluídos para:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="910"/>
        <source>Pre-allocate disk space for all files</source>
        <translation>Pré-alocar espaço em disco pra todos os arquivos</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="139"/>
        <source>Use custom UI Theme</source>
        <translation>Usar tema personalizado da interface do usuário</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="148"/>
        <source>UI Theme file:</source>
        <translation>Arquivo do tema da interface do usuário:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="181"/>
        <source>Use system icon theme</source>
        <translation>Usar tema do ícone do sistema</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="209"/>
        <source>Changing Interface settings requires application restart</source>
        <translation>Mudar as configurações da interface requer o reinício do aplicativo</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="225"/>
        <source>Shows a confirmation dialog upon torrent deletion</source>
        <translation>Mostra um diálogo de confirmação ao apagar o torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="313"/>
        <location filename="../gui/optionsdialog.ui" line="349"/>
        <source>Preview file, otherwise open destination folder</source>
        <translation>Pré-visualizar arquivo, de outro modo abrir a pasta de destino</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="318"/>
        <location filename="../gui/optionsdialog.ui" line="354"/>
        <source>Show torrent options</source>
        <translation>Mostrar opções do torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="409"/>
        <source>When qBittorrent is started, the main window will be minimized</source>
        <translation>Quando o qBittorrent for iniciado a janela principal será minimizada</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="419"/>
        <source>Shows a confirmation dialog when exiting with active torrents</source>
        <translation>Mostra um diálogo de confirmação quando sair com torrents ativos</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="451"/>
        <source>When minimizing, the main window is closed and must be reopened from the systray icon</source>
        <translation>Quando minimizar a janela principal é fechada e deve ser reaberta no ícone do tray</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="464"/>
        <source>The systray icon will still be visible when closing the main window</source>
        <translation>O ícone do tray ainda estará visível quando fechar a janela principal</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="467"/>
        <source>Close qBittorrent to notification area</source>
        <extracomment>The systray icon will still be visible when closing the main window</extracomment>
        <translation>Fechar o qBittorrent na área de notificação</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="489"/>
        <source>Monochrome (for dark theme)</source>
        <translation>Monocromático (pro tema escuro)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="494"/>
        <source>Monochrome (for light theme)</source>
        <translation>Monocromático (pro tema claro)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="559"/>
        <source>Inhibit system sleep when torrents are downloading</source>
        <translation>Inibir o sono do sistema quando os torrents estão baixando</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="566"/>
        <source>Inhibit system sleep when torrents are seeding</source>
        <translation>Inibir o sono do sistema quando os torrents estão no seeding</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="610"/>
        <source>Creates an additional log file after the log file reaches the specified file size</source>
        <translation>Cria um arquivo de log adicional após o arquivo de log alcançar o tamanho especificado do arquivo</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="677"/>
        <source>days</source>
        <extracomment>Delete backup logs older than 10 days</extracomment>
        <translation>dias</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="682"/>
        <source>months</source>
        <extracomment>Delete backup logs older than 10 months</extracomment>
        <translation>meses</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="687"/>
        <source>years</source>
        <extracomment>Delete backup logs older than 10 years</extracomment>
        <translation>anos</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="713"/>
        <source>Log performance warnings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="842"/>
        <source>The torrent will be added to download list in a paused state</source>
        <translation>O torrent será adicionado a lista de downloads num estado pausado</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="845"/>
        <source>Do not start the download automatically</source>
        <extracomment>The torrent will be added to download list in a paused state</extracomment>
        <translation>Não iniciar o download automaticamente</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="852"/>
        <source>Whether the .torrent file should be deleted after adding it</source>
        <translation>Se o arquivo .torrent deve ser apagado após adicioná-lo</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="907"/>
        <source>Allocate full file sizes on disk before starting downloads, to minimize fragmentation. Only useful for HDDs.</source>
        <translation>Aloca o tamanho completo dos arquivos no disco antes de iniciar os downloads pra minimizar a fragmentação. Só é útil pra HDDs.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="917"/>
        <source>Append .!qB extension to incomplete files</source>
        <translation>Adicionar a extensão .!qB nos arquivos incompletos</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="924"/>
        <source>When a torrent is downloaded, offer to add torrents from any .torrent files found inside it</source>
        <translation>Quando um torrent é baixado oferece pra adicionar torrents de quaisquer arquivos .torrent achados dentro dele</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="927"/>
        <source>Enable recursive download dialog</source>
        <translation>Ativar diálogo de download recursivo</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="954"/>
        <source>Automatic: Various torrent properties (e.g. save path) will be decided by the associated category
Manual: Various torrent properties (e.g. save path) must be assigned manually</source>
        <translation>Automático: Várias propriedades do torrent (ex: o caminho do salvamento) serão decididas pela categoria associada
Manual: Várias propriedades do torrent (ex: o caminho do salvamento) devem ser atribuídas manualmente</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1025"/>
        <source>When Default Save/Incomplete Path changed:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1066"/>
        <source>When Category Save Path changed:</source>
        <translation>Quando o caminho do salvamento da categoria for mudado:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1116"/>
        <source>Use Category paths in Manual Mode</source>
        <translation>Usar os caminhos da Categoria no Modo Manual</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1119"/>
        <source>Resolve relative Save Path against appropriate Category path instead of Default one</source>
        <translation>Resolver o Caminho de Salvamento relativo contra o Caminho da Categoria apropriado ao invés do caminho Padrão</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1138"/>
        <source>Use another path for incomplete torrents:</source>
        <translation>Usar outro caminho pros torrents incompletos:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1173"/>
        <source>Automatically add torrents from:</source>
        <translation>Adicionar automaticamente torrents de:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1284"/>
        <source>Receiver</source>
        <translation>Receptor</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1287"/>
        <source>To:</source>
        <comment>To receiver</comment>
        <translation>Até:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1294"/>
        <source>SMTP server:</source>
        <translation>Servidor SMTP:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1307"/>
        <source>Sender</source>
        <translation>Remetente</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1310"/>
        <source>From:</source>
        <comment>From sender</comment>
        <translation>De:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1319"/>
        <source>This server requires a secure connection (SSL)</source>
        <translation>Este servidor requer uma conexão segura (SSL)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1326"/>
        <location filename="../gui/optionsdialog.ui" line="3062"/>
        <source>Authentication</source>
        <translation>Autenticação</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1338"/>
        <location filename="../gui/optionsdialog.ui" line="1776"/>
        <location filename="../gui/optionsdialog.ui" line="3070"/>
        <location filename="../gui/optionsdialog.ui" line="3422"/>
        <source>Username:</source>
        <translation>Nome de usuário:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1348"/>
        <location filename="../gui/optionsdialog.ui" line="1786"/>
        <location filename="../gui/optionsdialog.ui" line="3080"/>
        <location filename="../gui/optionsdialog.ui" line="3432"/>
        <source>Password:</source>
        <translation>Senha:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1383"/>
        <source>Show console window</source>
        <translation>Mostrar janela do console</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1445"/>
        <source>TCP and μTP</source>
        <translation>TCP e μTP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1478"/>
        <source>Listening Port</source>
        <translation>Porta de Escuta</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1486"/>
        <source>Port used for incoming connections:</source>
        <translation>Porta usada pra conexões de entrada:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1493"/>
        <source>Set to 0 to let your system pick an unused port</source>
        <translation>Defina em 0 pra deixar seu sistema escolher uma porta não usada</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1506"/>
        <source>Random</source>
        <translation>Aleatória</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1528"/>
        <source>Use UPnP / NAT-PMP port forwarding from my router</source>
        <translation>Usar abertura de porta UPnP / NAT-PMP do meu roteador</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1541"/>
        <source>Connections Limits</source>
        <translation>Limites da Conexão</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1557"/>
        <source>Maximum number of connections per torrent:</source>
        <translation>Número máximo de conexões por torrent:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1567"/>
        <source>Global maximum number of connections:</source>
        <translation>Número máximo global de conexões:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1606"/>
        <source>Maximum number of upload slots per torrent:</source>
        <translation>Número máximo de slots de upload por torrent:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1613"/>
        <source>Global maximum number of upload slots:</source>
        <translation>Número global máximo de slots de upload:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1649"/>
        <source>Proxy Server</source>
        <translation>Servidor Proxy</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1657"/>
        <source>Type:</source>
        <translation>Tipo:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1665"/>
        <source>(None)</source>
        <translation>(Nenhum)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1670"/>
        <source>SOCKS4</source>
        <translation>SOCKS4</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1675"/>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1680"/>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1691"/>
        <source>Host:</source>
        <translation>Hospedeiro:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1708"/>
        <location filename="../gui/optionsdialog.ui" line="2979"/>
        <source>Port:</source>
        <translation>Porta:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1736"/>
        <source>Otherwise, the proxy server is only used for tracker connections</source>
        <translation>De outro modo o servidor proxy só é usado pra conexões com o tracker</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1739"/>
        <source>Use proxy for peer connections</source>
        <translation>Usar proxy pra conexões com os peers</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1746"/>
        <source>RSS feeds, search engine, software updates or anything else other than torrent transfers and related operations (such as peer exchanges) will use a direct connection</source>
        <translation>Feeds do RSS, motor de busca, atualizações do software ou qualquer outra coisa do que transferências de torrents e operações relacionadas (tais como trocas de peers) usarão uma conexão direta</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1749"/>
        <source>Use proxy only for torrents</source>
        <translation>Usar proxy só pra torrents</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1762"/>
        <source>A&amp;uthentication</source>
        <translation>A&amp;utenticação</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1802"/>
        <source>Info: The password is saved unencrypted</source>
        <translation>Info: A senha é salva desencriptada</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1823"/>
        <source>Filter path (.dat, .p2p, .p2b):</source>
        <translation>Caminho do filtro (.dat, .p2p, .p2b):</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1833"/>
        <source>Reload the filter</source>
        <translation>Recarregar o filtro</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1848"/>
        <source>Manually banned IP addresses...</source>
        <translation>Endereços de IP banidos manualmente...</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1855"/>
        <source>Apply to trackers</source>
        <translation>Aplicar aos trackers</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1913"/>
        <source>Global Rate Limits</source>
        <translation>Limites Globais da Taxa</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1919"/>
        <location filename="../gui/optionsdialog.ui" line="1935"/>
        <location filename="../gui/optionsdialog.ui" line="1990"/>
        <location filename="../gui/optionsdialog.ui" line="2126"/>
        <location filename="../gui/optionsdialog.ui" line="2439"/>
        <location filename="../gui/optionsdialog.ui" line="2462"/>
        <location filename="../gui/optionsdialog.ui" line="2485"/>
        <source>∞</source>
        <translation>∞</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1922"/>
        <location filename="../gui/optionsdialog.ui" line="1938"/>
        <location filename="../gui/optionsdialog.ui" line="1993"/>
        <location filename="../gui/optionsdialog.ui" line="2129"/>
        <location filename="../gui/optionsdialog.ui" line="2526"/>
        <location filename="../gui/optionsdialog.ui" line="2539"/>
        <source> KiB/s</source>
        <translation> KB/s</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1967"/>
        <location filename="../gui/optionsdialog.ui" line="2155"/>
        <source>Upload:</source>
        <translation>Upload:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1974"/>
        <location filename="../gui/optionsdialog.ui" line="2162"/>
        <source>Download:</source>
        <translation>Download:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1984"/>
        <source>Alternative Rate Limits</source>
        <translation>Limites Alternativos da Taxa</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2021"/>
        <source>Start time</source>
        <translation>Hora do início</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2048"/>
        <source>End time</source>
        <translation>Hora do término</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2078"/>
        <source>When:</source>
        <translation>Quando:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2092"/>
        <source>Every day</source>
        <translation>Todo dia</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2097"/>
        <source>Weekdays</source>
        <translation>Dias da semana</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2102"/>
        <source>Weekends</source>
        <translation>Finais de semana</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2172"/>
        <source>Rate Limits Settings</source>
        <translation>Configurações dos Limites da Taxa</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2192"/>
        <source>Apply rate limit to peers on LAN</source>
        <translation>Aplicar limite da taxa aos peers na LAN</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2185"/>
        <source>Apply rate limit to transport overhead</source>
        <translation>Aplicar limite da taxa a sobrecarga do transporte</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2178"/>
        <source>Apply rate limit to µTP protocol</source>
        <translation>Aplicar limite da taxa ao protocolo µTP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2250"/>
        <source>Privacy</source>
        <translation>Privacidade</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2259"/>
        <source>Enable DHT (decentralized network) to find more peers</source>
        <translation>Ativar DHT (rede decentralizada) pra achar mais peers</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2269"/>
        <source>Exchange peers with compatible Bittorrent clients (µTorrent, Vuze, ...)</source>
        <translation>Trocar peers com clientes Bittorrent compatíveis (µTorrent, Vuze...)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2272"/>
        <source>Enable Peer Exchange (PeX) to find more peers</source>
        <translation>Ativar Troca de Peers (PeX) pra achar mais peers</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2282"/>
        <source>Look for peers on your local network</source>
        <translation>Procurar peers na sua rede local</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2285"/>
        <source>Enable Local Peer Discovery to find more peers</source>
        <translation>Ativar descoberta de peers locais pra achar mais peers</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2297"/>
        <source>Encryption mode:</source>
        <translation>Modo de encriptação:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2315"/>
        <source>Require encryption</source>
        <translation>Requer encriptação</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2320"/>
        <source>Disable encryption</source>
        <translation>Desativar encriptação</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2345"/>
        <source>Enable when using a proxy or a VPN connection</source>
        <translation>Ativar quando usar um proxy ou uma conexão VPN</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2348"/>
        <source>Enable anonymous mode</source>
        <translation>Ativar modo anônimo</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2432"/>
        <source>Maximum active downloads:</source>
        <translation>Máximo de downloads ativos:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2455"/>
        <source>Maximum active uploads:</source>
        <translation>Máximo de uploads ativos:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2478"/>
        <source>Maximum active torrents:</source>
        <translation>Máximo de torrents ativos:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2514"/>
        <source>Do not count slow torrents in these limits</source>
        <translation>Não contar torrents lentos nestes limites</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2552"/>
        <source>Upload rate threshold:</source>
        <translation>Limite da taxa de upload:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2559"/>
        <source>Download rate threshold:</source>
        <translation>Limite da taxa de download:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2579"/>
        <location filename="../gui/optionsdialog.ui" line="3168"/>
        <location filename="../gui/optionsdialog.ui" line="3195"/>
        <source> sec</source>
        <extracomment>seconds</extracomment>
        <translation> seg</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2595"/>
        <source>Torrent inactivity timer:</source>
        <translation>Cronômetro da inatividade do torrent:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2637"/>
        <source>then</source>
        <translation>então</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3001"/>
        <source>Use UPnP / NAT-PMP to forward the port from my router</source>
        <translation>Usar UPnP / NAT-PMP pra abrir a porta do meu roteador</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3030"/>
        <source>Certificate:</source>
        <translation>Certificado:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3023"/>
        <source>Key:</source>
        <translation>Chave:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3043"/>
        <source>&lt;a href=https://httpd.apache.org/docs/current/ssl/ssl_faq.html#aboutcerts&gt;Information about certificates&lt;/a&gt;</source>
        <translation>&lt;a href=https://httpd.apache.org/docs/current/ssl/ssl_faq.html#aboutcerts&gt;Informações sobre certificados&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3090"/>
        <source>Change current password</source>
        <translation>Mudar a senha atual</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3223"/>
        <source>Use alternative Web UI</source>
        <translation>Usar interface alternativa de usuário da web</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3235"/>
        <source>Files location:</source>
        <translation>Local dos arquivos:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3248"/>
        <source>Security</source>
        <translation>Segurança</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3254"/>
        <source>Enable clickjacking protection</source>
        <translation>Ativar proteção contra clickjacking</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3261"/>
        <source>Enable Cross-Site Request Forgery (CSRF) protection</source>
        <translation>Ativar proteção contra falsificação de requisição de sites cruzados (CSRF)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3275"/>
        <source>Enable Host header validation</source>
        <translation>Ativar validação de cabeçalho do hospedeiro</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3312"/>
        <source>Add custom HTTP headers</source>
        <translation>Adicionar cabeçalhos HTTP personalizados</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3324"/>
        <source>Header: value pairs, one per line</source>
        <translation>Cabeçalho: pares de valores, um por linha</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3334"/>
        <source>Enable reverse proxy support</source>
        <translation>Ativar suporte pro proxy reverso</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3345"/>
        <source>Trusted proxies list:</source>
        <translation>Lista de proxies confiáveis:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3352"/>
        <source>Specify reverse proxy IPs in order to use forwarded client address (X-Forwarded-For attribute), use &apos;;&apos; to split multiple entries.</source>
        <translation>Especifique IPs de proxies reversos pra usar no endereço do cliente encaminhado (atributo X-Forwarded-For), use &apos;;&apos; pra dividir múltiplas entradas.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3376"/>
        <source>Service:</source>
        <translation>Serviço:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3399"/>
        <source>Register</source>
        <translation>Registrar</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3408"/>
        <source>Domain name:</source>
        <translation>Nome do domínio:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="228"/>
        <source>By enabling these options, you can &lt;strong&gt;irrevocably lose&lt;/strong&gt; your .torrent files!</source>
        <translation>Ao ativar estas opções, você pode &lt;strong&gt;perder irremediavelmente&lt;/strong&gt; seus arquivos .torrent!</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="235"/>
        <source>If you enable the second option (&amp;ldquo;Also when addition is cancelled&amp;rdquo;) the .torrent file &lt;strong&gt;will be deleted&lt;/strong&gt; even if you press &amp;ldquo;&lt;strong&gt;Cancel&lt;/strong&gt;&amp;rdquo; in the &amp;ldquo;Add torrent&amp;rdquo; dialog</source>
        <translation>Se você ativar a segunda opção (&amp;ldquo;Também quando a adição for cancelada&amp;rdquo;) o arquivo .torrent &lt;strong&gt;será apagado&lt;/strong&gt; mesmo se você pressionar &amp;ldquo;&lt;strong&gt;Cancelar&lt;/strong&gt;&amp;rdquo; no diálogo &amp;ldquo;Adicionar torrent&amp;rdquo;</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="259"/>
        <source>Select qBittorrent UI Theme file</source>
        <translation>Selecione o arquivo do tema da interface do usuário do qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="296"/>
        <source>Choose Alternative UI files location</source>
        <translation>Escolha o local alternativo dos arquivos da interface do usuário</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="395"/>
        <source>Supported parameters (case sensitive):</source>
        <translation>Parâmetros suportados (caso sensitivo):</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="396"/>
        <source>%N: Torrent name</source>
        <translation>%N: Nome do torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="397"/>
        <source>%L: Category</source>
        <translation>%L: Categoria</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="399"/>
        <source>%F: Content path (same as root path for multifile torrent)</source>
        <translation>%F: Caminho do conteúdo (o mesmo do caminho raiz pra torrent multi-arquivos)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="400"/>
        <source>%R: Root path (first torrent subdirectory path)</source>
        <translation>%R: Caminho raiz (primeiro caminho do sub-diretório do torrent)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="401"/>
        <source>%D: Save path</source>
        <translation>%D: Caminho do salvamento</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="402"/>
        <source>%C: Number of files</source>
        <translation>%C: Número de arquivos</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="403"/>
        <source>%Z: Torrent size (bytes)</source>
        <translation>%Z: Tamanho do torrent (bytes)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="404"/>
        <source>%T: Current tracker</source>
        <translation>%T: Tracker atual</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="408"/>
        <source>Tip: Encapsulate parameter with quotation marks to avoid text being cut off at whitespace (e.g., &quot;%N&quot;)</source>
        <translation>Dica: Encapsule o parâmetro entre aspas pra evitar que o texto seja cortado nos espaços em branco (ex: &quot;%N&quot;)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="476"/>
        <source>A torrent will be considered slow if its download and upload rates stay below these values for &quot;Torrent inactivity timer&quot; seconds</source>
        <translation>Um torrent será considerado lento se suas taxas de download e upload ficarem abaixo destes valores pelos segundos do &quot;Cronômetro de inatividade do torrent&quot;</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="485"/>
        <source>Certificate</source>
        <translation>Certificado</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="486"/>
        <source>Select certificate</source>
        <translation>Selecionar certificado</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="488"/>
        <source>Private key</source>
        <translation>Chave privada</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="489"/>
        <source>Select private key</source>
        <translation>Selecione a chave privada</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1665"/>
        <source>Select folder to monitor</source>
        <translation>Selecione a pasta a monitorar</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1688"/>
        <source>Adding entry failed</source>
        <translation>Falhou em adicionar a entrada</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1777"/>
        <location filename="../gui/optionsdialog.cpp" line="1803"/>
        <source>Invalid path</source>
        <translation>Caminho inválido</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1881"/>
        <source>Location Error</source>
        <translation>Erro do local</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1881"/>
        <source>The alternative Web UI files location cannot be blank.</source>
        <translation>O local alternativo dos arquivos da interface de usuário da web não pode estar em branco.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="553"/>
        <location filename="../gui/optionsdialog.cpp" line="556"/>
        <source>Choose export directory</source>
        <translation>Escolha o diretório pra exportar</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="230"/>
        <source>When these options are enabled, qBittorrent will &lt;strong&gt;delete&lt;/strong&gt; .torrent files after they were successfully (the first option) or not (the second option) added to its download queue. This will be applied &lt;strong&gt;not only&lt;/strong&gt; to the files opened via &amp;ldquo;Add torrent&amp;rdquo; menu action but to those opened via &lt;strong&gt;file type association&lt;/strong&gt; as well</source>
        <translation>Quando estas opções estão ativadas o qBittorrent &lt;strong&gt;apagará&lt;/strong&gt; os arquivos .torrent após eles serem adicionados com sucesso (a primeira opção) ou não (a segunda opção) nas suas filas de download. Isto será aplicado &lt;strong&gt;não só&lt;/strong&gt; nos arquivos abertos via ação pelo menu &amp;ldquo;Adicionar torrent&amp;rdquo;, mas também para aqueles abertos via &lt;strong&gt;associação de tipos de arquivo&lt;/strong&gt;</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="260"/>
        <source>qBittorrent UI Theme file (*.qbtheme config.json)</source>
        <translation>Arquivo do tema da interface do usuário do qBittorrent (*.qbtheme config.json)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="398"/>
        <source>%G: Tags (separated by comma)</source>
        <translation>%G: Etiquetas (separadas por vírgula)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="405"/>
        <source>%I: Info hash v1 (or &apos;-&apos; if unavailable)</source>
        <translation>%I: Informações do hash v1 (ou &apos;-&apos; se indisponível)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="406"/>
        <source>%J: Info hash v2 (or &apos;-&apos; if unavailable)</source>
        <translation>%J: Informações do hash v2 (ou &apos;-&apos; se indisponível)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="407"/>
        <source>%K: Torrent ID (either sha-1 info hash for v1 torrent or truncated sha-256 info hash for v2/hybrid torrent)</source>
        <translation>%K: ID do torrent (hash das informações do sha-1 pro torrent v1 ou hash das informações do sha-256 truncadas pra torrent v2/híbrido)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="550"/>
        <location filename="../gui/optionsdialog.cpp" line="563"/>
        <location filename="../gui/optionsdialog.cpp" line="566"/>
        <source>Choose a save directory</source>
        <translation>Escolha um diretório pra salvar</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="559"/>
        <source>Choose an IP filter file</source>
        <translation>Escolha um arquivo de filtro de IP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="560"/>
        <source>All supported filters</source>
        <translation>Todos os filtros suportados</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1845"/>
        <source>Parsing error</source>
        <translation>Erro de análise</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1845"/>
        <source>Failed to parse the provided IP filter</source>
        <translation>Falhou em analisar o filtro de IP fornecido</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1847"/>
        <source>Successfully refreshed</source>
        <translation>Atualizado com sucesso</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1847"/>
        <source>Successfully parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>Analisou com sucesso o filtro de IP fornecido: %1 regras foram aplicadas.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1810"/>
        <source>Invalid key</source>
        <translation>Chave inválida</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1810"/>
        <source>This is not a valid SSL key.</source>
        <translation>Esta não é uma chave SSL válida.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1784"/>
        <source>Invalid certificate</source>
        <translation>Certificado inválido</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="192"/>
        <source>Preferences</source>
        <translation>Preferências</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1784"/>
        <source>This is not a valid SSL certificate.</source>
        <translation>Este não é um certificado SSL válido.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1856"/>
        <source>Time Error</source>
        <translation>Erro do Tempo</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1856"/>
        <source>The start time and the end time can&apos;t be the same.</source>
        <translation>A hora de início e a hora do término não podem ser as mesmas.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1866"/>
        <location filename="../gui/optionsdialog.cpp" line="1871"/>
        <source>Length Error</source>
        <translation>Erro de Comprimento</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1866"/>
        <source>The Web UI username must be at least 3 characters long.</source>
        <translation>O nome de usuário da interface de usuário da web deve ter pelo menos 3 caracteres de comprimento.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1871"/>
        <source>The Web UI password must be at least 6 characters long.</source>
        <translation>A senha da interface de usuário da web deve ter pelo menos 6 caracteres de comprimento.</translation>
    </message>
</context>
<context>
    <name>PeerInfo</name>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="254"/>
        <source>Interested (local) and choked (peer)</source>
        <translation>Interessados​ ​(locais) e paralisados (peers)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="259"/>
        <source>Interested (local) and unchoked (peer)</source>
        <translation>Interessados (locais) e não paralisados (peers)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="268"/>
        <source>Interested (peer) and choked (local)</source>
        <translation>Interessados (peers) e paralisados (locais)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="273"/>
        <source>Interested (peer) and unchoked (local)</source>
        <translation>Interessados (peers) e não paralisados (locais)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="279"/>
        <source>Not interested (local) and unchoked (peer)</source>
        <translation>Não interessados (locais) e não paralisados (peers)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="283"/>
        <source>Not interested (peer) and unchoked (local)</source>
        <translation>Não interessados (peers) e não paralisados (locais)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="287"/>
        <source>Optimistic unchoke</source>
        <translation>Não paralisado otimista</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="291"/>
        <source>Peer snubbed</source>
        <translation>Peer esnobado</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="295"/>
        <source>Incoming connection</source>
        <translation>Conexão de entrada</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="299"/>
        <source>Peer from DHT</source>
        <translation>Peer do DHT</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="303"/>
        <source>Peer from PEX</source>
        <translation>Peer do PEX</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="307"/>
        <source>Peer from LSD</source>
        <translation>Peer do LSD</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="311"/>
        <source>Encrypted traffic</source>
        <translation>Tráfego criptografado</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="315"/>
        <source>Encrypted handshake</source>
        <translation>Handshake criptografado</translation>
    </message>
</context>
<context>
    <name>PeerListWidget</name>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="105"/>
        <source>Country/Region</source>
        <translation>País/Região</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="106"/>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="107"/>
        <source>Port</source>
        <translation>Porta</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="108"/>
        <source>Flags</source>
        <translation>Bandeiras</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="109"/>
        <source>Connection</source>
        <translation>Conexão</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="110"/>
        <source>Client</source>
        <comment>i.e.: Client application</comment>
        <translation>Cliente</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="111"/>
        <source>Progress</source>
        <comment>i.e: % downloaded</comment>
        <translation>Progresso</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="112"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Velocidade de download</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="113"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Velocidade de upload</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="114"/>
        <source>Downloaded</source>
        <comment>i.e: total data downloaded</comment>
        <translation>Baixados</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="115"/>
        <source>Uploaded</source>
        <comment>i.e: total data uploaded</comment>
        <translation>Enviados</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="116"/>
        <source>Relevance</source>
        <comment>i.e: How relevant this peer is to us. How many pieces it has that we don&apos;t.</comment>
        <translation>Relevância</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="117"/>
        <source>Files</source>
        <comment>i.e. files that are being downloaded right now</comment>
        <translation>Arquivos</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="185"/>
        <source>Column visibility</source>
        <translation>Visibilidade da coluna</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="211"/>
        <source>Resize columns</source>
        <translation>Redimensionar colunas</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="220"/>
        <source>Resize all non-hidden columns to the size of their contents</source>
        <translation>Redimensionar todas as colunas não ocultas para o tamanho do conteúdo delas</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="272"/>
        <source>Add peers...</source>
        <translation>Adicionar peers...</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="281"/>
        <location filename="../gui/properties/peerlistwidget.cpp" line="283"/>
        <source>Adding peers</source>
        <translation>Adicionando peers</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="281"/>
        <source>Some peers cannot be added. Check the Log for details.</source>
        <translation>Alguns peers não puderam ser adicionados. Verifique o log pra detalhes.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="283"/>
        <source>Peers are added to this torrent.</source>
        <translation>Os peers são adicionados a este torrent.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="288"/>
        <location filename="../gui/properties/peerlistwidget.cpp" line="331"/>
        <source>Ban peer permanently</source>
        <translation>Banir o peer permanentemente</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="299"/>
        <source>Cannot add peers to a private torrent</source>
        <translation>Não pôde adicionar os peers em um torrent privado</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="301"/>
        <source>Cannot add peers when the torrent is checking</source>
        <translation>Não pode adicionar os peers quando o torrent está verificando</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="303"/>
        <source>Cannot add peers when the torrent is queued</source>
        <translation>Não pode adicionar os peers quando o torrent está na fila</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="307"/>
        <source>No peer was selected</source>
        <translation>Nenhum peer foi selecionado</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="332"/>
        <source>Are you sure you want to permanently ban the selected peers?</source>
        <translation>Você tem certeza que você quer banir permanentemente os peers selecionados?</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="338"/>
        <source>Peer &quot;%1&quot; is manually banned</source>
        <translation>O Peer &quot;%1&quot; foi banido manualmente</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="285"/>
        <source>Copy IP:port</source>
        <translation>Copiar IP:porta</translation>
    </message>
</context>
<context>
    <name>PeersAdditionDialog</name>
    <message>
        <location filename="../gui/properties/peersadditiondialog.ui" line="14"/>
        <source>Add Peers</source>
        <translation>Adicionar Peers</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.ui" line="20"/>
        <source>List of peers to add (one IP per line):</source>
        <translation>Lista de peers pra adicionar (um IP por linha):</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.ui" line="33"/>
        <source>Format: IPv4:port / [IPv6]:port</source>
        <translation>Formato: IPv4:porta / [IPv6]:porta</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.cpp" line="62"/>
        <source>No peer entered</source>
        <translation>Nenhum peer inserido</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.cpp" line="63"/>
        <source>Please type at least one peer.</source>
        <translation>Por favor digite pelo menos um peer.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.cpp" line="76"/>
        <source>Invalid peer</source>
        <translation>Peer inválido</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.cpp" line="77"/>
        <source>The peer &apos;%1&apos; is invalid.</source>
        <translation>O peer &apos;%1&apos; é inválido.</translation>
    </message>
</context>
<context>
    <name>PieceAvailabilityBar</name>
    <message>
        <location filename="../gui/properties/pieceavailabilitybar.cpp" line="173"/>
        <source>Unavailable pieces</source>
        <translation>Pedaços indisponíveis</translation>
    </message>
    <message>
        <location filename="../gui/properties/pieceavailabilitybar.cpp" line="174"/>
        <source>Available pieces</source>
        <translation>Pedaços disponíveis</translation>
    </message>
</context>
<context>
    <name>PiecesBar</name>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="271"/>
        <source>Files in this piece:</source>
        <translation>Arquivos neste pedaço:</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="276"/>
        <source>File in this piece</source>
        <translation>Arquivo neste pedaço</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="278"/>
        <source>File in these pieces</source>
        <translation>Arquivo nestes pedaços</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="295"/>
        <source>Wait until metadata become available to see detailed information</source>
        <translation>Aguarde até que os metadados se tornem disponíveis pra ver a informação detalhada</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="297"/>
        <source>Hold Shift key for detailed information</source>
        <translation>Pressione a tecla Shift pra informações detalhadas</translation>
    </message>
</context>
<context>
    <name>PluginSelectDialog</name>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="17"/>
        <source>Search plugins</source>
        <translation>Plugins de busca</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="30"/>
        <source>Installed search plugins:</source>
        <translation>Plugins de busca instalados:</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="53"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="58"/>
        <source>Version</source>
        <translation>Versão</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="63"/>
        <source>Url</source>
        <translation>URL</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="68"/>
        <location filename="../gui/search/pluginselectdialog.ui" line="134"/>
        <source>Enabled</source>
        <translation>Ativado</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="81"/>
        <source>Warning: Be sure to comply with your country&apos;s copyright laws when downloading torrents from any of these search engines.</source>
        <translation>Aviso: Certifique-se de obedecer as leis de copyright do seu país quando baixar torrents de quaisquer destes motores de busca.</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="96"/>
        <source>You can get new search engine plugins here: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</source>
        <translation>Você pode obter novos plugins de motores de busca aqui: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="108"/>
        <source>Install a new one</source>
        <translation>Instalar um novo plugin</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="115"/>
        <source>Check for updates</source>
        <translation>Procurar atualizações</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="122"/>
        <source>Close</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="139"/>
        <source>Uninstall</source>
        <translation>Desinstalar</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="160"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="231"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="296"/>
        <source>Yes</source>
        <translation>Sim</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="165"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="210"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="236"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="301"/>
        <source>No</source>
        <translation>Não</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="216"/>
        <source>Uninstall warning</source>
        <translation>Aviso da desinstalação</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="216"/>
        <source>Some plugins could not be uninstalled because they are included in qBittorrent. Only the ones you added yourself can be uninstalled.
Those plugins were disabled.</source>
        <translation>Alguns plugins não puderam ser desinstalados porque eles estão incluídos no qBittorrent. Só aqueles que você adicionou você mesmo podem ser desinstalados.
Esses plugins foram desativados.</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="218"/>
        <source>Uninstall success</source>
        <translation>Desinstalado com sucesso</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="218"/>
        <source>All selected plugins were uninstalled successfully</source>
        <translation>Todos os plugins selecionados foram desinstalados com sucesso</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="341"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="447"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="462"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="494"/>
        <source>Search plugin update</source>
        <translation>Atualização do plugin de busca</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="341"/>
        <source>Plugins installed or updated: %1</source>
        <translation>Plugins instalados ou atualizados: %1</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="361"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="369"/>
        <source>New search engine plugin URL</source>
        <translation>URL do novo plugin do motor de busca</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="362"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="370"/>
        <source>URL:</source>
        <translation>URL:</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="367"/>
        <source>Invalid link</source>
        <translation>Link inválido</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="367"/>
        <source>The link doesn&apos;t seem to point to a search engine plugin.</source>
        <translation>O link não parece apontar pra um plugin do motor de busca.</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="384"/>
        <source>Select search plugins</source>
        <translation>Selecionar plugins de busca</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="385"/>
        <source>qBittorrent search plugin</source>
        <translation>Plugin de busca do qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="447"/>
        <source>All your plugins are already up to date.</source>
        <translation>Todos os seus plugins já estão atualizados.</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="462"/>
        <source>Sorry, couldn&apos;t check for plugin updates. %1</source>
        <translation>Lamento, não pôde procurar atualizações do plugin. %1</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="476"/>
        <source>Search plugin install</source>
        <translation>Instalação do plugin de busca</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="477"/>
        <source>Couldn&apos;t install &quot;%1&quot; search engine plugin. %2</source>
        <translation>Não pôde instalar o plugin do motor de busca &quot;%1&quot;. %2</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="495"/>
        <source>Couldn&apos;t update &quot;%1&quot; search engine plugin. %2</source>
        <translation>Não pôde atualizar o plugin do motor de busca &quot;%1&quot;. %2</translation>
    </message>
</context>
<context>
    <name>PluginSourceDialog</name>
    <message>
        <location filename="../gui/search/pluginsourcedialog.ui" line="14"/>
        <source>Plugin source</source>
        <translation>Fonte do plugin</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginsourcedialog.ui" line="27"/>
        <source>Search plugin source:</source>
        <translation>Fonte do plugin de busca:</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginsourcedialog.ui" line="36"/>
        <source>Local file</source>
        <translation>Arquivo local</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginsourcedialog.ui" line="43"/>
        <source>Web link</source>
        <translation>Link da web</translation>
    </message>
</context>
<context>
    <name>PortForwarderImpl</name>
    <message>
        <source>UPnP / NAT-PMP support [ON]</source>
        <translation type="vanished">Suporte a UPnP / NAT-PMP [LIGADO]</translation>
    </message>
    <message>
        <source>UPnP / NAT-PMP support [OFF]</source>
        <translation type="vanished">Suporte a UPnP / NAT-PMP [DESLIGADO]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/portforwarderimpl.cpp" line="104"/>
        <source>UPnP/NAT-PMP support: ON</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/portforwarderimpl.cpp" line="114"/>
        <source>UPnP/NAT-PMP support: OFF</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PowerManagement</name>
    <message>
        <location filename="../gui/powermanagement/powermanagement.cpp" line="76"/>
        <source>qBittorrent is active</source>
        <translation>O qBittorrent está ativo</translation>
    </message>
</context>
<context>
    <name>PreviewSelectDialog</name>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="64"/>
        <source>The following files from torrent &quot;%1&quot; support previewing, please select one of them:</source>
        <translation>Os seguintes arquivos do torrent &quot;%1&quot; suportam pré-visualização por favor selecione um deles:</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="67"/>
        <source>Preview</source>
        <translation>Pré-visualização</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="75"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="76"/>
        <source>Size</source>
        <translation>Tamanho</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="77"/>
        <source>Progress</source>
        <translation>Progresso</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="135"/>
        <source>Preview impossible</source>
        <translation>Pré-visualização impossivel</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="136"/>
        <source>Sorry, we can&apos;t preview this file: &quot;%1&quot;.</source>
        <translation>Lamento, nós não conseguimos pré-visualizar este arquivo: &quot;%1&quot;.</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="152"/>
        <source>Resize columns</source>
        <translation>Redimensionar colunas</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="160"/>
        <source>Resize all non-hidden columns to the size of their contents</source>
        <translation>Redimensionar todas as colunas não ocultas para o tamanho do conteúdo delas</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.ui" line="14"/>
        <source>Preview selection</source>
        <translation>Seleção da pré-visualização</translation>
    </message>
</context>
<context>
    <name>Private::FileLineEdit</name>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="325"/>
        <source>&apos;%1&apos; does not exist</source>
        <translation>&apos;%1&apos; não existe</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="327"/>
        <source>&apos;%1&apos; does not point to a directory</source>
        <translation>&apos;%1&apos; não aponta pra um diretório</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="329"/>
        <source>&apos;%1&apos; does not point to a file</source>
        <translation>&apos;%1&apos; não aponta pra um arquivo</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="331"/>
        <source>Does not have read permission in &apos;%1&apos;</source>
        <translation>Não tem permissão de leitura em &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="333"/>
        <source>Does not have write permission in &apos;%1&apos;</source>
        <translation>Não tem permissão de gravação em &apos;%1&apos;</translation>
    </message>
</context>
<context>
    <name>PropListDelegate</name>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="87"/>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="86"/>
        <source>Do not download</source>
        <comment>Do not download (priority)</comment>
        <translation>Não baixar</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="88"/>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation>Alta</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="89"/>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation>Máxima</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="95"/>
        <source>Mixed</source>
        <comment>Mixed (priorities)</comment>
        <translation type="unfinished">Misto</translation>
    </message>
</context>
<context>
    <name>PropTabBar</name>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="51"/>
        <source>General</source>
        <translation>Geral</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="60"/>
        <source>Trackers</source>
        <translation>Trackers</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="69"/>
        <source>Peers</source>
        <translation>Peers</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="78"/>
        <source>HTTP Sources</source>
        <translation>Fontes HTTP</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="87"/>
        <source>Content</source>
        <translation>Conteúdo</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="98"/>
        <source>Speed</source>
        <translation>Velocidade</translation>
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="333"/>
        <source>Downloaded:</source>
        <translation>Baixados:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="110"/>
        <source>Availability:</source>
        <translation>Disponibilidade:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="81"/>
        <source>Progress:</source>
        <translation>Progresso:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="157"/>
        <source>Transfer</source>
        <translation>Transferência</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="549"/>
        <source>Time Active:</source>
        <extracomment>Time (duration) the torrent is active (not paused)</extracomment>
        <translation>Tempo Ativo:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="578"/>
        <source>ETA:</source>
        <translation>Tempo Restante:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="507"/>
        <source>Uploaded:</source>
        <translation>Enviados:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="436"/>
        <source>Seeds:</source>
        <translation>Seeds:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="452"/>
        <source>Download Speed:</source>
        <translation>Velocidade de download:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="188"/>
        <source>Upload Speed:</source>
        <translation>Velocidade de upload:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="217"/>
        <source>Peers:</source>
        <translation>Peers:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="275"/>
        <source>Download Limit:</source>
        <translation>Limite do download:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="349"/>
        <source>Upload Limit:</source>
        <translation>Limite do upload:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="594"/>
        <source>Wasted:</source>
        <translation>Perdidos:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="233"/>
        <source>Connections:</source>
        <translation>Conexões:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="607"/>
        <source>Information</source>
        <translation>Informação</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="799"/>
        <source>Info Hash v1:</source>
        <translation>Informações do Hash v1:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="815"/>
        <source>Info Hash v2:</source>
        <translation>Informações do Hash v2:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="863"/>
        <source>Comment:</source>
        <translation>Comentário:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1058"/>
        <source>Select All</source>
        <translation>Selecionar tudo</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1065"/>
        <source>Select None</source>
        <translation>Não selecionar nenhum</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="677"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="681"/>
        <source>High</source>
        <translation>Alta</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="291"/>
        <source>Share Ratio:</source>
        <translation>Proporção do compartilhamento:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="407"/>
        <source>Reannounce In:</source>
        <translation>Re-anunciar em:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="365"/>
        <source>Last Seen Complete:</source>
        <translation>Visto completo pela última vez:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="625"/>
        <source>Total Size:</source>
        <translation>Tamanho total:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="654"/>
        <source>Pieces:</source>
        <translation>Pedaços:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="683"/>
        <source>Created By:</source>
        <translation>Criado por:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="712"/>
        <source>Added On:</source>
        <translation>Adicionado em:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="741"/>
        <source>Completed On:</source>
        <translation>Completado em:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="770"/>
        <source>Created On:</source>
        <translation>Criado em:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="847"/>
        <source>Save Path:</source>
        <translation>Caminho do salvamento:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="685"/>
        <source>Maximum</source>
        <translation>Máxima</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="673"/>
        <source>Do not download</source>
        <translation>Não baixar</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="492"/>
        <source>Never</source>
        <translation>Nunca</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="500"/>
        <source>%1 x %2 (have %3)</source>
        <comment>(torrent pieces) eg 152 x 4MB (have 25)</comment>
        <translation>%1 x %2 (tem %3)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="442"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="445"/>
        <source>%1 (%2 this session)</source>
        <translation>%1 (%2 nesta sessão)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="184"/>
        <source>Column visibility</source>
        <translation>Visibilidade da coluna</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="207"/>
        <source>Resize columns</source>
        <translation>Redimensionar colunas</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="216"/>
        <source>Resize all non-hidden columns to the size of their contents</source>
        <translation>Redimensionar todas as colunas não ocultas para o tamanho do conteúdo delas</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="362"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="363"/>
        <source>N/A</source>
        <translation>N/D</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="454"/>
        <source>%1 (seeded for %2)</source>
        <comment>e.g. 4m39s (seeded for 3m10s)</comment>
        <translation>%1 (semeado por %2)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="461"/>
        <source>%1 (%2 max)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 max)</comment>
        <translation>%1 (%2 máx.)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="474"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="478"/>
        <source>%1 (%2 total)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 total)</comment>
        <translation>%1 (%2 total)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="484"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="489"/>
        <source>%1 (%2 avg.)</source>
        <comment>%1 and %2 are speed rates, e.g. 200KiB/s (100KiB/s avg.)</comment>
        <translation>%1 (%2 em média)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="649"/>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="651"/>
        <source>Open Containing Folder</source>
        <translation>Abrir a pasta de contenção</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="653"/>
        <source>Rename...</source>
        <translation>Renomear...</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="671"/>
        <source>Priority</source>
        <translation>Prioridade</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="690"/>
        <source>By shown file order</source>
        <translation>Pela ordem mostrada dos arquivos</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="748"/>
        <source>New Web seed</source>
        <translation>Novo seed da web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="752"/>
        <source>Remove Web seed</source>
        <translation>Remover seed da web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="755"/>
        <source>Copy Web seed URL</source>
        <translation>Copiar URL do seed da web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="757"/>
        <source>Edit Web seed URL</source>
        <translation>Editar a URL do seed da web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="96"/>
        <source>Filter files...</source>
        <translation>Filtrar arquivos...</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="800"/>
        <source>Speed graphs are disabled</source>
        <translation>Os gráficos de velocidade estão desativados</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="800"/>
        <source>You can enable it in Advanced Options</source>
        <translation>Você pode ativá-lo nas Opções Avançadas</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="813"/>
        <source>New URL seed</source>
        <comment>New HTTP source</comment>
        <translation>Nova URL do seed</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="814"/>
        <source>New URL seed:</source>
        <translation>Nova URL do seed:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="821"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="875"/>
        <source>This URL seed is already in the list.</source>
        <translation>Essa URL do seed já está na lista.</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="867"/>
        <source>Web seed editing</source>
        <translation>Editando o seed da web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="868"/>
        <source>Web seed URL:</source>
        <translation>URL do seed da web:</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../app/main.cpp" line="155"/>
        <source>%1 is an unknown command line parameter.</source>
        <comment>--random-parameter is an unknown command line parameter.</comment>
        <translation>%1 é um parâmetro desconhecido da linha de comando.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="167"/>
        <location filename="../app/main.cpp" line="178"/>
        <source>%1 must be the single command line parameter.</source>
        <translation>%1 deve ser o único parâmetro da linha de comando.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="210"/>
        <source>You cannot use %1: qBittorrent is already running for this user.</source>
        <translation>Você não pode usar o %1: o qBittorrent já está em execução pra este usuário.</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="529"/>
        <source>Usage:</source>
        <translation>Uso:</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="532"/>
        <source>Options:</source>
        <translation>Opções:</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="161"/>
        <source>Parameter &apos;%1&apos; must follow syntax &apos;%1=%2&apos;</source>
        <comment>e.g. Parameter &apos;--webui-port&apos; must follow syntax &apos;--webui-port=value&apos;</comment>
        <translation>O parâmetro &apos;%1&apos; deve seguir a sintaxe &apos;%1=%2&apos;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="207"/>
        <source>Parameter &apos;%1&apos; must follow syntax &apos;%1=%2&apos;</source>
        <comment>e.g. Parameter &apos;--webui-port&apos; must follow syntax &apos;--webui-port=&lt;value&gt;&apos;</comment>
        <translation>O parâmetro &apos;%1&apos; deve seguir a sintaxe &apos;%1=%2&apos;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="222"/>
        <source>Expected integer number in environment variable &apos;%1&apos;, but got &apos;%2&apos;</source>
        <translation>Número inteiro esperado na variável do ambiente &apos;%1&apos;, mas obteve &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="279"/>
        <source>Parameter &apos;%1&apos; must follow syntax &apos;%1=%2&apos;</source>
        <comment>e.g. Parameter &apos;--add-paused&apos; must follow syntax &apos;--add-paused=&lt;true|false&gt;&apos;</comment>
        <translation>O parâmetro &apos;%1&apos; deve seguir a sintaxe &apos;%1=%2&apos;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="306"/>
        <source>Expected %1 in environment variable &apos;%2&apos;, but got &apos;%3&apos;</source>
        <translation>Esperava %1 na variável do ambiente &apos;%2&apos;, mas obteve &apos;%3&apos;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="537"/>
        <source>port</source>
        <translation>porta</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="425"/>
        <source>%1 must specify a valid port (1 to 65535).</source>
        <translation>%1 deve especificar uma porta válida (De 1 até 65535).</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="534"/>
        <source>Display program version and exit</source>
        <translation>Exibe a versão do programa e sai</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="536"/>
        <source>Display this help message and exit</source>
        <translation>Exibe esta mensagem de ajuda e sai</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="538"/>
        <source>Change the Web UI port</source>
        <translation>Muda a porta da interface de usuário da web</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="541"/>
        <source>Disable splash screen</source>
        <translation>Desativar a tela de inicialização</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="543"/>
        <source>Run in daemon-mode (background)</source>
        <translation>Executar no modo-daemon (em 2o plano)</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="546"/>
        <source>dir</source>
        <extracomment>Use appropriate short form or abbreviation of &quot;directory&quot;</extracomment>
        <translation>dir</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="547"/>
        <source>Store configuration files in &lt;dir&gt;</source>
        <translation>Armazenar os arquivos de configuração em &lt;dir&gt;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="548"/>
        <location filename="../app/cmdoptions.cpp" line="561"/>
        <source>name</source>
        <translation>nome</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="549"/>
        <source>Store configuration files in directories qBittorrent_&lt;name&gt;</source>
        <translation>Armazenar os arquivos de configuração nos diretórios do qBittorrent_&lt;name&gt;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="551"/>
        <source>Hack into libtorrent fastresume files and make file paths relative to the profile directory</source>
        <translation>Hackear os arquivos de resumo rápido do libtorrent e criar caminhos de arquivos relativos ao diretório do perfil</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="553"/>
        <source>files or URLs</source>
        <translation>arquivos ou URLs</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="554"/>
        <source>Download the torrents passed by the user</source>
        <translation>Baixa os torrents passados pelo usuário</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="568"/>
        <source>Specify whether the &quot;Add New Torrent&quot; dialog opens when adding a torrent.</source>
        <translation>Especifica se o diálogo &quot;Adicionar Novo Torrent&quot; abre quando adicionar um torrent.</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="557"/>
        <source>Options when adding new torrents:</source>
        <translation>Opções quando adicionar novos torrents:</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="558"/>
        <source>path</source>
        <translation>caminho</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="558"/>
        <source>Torrent save path</source>
        <translation>Caminho de salvamento do torrent</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="559"/>
        <source>Add torrents as started or paused</source>
        <translation>Adicionar torrents como iniciados ou pausados</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="560"/>
        <source>Skip hash check</source>
        <translation>Ignorar a verificação do hash</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="562"/>
        <source>Assign torrents to category. If the category doesn&apos;t exist, it will be created.</source>
        <translation>Atribui os torrents a uma categoria. Se a categoria não existir ela será criada.</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="564"/>
        <source>Download files in sequential order</source>
        <translation>Baixar arquivos em ordem sequencial</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="566"/>
        <source>Download first and last pieces first</source>
        <translation>Baixar primeiro os primeiros e os últimos pedaços</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="572"/>
        <source>Option values may be supplied via environment variables. For option named &apos;parameter-name&apos;, environment variable name is &apos;QBT_PARAMETER_NAME&apos; (in upper case, &apos;-&apos; replaced with &apos;_&apos;). To pass flag values, set the variable to &apos;1&apos; or &apos;TRUE&apos;. For example, to disable the splash screen: </source>
        <translation>Os valores das opções podem ser supridos via variáveis do ambiente. Para a opção chamada &apos;parameter-name&apos;, o nome da variável do ambiente é &apos;QBT_PARAMETER_NAME&apos; (em maiúsculas, &apos;-&apos; substituído por &apos;_&apos;). Pra passar os valores da bandeira, defina a variável como &apos;1&apos; ou &apos;TRUE&apos;. Por exemplo, pra desativar a tela de inicialização: </translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="577"/>
        <source>Command line parameters take precedence over environment variables</source>
        <translation>Os parâmetros da linha de comando têm precedência sobre as variáveis do ambiente</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="585"/>
        <source>Help</source>
        <translation>Ajuda</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="397"/>
        <source>Run application with -h option to read about command line parameters.</source>
        <translation>Execute o aplicativo com a opção -h pra ler sobre os parâmetros da linha de comando.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="399"/>
        <source>Bad command line</source>
        <translation>Linha de comando ruim</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="405"/>
        <source>Bad command line: </source>
        <translation>Linha de comando ruim: </translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="418"/>
        <source>Legal Notice</source>
        <translation>Nota Legal</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="419"/>
        <source>qBittorrent is a file sharing program. When you run a torrent, its data will be made available to others by means of upload. Any content you share is your sole responsibility.</source>
        <translation>O qBittorrent é um programa de compartilhamento de arquivos. Quando você executa um torrent seus dados serão tornados disponíveis para os outros por meio do upload. Qualquer conteúdo que você compartilha é de sua inteira responsabilidade.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="420"/>
        <source>No further notices will be issued.</source>
        <translation>Nenhuma nota adicional será emitida.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="433"/>
        <source>qBittorrent is a file sharing program. When you run a torrent, its data will be made available to others by means of upload. Any content you share is your sole responsibility.

No further notices will be issued.</source>
        <translation>O qBittorrent é um programa de compartilhamento de arquivos. Quando você executa um torrent seus dados serão tornados disponíveis aos outros por meio do upload. Qualquer conteúdo que você compartilha é de sua inteira responsabilidade.

Nenhuma nota adicional será emitida.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="421"/>
        <source>Press %1 key to accept and continue...</source>
        <translation>Pressione a tecla %1 pra aceitar e continuar...</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="434"/>
        <source>Legal notice</source>
        <translation>Nota legal</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="435"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="436"/>
        <source>I Agree</source>
        <translation>Eu concordo</translation>
    </message>
    <message>
        <location filename="../base/settingsstorage.cpp" line="167"/>
        <source>Detected unclean program exit. Using fallback file to restore settings: %1</source>
        <translation>Detectada saída não limpa do programa. Usando arquivo de recuo pra restaurar as configurações: %1</translation>
    </message>
    <message>
        <location filename="../base/settingsstorage.cpp" line="243"/>
        <source>An access error occurred while trying to write the configuration file.</source>
        <translation>Um erro de acesso ocorreu enquanto tentava gravar o arquivo de configuração.</translation>
    </message>
    <message>
        <location filename="../base/settingsstorage.cpp" line="246"/>
        <source>A format error occurred while trying to write the configuration file.</source>
        <translation>Um erro de formato ocorreu enquanto tentava gravar o arquivo de configuração.</translation>
    </message>
    <message>
        <location filename="../base/settingsstorage.cpp" line="249"/>
        <source>An unknown error occurred while trying to write the configuration file.</source>
        <translation>Um erro desconhecido ocorreu enquanto tentava gravar o arquivo de configuração.</translation>
    </message>
    <message>
        <location filename="../app/upgrade.cpp" line="57"/>
        <source>Migrate preferences failed: WebUI https, file: &quot;%1&quot;, error: &quot;%2&quot;</source>
        <translation>Falhou em migrar as preferências: HTTPS WebUI, arquivo: &quot;%1&quot;, erro: &quot;%2&quot;</translation>
    </message>
    <message>
        <location filename="../app/upgrade.cpp" line="72"/>
        <source>Migrated preferences: WebUI https, exported data to file: &quot;%1&quot;</source>
        <translation>Preferências migradas: HTTPS WebUI, exportou os dados pro arquivo: &quot;%1&quot;</translation>
    </message>
    <message>
        <location filename="../app/upgrade.cpp" line="164"/>
        <location filename="../app/upgrade.cpp" line="195"/>
        <location filename="../app/upgrade.cpp" line="226"/>
        <location filename="../app/upgrade.cpp" line="364"/>
        <source>Invalid value found in configuration file, reverting it to default. Key: &quot;%1&quot;. Invalid value: &quot;%2&quot;.</source>
        <translation>Valor inválido encontrado no arquivo de configuração, revertendo para o padrão. Chave: &quot;%1&quot;. Valor inválido: &quot;%2&quot;.</translation>
    </message>
</context>
<context>
    <name>RSS::AutoDownloader</name>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="74"/>
        <location filename="../base/rss/rss_autodownloader.cpp" line="82"/>
        <source>Invalid data format.</source>
        <translation>Formato inválido dos dados.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="112"/>
        <source>Directory for RSS AutoDownloader data is unavailable.</source>
        <translation>O diretório do Auto-Baixador dos dados de RSS está indisponível.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="118"/>
        <source>Couldn&apos;t save RSS AutoDownloader data in %1. Error: %2</source>
        <translation>Não pôde salvar os dados do auto-baixador do RSS em %1. Erro: %2</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="279"/>
        <source>Invalid data format</source>
        <translation>Formato inválido dos dados</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="423"/>
        <source>Couldn&apos;t read RSS AutoDownloader rules from %1. Error: %2</source>
        <translation>Não pôde ler as regras do auto-baixador do RSS de %1. Erro: %2</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="437"/>
        <source>Couldn&apos;t load RSS AutoDownloader rules. Reason: %1</source>
        <translation>Não pôde carregar as regras do auto-baixador do RSS. Motivo: %1</translation>
    </message>
</context>
<context>
    <name>RSS::Feed</name>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="219"/>
        <source>Failed to download RSS feed at &apos;%1&apos;. Reason: %2</source>
        <translation>Falhou em baixar o feed do RSS em &apos;%1&apos;. Motivo: %2</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="255"/>
        <source>RSS feed at &apos;%1&apos; updated. Added %2 new articles.</source>
        <translation>Feed do RSS em &apos;%1&apos; atualizado. Adicionou %2 novos artigos.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="252"/>
        <source>Failed to parse RSS feed at &apos;%1&apos;. Reason: %2</source>
        <translation>Falhou em analisar o feed do RSS em &apos;%1&apos;. Motivo: %2</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="209"/>
        <source>RSS feed at &apos;%1&apos; is successfully downloaded. Starting to parse it.</source>
        <translation>O feed do RSS em &apos;%1&apos; foi baixado com sucesso. Começando a analisá-lo.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="279"/>
        <source>Couldn&apos;t read RSS Session data from %1. Error: %2</source>
        <translation>Não pôde ler a sessão de dados do RSS de %1. Erro: %2</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="291"/>
        <source>Couldn&apos;t parse RSS Session data. Error: %1</source>
        <translation>Não pôde analisar a sessão de dados do RSS. Erro: %1</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="298"/>
        <source>Couldn&apos;t load RSS Session data. Invalid data format.</source>
        <translation>Não pôde carregar a sessão de dados do RSS. Formato inválido dos dados.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="309"/>
        <source>Couldn&apos;t load RSS article &apos;%1#%2&apos;. Invalid data format.</source>
        <translation>Não pôde carregar o artigo do RSS &apos;%1#%2&apos;. Formato inválido dos dados.</translation>
    </message>
</context>
<context>
    <name>RSS::Private::Parser</name>
    <message>
        <location filename="../base/rss/rss_parser.cpp" line="603"/>
        <source>Invalid RSS feed.</source>
        <translation>Feed do RSS inválido.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_parser.cpp" line="597"/>
        <source>%1 (line: %2, column: %3, offset: %4).</source>
        <translation>%1 (linha: %2, coluna: %3, deslocamento: %4).</translation>
    </message>
</context>
<context>
    <name>RSS::Session</name>
    <message>
        <source>Couldn&apos;t save RSS Session configuration in %1. Error: %2</source>
        <translation type="vanished">Não pôde salvar a configuração da Sessão do RSS em %1. Erro: %2</translation>
    </message>
    <message>
        <source>Couldn&apos;t save RSS Session data in %1. Error: %2</source>
        <translation type="vanished">Não pôde salvar os dados da Sessão do RSS em %1. Erro: %2</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="74"/>
        <source>Couldn&apos;t save RSS session configuration. File: &quot;%1&quot;. Error: &quot;%2&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="83"/>
        <source>Couldn&apos;t save RSS session data. File: &quot;%1&quot;. Error: &quot;%2&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="154"/>
        <source>RSS feed with given URL already exists: %1.</source>
        <translation>O feed do RSS com a URL dada já existe: %1.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="172"/>
        <source>Cannot move root folder.</source>
        <translation>Não pôde mover a pasta raiz.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="176"/>
        <location filename="../base/rss/rss_session.cpp" line="210"/>
        <source>Item doesn&apos;t exist: %1.</source>
        <translation>O item não existe: %1.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="206"/>
        <source>Cannot delete root folder.</source>
        <translation>Não pôde apagar a pasta raiz.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="243"/>
        <source>Couldn&apos;t read RSS session data. File: &quot;%1&quot;. Error: &quot;%2&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="252"/>
        <source>Couldn&apos;t parse RSS session data. File: &quot;%1&quot;. Error: &quot;%2&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="259"/>
        <source>Couldn&apos;t load RSS session data. File: &quot;%1&quot;. Error: Invalid data format.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="289"/>
        <source>Couldn&apos;t load RSS feed. Feed: &quot;%1&quot;. Reason: URL is required.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="300"/>
        <source>Couldn&apos;t load RSS feed. Feed: &quot;%1&quot;. Reason: UID is invalid.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="307"/>
        <source>Duplicate RSS feed found. UID: &quot;%1&quot;. Error: Configuration seems to be corrupted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="328"/>
        <source>Couldn&apos;t load RSS item. Item: &quot;%1&quot;. Invalid data format.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="343"/>
        <source>Corrupted RSS list, not loading it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Couldn&apos;t load RSS Feed &apos;%1&apos;. URL is required.</source>
        <translation type="vanished">Não pôde carregar o feed do RSS &apos;%1&apos;. A URL é requerida.</translation>
    </message>
    <message>
        <source>Couldn&apos;t load RSS Feed &apos;%1&apos;. UID is invalid.</source>
        <translation type="vanished">Não pôde carregar o feed do RSS &apos;%1&apos;. O UID é inválido.</translation>
    </message>
    <message>
        <source>Duplicate RSS Feed UID: %1. Configuration seems to be corrupted.</source>
        <translation type="vanished">UID do feed do RSS duplicado: %1. A configuração parece estar corrompida.</translation>
    </message>
    <message>
        <source>Couldn&apos;t load RSS Item &apos;%1&apos;. Invalid data format.</source>
        <translation type="vanished">Não pôde carregar o item do RSS &apos;%1&apos;. Formato inválido dos dados.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="377"/>
        <source>Incorrect RSS Item path: %1.</source>
        <translation>Caminho incorreto do item do RSS: %1.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="380"/>
        <source>RSS item with given path already exists: %1.</source>
        <translation>O item do RSS com o caminho dado já existe: %1.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="385"/>
        <source>Parent folder doesn&apos;t exist: %1.</source>
        <translation>A pasta pai não existe: %1.</translation>
    </message>
</context>
<context>
    <name>RSSWidget</name>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="17"/>
        <source>Search</source>
        <translation>Busca</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="31"/>
        <source>Fetching of RSS feeds is disabled now! You can enable it in application settings.</source>
        <translation>A busca de feeds do RSS está desativada agora! Você pode ativá-la nas configurações do programa.</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="43"/>
        <source>New subscription</source>
        <translation>Nova subscrição</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="50"/>
        <location filename="../gui/rss/rsswidget.ui" line="174"/>
        <location filename="../gui/rss/rsswidget.ui" line="177"/>
        <source>Mark items read</source>
        <translation>Marcar itens como lidos</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="57"/>
        <source>Refresh RSS streams</source>
        <translation>Atualizar streams do RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="60"/>
        <source>Update all</source>
        <translation>Atualizar tudo</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="80"/>
        <source>RSS Downloader...</source>
        <translation>Baixador do RSS...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="108"/>
        <source>Torrents: (double-click to download)</source>
        <translation>Torrents: (clique-duplo pra baixar)</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="137"/>
        <location filename="../gui/rss/rsswidget.ui" line="140"/>
        <source>Delete</source>
        <translation>Apagar</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="145"/>
        <source>Rename...</source>
        <translation>Renomear...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="148"/>
        <source>Rename</source>
        <translation>Renomear</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="153"/>
        <location filename="../gui/rss/rsswidget.ui" line="156"/>
        <source>Update</source>
        <translation>Atualizar</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="161"/>
        <source>New subscription...</source>
        <translation>Nova subscrição...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="166"/>
        <location filename="../gui/rss/rsswidget.ui" line="169"/>
        <source>Update all feeds</source>
        <translation>Atualizar todos os feeds</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="182"/>
        <source>Download torrent</source>
        <translation>Baixar torrent</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="187"/>
        <source>Open news URL</source>
        <translation>Abrir novas URLs</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="192"/>
        <source>Copy feed URL</source>
        <translation>Copiar URL do feed</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="197"/>
        <source>New folder...</source>
        <translation>Nova pasta...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="228"/>
        <source>Please choose a folder name</source>
        <translation>Por favor escolha um nome de pasta</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="228"/>
        <source>Folder name:</source>
        <translation>Nome da pasta:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="229"/>
        <source>New folder</source>
        <translation>Nova pasta</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="270"/>
        <source>Please type a RSS feed URL</source>
        <translation>Por favor digite uma URL de feed do RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="270"/>
        <source>Feed URL:</source>
        <translation>URL do feed:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="312"/>
        <source>Deletion confirmation</source>
        <translation>Confirmação de exclusão</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="312"/>
        <source>Are you sure you want to delete the selected RSS feeds?</source>
        <translation>Você tem certeza que você quer apagar os feeds do RSS selecionados?</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="409"/>
        <source>Please choose a new name for this RSS feed</source>
        <translation>Por favor escolha um novo nome pra este feed do RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="409"/>
        <source>New feed name:</source>
        <translation>Novo nome do feed:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="417"/>
        <source>Rename failed</source>
        <translation>Falhou em renomear</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="489"/>
        <source>Date: </source>
        <translation>Data: </translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="491"/>
        <source>Author: </source>
        <translation>Autor: </translation>
    </message>
</context>
<context>
    <name>SearchController</name>
    <message>
        <location filename="../webui/api/searchcontroller.cpp" line="98"/>
        <source>Python must be installed to use the Search Engine.</source>
        <translation>O Python deve estar instalado pra usar o Motor de Busca.</translation>
    </message>
    <message>
        <location filename="../webui/api/searchcontroller.cpp" line="123"/>
        <source>Unable to create more than %1 concurrent searches.</source>
        <translation>Incapaz de criar mais do que %1 buscas simultâneas.</translation>
    </message>
    <message>
        <location filename="../webui/api/searchcontroller.cpp" line="203"/>
        <location filename="../webui/api/searchcontroller.cpp" line="209"/>
        <source>Offset is out of range</source>
        <translation>O deslocamento está fora do alcance</translation>
    </message>
    <message>
        <location filename="../webui/api/searchcontroller.cpp" line="286"/>
        <source>All plugins are already up to date.</source>
        <translation>Todos os plugins já estão atualizados.</translation>
    </message>
    <message>
        <location filename="../webui/api/searchcontroller.cpp" line="290"/>
        <source>Updating %1 plugins</source>
        <translation>Atualizando %1 plugins</translation>
    </message>
    <message>
        <location filename="../webui/api/searchcontroller.cpp" line="295"/>
        <source>Updating plugin %1</source>
        <translation>Atualizando o plugin %1</translation>
    </message>
    <message>
        <location filename="../webui/api/searchcontroller.cpp" line="302"/>
        <source>Failed to check for plugin updates: %1</source>
        <translation>Falhou em procurar as atualizações dos plugins: %1</translation>
    </message>
</context>
<context>
    <name>SearchJobWidget</name>
    <message>
        <source>Form</source>
        <translation type="vanished">Formulário</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="19"/>
        <source>Results(xxx)</source>
        <translation>Resultados (xxx)</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="39"/>
        <source>Search in:</source>
        <translation>Procurar em:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="46"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Some search engines search in torrent description and in torrent file names too. Whether such results will be shown in the list below is controlled by this mode.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Everywhere &lt;/span&gt;disables filtering and shows everything returned by the search engines.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torrent names only&lt;/span&gt; shows only torrents whose names match the search query.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Alguns motores de busca procuram na descrição do torrent e também nos nomes dos arquivos torrent. Se tais resultados serão mostrados na lista abaixo é controlado por este modo.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Em toda parte &lt;/span&gt;desativa a filtragem e mostra tudo retornado pelos motores de busca.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Só nomes de torrents&lt;/span&gt; só mostra torrents cujos nomes combinam com a consulta da busca.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="69"/>
        <source>Set minimum and maximum allowed number of seeders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="79"/>
        <source>Minimum number of seeds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="96"/>
        <source>Maximum number of seeds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="125"/>
        <source>Set minimum and maximum allowed size of a torrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="137"/>
        <source>Minimum torrent size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="161"/>
        <source>Maximum torrent size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set minimal and maximal allowed number of seeders&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Define o número máximo e mínimo de seeders permitidos&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="72"/>
        <source>Seeds:</source>
        <translation>Seeds:</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Minimal number of seeds&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Número mínimo de seeds&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="89"/>
        <location filename="../gui/search/searchjobwidget.ui" line="152"/>
        <source>to</source>
        <translation>até</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Maximal number of seeds&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Número máximo de seeds&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="99"/>
        <location filename="../gui/search/searchjobwidget.ui" line="164"/>
        <source>∞</source>
        <translation>∞</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set minimal and maximal allowed size of a torrent&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Define o tamanho máximo e mínimo permitido de um torrent&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="128"/>
        <source>Size:</source>
        <translation>Tamanho:</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Minimal torrent size&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Tamanho mínimo do torrent&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Maximal torrent size&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Tamanho máximo do torrent&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="71"/>
        <source>Name</source>
        <comment>i.e: file name</comment>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="72"/>
        <source>Size</source>
        <comment>i.e: file size</comment>
        <translation>Tamanho</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="73"/>
        <source>Seeders</source>
        <comment>i.e: Number of full sources</comment>
        <translation>Seeders</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="74"/>
        <source>Leechers</source>
        <comment>i.e: Number of partial sources</comment>
        <translation>Leechers</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="75"/>
        <source>Search engine</source>
        <translation>Motor de busca</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="128"/>
        <source>Filter search results...</source>
        <translation>Filtrar resultados da busca...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="304"/>
        <source>Results (showing &lt;i&gt;%1&lt;/i&gt; out of &lt;i&gt;%2&lt;/i&gt;):</source>
        <comment>i.e: Search results</comment>
        <translation>Resultados (mostrando &lt;i&gt;%1&lt;/i&gt; de &lt;i&gt;%2&lt;/i&gt;):</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="355"/>
        <source>Torrent names only</source>
        <translation>Só nomes de torrents</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="356"/>
        <source>Everywhere</source>
        <translation>Em toda parte</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="379"/>
        <source>Use regular expressions</source>
        <translation>Usar expressões regulares</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="393"/>
        <source>Open download window</source>
        <translation>Abrir janela de download</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="395"/>
        <source>Download</source>
        <translation>Download</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="398"/>
        <source>Open description page</source>
        <translation>Abrir página da descrição</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="402"/>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="404"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="406"/>
        <source>Download link</source>
        <translation>Link do download</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="408"/>
        <source>Description page URL</source>
        <translation>URL da página de descrição</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="419"/>
        <source>Searching...</source>
        <translation>Procurando...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="421"/>
        <source>Search has finished</source>
        <translation>A busca foi concluída</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="423"/>
        <source>Search aborted</source>
        <translation>Busca abortada</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="425"/>
        <source>An error occurred during search...</source>
        <translation>Um erro ocorreu durante a busca...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="427"/>
        <source>Search returned no results</source>
        <translation>A busca não retornou resultados</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="464"/>
        <source>Column visibility</source>
        <translation>Visibilidade da coluna</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="487"/>
        <source>Resize columns</source>
        <translation>Redimensionar colunas</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="496"/>
        <source>Resize all non-hidden columns to the size of their contents</source>
        <translation>Redimensionar todas as colunas não ocultas para o tamanho do conteúdo delas</translation>
    </message>
</context>
<context>
    <name>SearchPluginManager</name>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="224"/>
        <source>Unknown search engine plugin file format.</source>
        <translation>Formato desconhecido do arquivo do plugin do motor de busca.</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="235"/>
        <source>Plugin already at version %1, which is greater than %2</source>
        <translation>O plugin já está na versão: %1, a qual é superior a %2</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="236"/>
        <source>A more recent version of this plugin is already installed.</source>
        <translation>Uma versão mais recente deste plugin já está instalada.</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="260"/>
        <source>Plugin %1 is not supported.</source>
        <translation>O plugin %1 não é suportado.</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="268"/>
        <location filename="../base/search/searchpluginmanager.cpp" line="272"/>
        <source>Plugin is not supported.</source>
        <translation>O plugin não é suportado.</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="280"/>
        <source>Plugin %1 has been successfully updated.</source>
        <translation>O plugin %1 foi atualizado com sucesso.</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="346"/>
        <source>All categories</source>
        <translation>Todas as categorias</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="347"/>
        <source>Movies</source>
        <translation>Filmes</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="348"/>
        <source>TV shows</source>
        <translation>Shows de TV</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="349"/>
        <source>Music</source>
        <translation>Músicas</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="350"/>
        <source>Games</source>
        <translation>Jogos</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="351"/>
        <source>Anime</source>
        <translation>Animes</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="352"/>
        <source>Software</source>
        <translation>Softwares</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="353"/>
        <source>Pictures</source>
        <translation>Imagens</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="354"/>
        <source>Books</source>
        <translation>Livros</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="386"/>
        <source>Update server is temporarily unavailable. %1</source>
        <translation>O servidor de atualização está temporariamente indisponível. %1</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="407"/>
        <location filename="../base/search/searchpluginmanager.cpp" line="409"/>
        <source>Failed to download the plugin file. %1</source>
        <translation>Falhou em baixar o arquivo do plugin. %1</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="539"/>
        <source>Plugin &quot;%1&quot; is outdated, updating to version %2</source>
        <translation>O plugin &quot;%1&quot; está desatualizado, atualizando para a versão %2</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="546"/>
        <source>Incorrect update info received for %1 out of %2 plugins.</source>
        <translation>Informação de atualização incorreta recebida por %1 de %2 plugins.</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="585"/>
        <source>Search plugin &apos;%1&apos; contains invalid version string (&apos;%2&apos;)</source>
        <translation>O plugin de busca &apos;%1&apos; contém uma string de versão inválida (&apos;%2&apos;)</translation>
    </message>
</context>
<context>
    <name>SearchWidget</name>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="14"/>
        <location filename="../gui/search/searchwidget.ui" line="51"/>
        <location filename="../gui/search/searchwidget.cpp" line="295"/>
        <location filename="../gui/search/searchwidget.cpp" line="318"/>
        <location filename="../gui/search/searchwidget.cpp" line="384"/>
        <location filename="../gui/search/searchwidget.cpp" line="392"/>
        <source>Search</source>
        <translation>Busca</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="79"/>
        <source>There aren&apos;t any search plugins installed.
Click the &quot;Search plugins...&quot; button at the bottom right of the window to install some.</source>
        <translation>Não há quaisquer plugins de busca instalados.
Clique no botão &quot;Plugins de busca&quot; na parte inferior direita da janela pra instalar alguns.</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="132"/>
        <source>Search plugins...</source>
        <translation>Plugins de busca...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="99"/>
        <source>A phrase to search for.</source>
        <translation>Uma frase a ser procurada.</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="100"/>
        <source>Spaces in a search term may be protected by double quotes.</source>
        <translation>Os espaços num termo de busca podem ser protegidos por aspas duplas.</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="102"/>
        <source>Example:</source>
        <comment>Search phrase example</comment>
        <translation>Exemplo:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="104"/>
        <source>&lt;b&gt;foo bar&lt;/b&gt;: search for &lt;b&gt;foo&lt;/b&gt; and &lt;b&gt;bar&lt;/b&gt;</source>
        <comment>Search phrase example, illustrates quotes usage, a pair of space delimited words, individal words are highlighted</comment>
        <translation>&lt;b&gt;foo bar&lt;/b&gt;: procure por &lt;b&gt;foo&lt;/b&gt; e &lt;b&gt;bar&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="108"/>
        <source>&lt;b&gt;&amp;quot;foo bar&amp;quot;&lt;/b&gt;: search for &lt;b&gt;foo bar&lt;/b&gt;</source>
        <comment>Search phrase example, illustrates quotes usage, double quotedpair of space delimited words, the whole pair is highlighted</comment>
        <translation>&lt;b&gt;&amp;quot;foo bar&amp;quot;&lt;/b&gt;: procure por &lt;b&gt;foo bar&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="207"/>
        <source>All plugins</source>
        <translation>Todos os plugins</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="206"/>
        <source>Only enabled</source>
        <translation>Só ativados</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="172"/>
        <source>Close tab</source>
        <translation>Fechar aba</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="173"/>
        <source>Close all tabs</source>
        <translation>Fechar todas as abas</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="208"/>
        <source>Select...</source>
        <translation>Selecionar...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="309"/>
        <location filename="../gui/search/searchwidget.cpp" line="378"/>
        <location filename="../gui/search/searchwidget.cpp" line="380"/>
        <source>Search Engine</source>
        <translation>Motor de Busca</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="309"/>
        <source>Please install Python to use the Search Engine.</source>
        <translation>Por favor instale o Python pra usar o motor de busca.</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="329"/>
        <source>Empty search pattern</source>
        <translation>Modelo de busca vazio</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="329"/>
        <source>Please type a search pattern first</source>
        <translation>Por favor digite um modelo de busca primeiro</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="359"/>
        <source>Stop</source>
        <translation>Parar</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="380"/>
        <source>Search has finished</source>
        <translation>A busca foi concluída</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="378"/>
        <source>Search has failed</source>
        <translation>A busca falhou</translation>
    </message>
</context>
<context>
    <name>ShutdownConfirmDialog</name>
    <message>
        <location filename="../gui/shutdownconfirmdialog.ui" line="64"/>
        <source>Don&apos;t show again</source>
        <translation>Não mostrar de novo</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="112"/>
        <source>qBittorrent will now exit.</source>
        <translation>O qBittorrent sairá agora.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="113"/>
        <source>E&amp;xit Now</source>
        <translation>S&amp;air Agora</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="114"/>
        <source>Exit confirmation</source>
        <translation>Confirmação da saída</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="117"/>
        <source>The computer is going to shutdown.</source>
        <translation>O computador vai ser desligado.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="118"/>
        <source>&amp;Shutdown Now</source>
        <translation>&amp;Desligar agora</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="119"/>
        <source>Shutdown confirmation</source>
        <translation>Confirmação do desligamento</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="122"/>
        <source>The computer is going to enter suspend mode.</source>
        <translation>O computador vai entrar no modo de suspensão.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="123"/>
        <source>&amp;Suspend Now</source>
        <translation>&amp;Suspender agora</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="124"/>
        <source>Suspend confirmation</source>
        <translation>Confirmação da suspensão</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="127"/>
        <source>The computer is going to enter hibernation mode.</source>
        <translation>O computador vai entrar no modo de hibernação.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="128"/>
        <source>&amp;Hibernate Now</source>
        <translation>&amp;Hibernar agora</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="129"/>
        <source>Hibernate confirmation</source>
        <translation>Confirmação da hibernação</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="139"/>
        <source>You can cancel the action within %1 seconds.</source>
        <translation>Você pode cancelar a ação dentro de %1 segundos.</translation>
    </message>
</context>
<context>
    <name>SpeedLimitDialog</name>
    <message>
        <location filename="../gui/speedlimitdialog.ui" line="14"/>
        <source>Global Speed Limits</source>
        <translation>Limites globais de velocidade</translation>
    </message>
    <message>
        <location filename="../gui/speedlimitdialog.ui" line="20"/>
        <source>Speed limits</source>
        <translation>Limites de velocidade</translation>
    </message>
    <message>
        <location filename="../gui/speedlimitdialog.ui" line="33"/>
        <location filename="../gui/speedlimitdialog.ui" line="103"/>
        <source>Upload:</source>
        <translation>Upload:</translation>
    </message>
    <message>
        <location filename="../gui/speedlimitdialog.ui" line="47"/>
        <location filename="../gui/speedlimitdialog.ui" line="74"/>
        <location filename="../gui/speedlimitdialog.ui" line="117"/>
        <location filename="../gui/speedlimitdialog.ui" line="144"/>
        <source>∞</source>
        <translation>∞</translation>
    </message>
    <message>
        <location filename="../gui/speedlimitdialog.ui" line="50"/>
        <location filename="../gui/speedlimitdialog.ui" line="77"/>
        <location filename="../gui/speedlimitdialog.ui" line="120"/>
        <location filename="../gui/speedlimitdialog.ui" line="147"/>
        <source> KiB/s</source>
        <translation> KB/s</translation>
    </message>
    <message>
        <location filename="../gui/speedlimitdialog.ui" line="60"/>
        <location filename="../gui/speedlimitdialog.ui" line="130"/>
        <source>Download:</source>
        <translation>Download:</translation>
    </message>
    <message>
        <location filename="../gui/speedlimitdialog.ui" line="90"/>
        <source>Alternative speed limits</source>
        <translation>Limites alternativos de velocidade</translation>
    </message>
</context>
<context>
    <name>SpeedPlotView</name>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="173"/>
        <source>Total Upload</source>
        <translation>Total do upload</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="174"/>
        <source>Total Download</source>
        <translation>Total do download</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="178"/>
        <source>Payload Upload</source>
        <translation>Carga do upload</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="179"/>
        <source>Payload Download</source>
        <translation>Carga do download</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="183"/>
        <source>Overhead Upload</source>
        <translation>Sobrecarga do upload</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="184"/>
        <source>Overhead Download</source>
        <translation>Sobrecarga do download</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="188"/>
        <source>DHT Upload</source>
        <translation>Upload do DHT</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="189"/>
        <source>DHT Download</source>
        <translation>Download do DHT</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="193"/>
        <source>Tracker Upload</source>
        <translation>Upload do tracker</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="194"/>
        <source>Tracker Download</source>
        <translation>Download do tracker</translation>
    </message>
</context>
<context>
    <name>SpeedWidget</name>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="68"/>
        <source>Period:</source>
        <translation>Período:</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="71"/>
        <source>1 Minute</source>
        <translation>1 minuto</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="72"/>
        <source>5 Minutes</source>
        <translation>5 minutos</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="73"/>
        <source>30 Minutes</source>
        <translation>30 minutos</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="75"/>
        <source>6 Hours</source>
        <translation>6 horas</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="105"/>
        <source>Select Graphs</source>
        <translation>Selecione os gráficos</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="83"/>
        <source>Total Upload</source>
        <translation>Total do upload</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="74"/>
        <source>3 Hours</source>
        <translation>3 horas</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="76"/>
        <source>12 Hours</source>
        <translation>12 horas</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="77"/>
        <source>24 Hours</source>
        <translation>24 horas</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="84"/>
        <source>Total Download</source>
        <translation>Total do download</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="85"/>
        <source>Payload Upload</source>
        <translation>Carga do upload</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="86"/>
        <source>Payload Download</source>
        <translation>Carga do download</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="87"/>
        <source>Overhead Upload</source>
        <translation>Sobrecarga do upload</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="88"/>
        <source>Overhead Download</source>
        <translation>Sobrecarga do download</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="89"/>
        <source>DHT Upload</source>
        <translation>Upload do DHT</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="90"/>
        <source>DHT Download</source>
        <translation>Download do DHT</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="91"/>
        <source>Tracker Upload</source>
        <translation>Upload do tracker</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="92"/>
        <source>Tracker Download</source>
        <translation>Download do tracker</translation>
    </message>
</context>
<context>
    <name>StacktraceDialog</name>
    <message>
        <location filename="../app/stacktracedialog.ui" line="14"/>
        <source>Crash info</source>
        <translation>Informações do crash</translation>
    </message>
</context>
<context>
    <name>StatsDialog</name>
    <message>
        <location filename="../gui/statsdialog.ui" line="14"/>
        <source>Statistics</source>
        <translation>Estatísticas</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="20"/>
        <source>User statistics</source>
        <translation>Estatísticas do usuário</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="99"/>
        <source>Cache statistics</source>
        <translation>Estatísticas do cache</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="105"/>
        <source>Read cache hits:</source>
        <translation>Acertos do cache de leitura:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="184"/>
        <source>Average time in queue:</source>
        <translation>Tempo médio na fila:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="33"/>
        <source>Connected peers:</source>
        <translation>Peers conectados:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="40"/>
        <source>All-time share ratio:</source>
        <translation>Proporção do compartilhamento de todos os tempos:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="54"/>
        <source>All-time download:</source>
        <translation>Download de todos os tempos:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="75"/>
        <source>Session waste:</source>
        <translation>Perdas da sessão:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="82"/>
        <source>All-time upload:</source>
        <translation>Upload de todos os tempos:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="126"/>
        <source>Total buffer size:</source>
        <translation>Tamanho total do buffer:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="136"/>
        <source>Performance statistics</source>
        <translation>Estatísticas da performance</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="170"/>
        <source>Queued I/O jobs:</source>
        <translation>Trabalhos de E/S na fila:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="177"/>
        <source>Write cache overload:</source>
        <translation>Sobrecarga do cache da gravação:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="191"/>
        <source>Read cache overload:</source>
        <translation>Sobrecarga do cache de leitura:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="198"/>
        <source>Total queued size:</source>
        <translation>Tamanho total na fila:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.cpp" line="112"/>
        <source>%1 ms</source>
        <comment>18 milliseconds</comment>
        <translation>%1 ms</translation>
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <location filename="../gui/statusbar.cpp" line="68"/>
        <location filename="../gui/statusbar.cpp" line="192"/>
        <source>Connection status:</source>
        <translation>Status da conexão:</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="69"/>
        <location filename="../gui/statusbar.cpp" line="192"/>
        <source>No direct connections. This may indicate network configuration problems.</source>
        <translation>Não há conexões diretas. Isto pode indicar problemas na configuração da rede.</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="90"/>
        <location filename="../gui/statusbar.cpp" line="202"/>
        <source>DHT: %1 nodes</source>
        <translation>DHT: %1 nós</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="161"/>
        <source>qBittorrent needs to be restarted!</source>
        <translation>O qBittorrent precisa ser reiniciado!</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="179"/>
        <location filename="../gui/statusbar.cpp" line="187"/>
        <source>Connection Status:</source>
        <translation>Status da conexão:</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="179"/>
        <source>Offline. This usually means that qBittorrent failed to listen on the selected port for incoming connections.</source>
        <translation>Offline. Isto geralmente significa que o qBittorrent falhou em escutar a porta selecionada pra conexões de entrada.</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="187"/>
        <source>Online</source>
        <translation>Online</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="248"/>
        <source>Click to switch to alternative speed limits</source>
        <translation>Clique pra trocar pros limites alternativos da velocidade</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="242"/>
        <source>Click to switch to regular speed limits</source>
        <translation>Clique pra trocar pros limites regulares da velocidade</translation>
    </message>
</context>
<context>
    <name>StatusFilterWidget</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="174"/>
        <source>All (0)</source>
        <comment>this is for the status filter</comment>
        <translation>Todos (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="177"/>
        <source>Downloading (0)</source>
        <translation>Baixando (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="180"/>
        <source>Seeding (0)</source>
        <translation>Seeding (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="183"/>
        <source>Completed (0)</source>
        <translation>Completado (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="186"/>
        <source>Resumed (0)</source>
        <translation>Resumido (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="189"/>
        <source>Paused (0)</source>
        <translation>Pausado (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="192"/>
        <source>Active (0)</source>
        <translation>Ativo (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="195"/>
        <source>Inactive (0)</source>
        <translation>Inativo (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="198"/>
        <source>Stalled (0)</source>
        <translation>Parado (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="201"/>
        <source>Stalled Uploading (0)</source>
        <translation>Upload parado (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="204"/>
        <source>Stalled Downloading (0)</source>
        <translation>Download parado (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="207"/>
        <source>Checking (0)</source>
        <translation>Verificando (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="210"/>
        <source>Errored (0)</source>
        <translation>Com erro (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="281"/>
        <source>All (%1)</source>
        <translation>Todos (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="282"/>
        <source>Downloading (%1)</source>
        <translation>Baixando (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="283"/>
        <source>Seeding (%1)</source>
        <translation>Seeding (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="284"/>
        <source>Completed (%1)</source>
        <translation>Completado (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="286"/>
        <source>Paused (%1)</source>
        <translation>Pausado (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="309"/>
        <source>Resume torrents</source>
        <translation type="unfinished">Resumir torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="311"/>
        <source>Pause torrents</source>
        <translation type="unfinished">Pausar torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="313"/>
        <source>Delete torrents</source>
        <translation type="unfinished">Apagar torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="285"/>
        <source>Resumed (%1)</source>
        <translation>Resumido (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="287"/>
        <source>Active (%1)</source>
        <translation>Ativo (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="288"/>
        <source>Inactive (%1)</source>
        <translation>Inativo (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="289"/>
        <source>Stalled (%1)</source>
        <translation>Parado (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="290"/>
        <source>Stalled Uploading (%1)</source>
        <translation>Upload parado (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="291"/>
        <source>Stalled Downloading (%1)</source>
        <translation>Download parado (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="292"/>
        <source>Checking (%1)</source>
        <translation>Verificando (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="293"/>
        <source>Errored (%1)</source>
        <translation>Com erro (%1)</translation>
    </message>
</context>
<context>
    <name>TagFilterModel</name>
    <message>
        <location filename="../gui/tagfiltermodel.cpp" line="149"/>
        <source>Tags</source>
        <translation>Etiquetas</translation>
    </message>
    <message>
        <location filename="../gui/tagfiltermodel.cpp" line="260"/>
        <source>All</source>
        <translation>Tudo</translation>
    </message>
    <message>
        <location filename="../gui/tagfiltermodel.cpp" line="262"/>
        <source>Untagged</source>
        <translation>Sem etiqueta</translation>
    </message>
</context>
<context>
    <name>TagFilterWidget</name>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="110"/>
        <source>Add tag...</source>
        <translation>Adicionar etiqueta...</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="116"/>
        <source>Remove tag</source>
        <translation>Remover etiqueta</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="120"/>
        <source>Remove unused tags</source>
        <translation>Remover etiquetas não usadas</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="123"/>
        <source>Resume torrents</source>
        <translation>Resumir torrents</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="125"/>
        <source>Pause torrents</source>
        <translation>Pausar torrents</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="127"/>
        <source>Delete torrents</source>
        <translation>Apagar torrents</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="171"/>
        <source>New Tag</source>
        <translation>Nova etiqueta</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="171"/>
        <source>Tag:</source>
        <translation>Etiqueta:</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="177"/>
        <source>Invalid tag name</source>
        <translation>Nome da etiqueta inválido</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="178"/>
        <source>Tag name &apos;%1&apos; is invalid</source>
        <translation>O nome da etiqueta &apos;%1&apos; é inválido</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="193"/>
        <source>Tag exists</source>
        <translation>A etiqueta existe</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="193"/>
        <source>Tag name already exists.</source>
        <translation>O nome da etiqueta já existe.</translation>
    </message>
</context>
<context>
    <name>TorrentCategoryDialog</name>
    <message>
        <location filename="../gui/torrentcategorydialog.ui" line="14"/>
        <source>Torrent Category Properties</source>
        <translation>Propriedades da categoria do torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.ui" line="55"/>
        <source>Name:</source>
        <translation>Nome:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.ui" line="64"/>
        <source>Save path for incomplete torrents:</source>
        <translation>Caminho do salvamento dos torrents incompletos:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.ui" line="72"/>
        <source>Use another path for incomplete torrents:</source>
        <translation>Usar outro caminho pros torrents incompletos:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.ui" line="83"/>
        <source>Default</source>
        <translation>Padrão</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.ui" line="88"/>
        <source>Yes</source>
        <translation>Sim</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.ui" line="93"/>
        <source>No</source>
        <translation>Não</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.ui" line="124"/>
        <source>Path:</source>
        <translation>Caminho:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.ui" line="48"/>
        <source>Save path:</source>
        <translation>Caminho do salvamento:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="45"/>
        <source>Choose save path</source>
        <translation>Escolha o caminho do salvamento</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="48"/>
        <source>Choose download path</source>
        <translation>Escolha o caminho do download</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="72"/>
        <source>New Category</source>
        <translation>Nova categoria</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="83"/>
        <source>Invalid category name</source>
        <translation>Nome inválido da categoria</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="84"/>
        <source>Category name cannot contain &apos;\&apos;.
Category name cannot start/end with &apos;/&apos;.
Category name cannot contain &apos;//&apos; sequence.</source>
        <translation>O nome da categoria não pode conter &apos;\&apos;.
O nome da categoria não pode iniciar/terminar com &apos;/&apos;.
O nome da categoria não pode conter a sequência &apos;//&apos;.</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="91"/>
        <source>Category creation error</source>
        <translation>Erro na criação da categoria</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="92"/>
        <source>Category with the given name already exists.
Please choose a different name and try again.</source>
        <translation>Uma categoria com o nome dado já existe.
Por favor escolha um nome diferente e tente de novo.</translation>
    </message>
</context>
<context>
    <name>TorrentContentModel</name>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="194"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="vanished">Tamanho</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="194"/>
        <source>Progress</source>
        <translation>Progresso</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="194"/>
        <source>Download Priority</source>
        <translation>Prioridade do download</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="194"/>
        <source>Remaining</source>
        <translation>Restante</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="194"/>
        <source>Availability</source>
        <translation>Disponibilidade</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="194"/>
        <source>Total Size</source>
        <translation type="unfinished">Tamanho total</translation>
    </message>
</context>
<context>
    <name>TorrentContentModelItem</name>
    <message>
        <location filename="../gui/torrentcontentmodelitem.cpp" line="118"/>
        <source>Mixed</source>
        <comment>Mixed (priorities</comment>
        <translation>Misto</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodelitem.cpp" line="120"/>
        <source>Not downloaded</source>
        <translation>Não baixado</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodelitem.cpp" line="122"/>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation>Alta</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodelitem.cpp" line="124"/>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation>Máxima</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodelitem.cpp" line="126"/>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodelitem.cpp" line="140"/>
        <source>N/A</source>
        <translation>N/D</translation>
    </message>
</context>
<context>
    <name>TorrentContentTreeView</name>
    <message>
        <location filename="../gui/torrentcontenttreeview.cpp" line="118"/>
        <source>Renaming</source>
        <translation>Renomeando</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontenttreeview.cpp" line="118"/>
        <source>New name:</source>
        <translation>Novo nome:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontenttreeview.cpp" line="141"/>
        <source>Rename error</source>
        <translation>Erro ao renomear</translation>
    </message>
</context>
<context>
    <name>TorrentCreatorDialog</name>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="17"/>
        <source>Torrent Creator</source>
        <translation>Criador de torrents</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="56"/>
        <source>Select file/folder to share</source>
        <translation>Selecione o arquivo/pasta a compartilhar</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="64"/>
        <source>Path:</source>
        <translation>Caminho:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="91"/>
        <source>[Drag and drop area]</source>
        <translation>[Área pra arrastar e soltar]</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="101"/>
        <location filename="../gui/torrentcreatordialog.cpp" line="120"/>
        <source>Select file</source>
        <translation>Selecione o arquivo</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="108"/>
        <location filename="../gui/torrentcreatordialog.cpp" line="113"/>
        <source>Select folder</source>
        <translation>Selecione a pasta</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="120"/>
        <source>Settings</source>
        <translation>Configurações</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="141"/>
        <source>Torrent format:</source>
        <translation>Formato do torrent:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="154"/>
        <source>Hybrid</source>
        <translation>Híbrido</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="185"/>
        <source>Piece size:</source>
        <translation>Tamanho do pedaço:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="199"/>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="204"/>
        <source>16 KiB</source>
        <translation>16 KBs</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="209"/>
        <source>32 KiB</source>
        <translation>32 KBs</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="214"/>
        <source>64 KiB</source>
        <translation>64 KBs</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="219"/>
        <source>128 KiB</source>
        <translation>128 KBs</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="224"/>
        <source>256 KiB</source>
        <translation>256 KBs</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="229"/>
        <source>512 KiB</source>
        <translation>512 KBs</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="234"/>
        <source>1 MiB</source>
        <translation>1 MBs</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="239"/>
        <source>2 MiB</source>
        <translation>2 MBs</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="244"/>
        <source>4 MiB</source>
        <translation>4 MBs</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="249"/>
        <source>8 MiB</source>
        <translation>8 MBs</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="254"/>
        <source>16 MiB</source>
        <translation>16 MBs</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="259"/>
        <source>32 MiB</source>
        <translation>32 MBs</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="267"/>
        <source>Calculate number of pieces:</source>
        <translation>Calcular número de pedaços:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="296"/>
        <source>Private torrent (Won&apos;t distribute on DHT network)</source>
        <translation>Torrent privado (não distribuirá na rede DHT)</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="303"/>
        <source>Start seeding immediately</source>
        <translation>Iniciar o seeding imediatamente</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="313"/>
        <source>Ignore share ratio limits for this torrent</source>
        <translation>Ignorar os limites da proporção de compartilhamento pra este torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="320"/>
        <source>Optimize alignment</source>
        <translation>Otimizar alinhamento</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="331"/>
        <source>Align to piece boundary for files larger than:</source>
        <translation>Alinhar ao limite dos pedaços pra arquivos maiores do que:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="338"/>
        <source>Disabled</source>
        <translation>Desativado</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="341"/>
        <source> KiB</source>
        <translation> KBs</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="378"/>
        <source>Fields</source>
        <translation>Campos</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="384"/>
        <source>You can separate tracker tiers / groups with an empty line.</source>
        <translation>Você pode separar camadas / grupos de trackers com uma linha vazia.</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="394"/>
        <source>Web seed URLs:</source>
        <translation>URLs do seed da web:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="415"/>
        <source>Tracker URLs:</source>
        <translation>URLs do tracker:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="422"/>
        <source>Comments:</source>
        <translation>Comentários:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="429"/>
        <source>Source:</source>
        <translation>Fonte:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="448"/>
        <source>Progress:</source>
        <translation>Progresso:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="73"/>
        <source>Create Torrent</source>
        <translation>Criar Torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="182"/>
        <location filename="../gui/torrentcreatordialog.cpp" line="227"/>
        <location filename="../gui/torrentcreatordialog.cpp" line="241"/>
        <source>Torrent creation failed</source>
        <translation>Falhou na criação do torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="182"/>
        <source>Reason: Path to file/folder is not readable.</source>
        <translation>Motivo: O caminho para o arquivo/pasta não é legível.</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="188"/>
        <source>Select where to save the new torrent</source>
        <translation>Selecione aonde salvar o novo torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="188"/>
        <source>Torrent Files (*.torrent)</source>
        <translation>Arquivos Torrent (*.torrent)</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="227"/>
        <source>Reason: %1</source>
        <translation>Motivo: %1</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="241"/>
        <source>Reason: Created torrent is invalid. It won&apos;t be added to download list.</source>
        <translation>Motivo: O torrent criado é inválido. Ele não será adicionado a lista de downloads.</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="257"/>
        <source>Torrent creator</source>
        <translation>Criador de torrents</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="258"/>
        <source>Torrent created:</source>
        <translation>Torrent criado:</translation>
    </message>
</context>
<context>
    <name>TorrentFilesWatcher</name>
    <message>
        <location filename="../base/torrentfileswatcher.cpp" line="288"/>
        <source>Couldn&apos;t load Watched Folders configuration from %1. Error: %2</source>
        <translation>Não pôde carregar a configuração das Pastas Observadas de %1. Erro: %2</translation>
    </message>
    <message>
        <location filename="../base/torrentfileswatcher.cpp" line="297"/>
        <source>Couldn&apos;t parse Watched Folders configuration from %1. Error: %2</source>
        <translation>Não pôde analisar a configuração das Pastas Observadas de %1. Erro: %2</translation>
    </message>
    <message>
        <location filename="../base/torrentfileswatcher.cpp" line="304"/>
        <source>Couldn&apos;t load Watched Folders configuration from %1. Invalid data format.</source>
        <translation>Não pôde carregar a configuração das Pastas Observadas de %1. Formato dos dados inválido.</translation>
    </message>
    <message>
        <location filename="../base/torrentfileswatcher.cpp" line="377"/>
        <source>Couldn&apos;t store Watched Folders configuration to %1. Error: %2</source>
        <translation>Não pôde armazenar a configuração das Pastas Observadas em %1. Erro: %2</translation>
    </message>
    <message>
        <location filename="../base/torrentfileswatcher.cpp" line="396"/>
        <source>Watched folder Path cannot be empty.</source>
        <translation>O caminho da pasta observada não pode estar vazio.</translation>
    </message>
    <message>
        <location filename="../base/torrentfileswatcher.cpp" line="399"/>
        <source>Watched folder Path cannot be relative.</source>
        <translation>O caminho da pasta observada não pode ser relativo.</translation>
    </message>
</context>
<context>
    <name>TorrentFilesWatcher::Worker</name>
    <message>
        <location filename="../base/torrentfileswatcher.cpp" line="534"/>
        <source>Failed to open magnet file: %1</source>
        <translation>Falhou em abrir o arquivo magnet: %1</translation>
    </message>
    <message>
        <location filename="../base/torrentfileswatcher.cpp" line="606"/>
        <source>Rejecting failed torrent file: %1</source>
        <translation>Rejeitando arquivo do torrent que falhou: %1</translation>
    </message>
    <message>
        <location filename="../base/torrentfileswatcher.cpp" line="645"/>
        <source>Watching folder: &quot;%1&quot;</source>
        <translation>Pasta de observação: &quot;%1&quot;</translation>
    </message>
</context>
<context>
    <name>TorrentInfo</name>
    <message>
        <location filename="../base/bittorrent/torrentinfo.cpp" line="116"/>
        <source>File size exceeds max limit %1</source>
        <translation>O tamanho do arquivo excede o limite máximo de %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentinfo.cpp" line="125"/>
        <source>Torrent file read error: %1</source>
        <translation>Erro de leitura do arquivo torrent: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentinfo.cpp" line="129"/>
        <source>Torrent file read error: size mismatch</source>
        <translation>Erro de leitura do arquivo torrent: o tamanho não combina</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentinfo.cpp" line="139"/>
        <source>Invalid metadata</source>
        <translation>Metadados inválidos</translation>
    </message>
</context>
<context>
    <name>TorrentOptionsDialog</name>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="14"/>
        <source>Torrent Options</source>
        <translation>Opções do torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="20"/>
        <source>Automatic mode means that various torrent properties (e.g. save path) will be decided by the associated category</source>
        <translation>O modo automático significa que várias propriedades do torrent (ex: caminho do salvamento) serão decididas pela categoria associada</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="23"/>
        <source>Automatic Torrent Management</source>
        <translation>Gerenciamento Automático dos Torrents</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="30"/>
        <source>Save at</source>
        <translation>Salvar em</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="39"/>
        <source>Use another path for incomplete torrent</source>
        <translation>Usar outro caminho pro torrent incompleto</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="77"/>
        <source>Category:</source>
        <translation>Categoria:</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="86"/>
        <source>Torrent speed limits</source>
        <translation>Limites da velocidade do torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="92"/>
        <source>Download:</source>
        <translation>Download:</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="99"/>
        <location filename="../gui/torrentoptionsdialog.ui" line="112"/>
        <source>∞</source>
        <translation>∞</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="102"/>
        <location filename="../gui/torrentoptionsdialog.ui" line="115"/>
        <source> KiB/s</source>
        <translation> KB/s</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="125"/>
        <source>These will not exceed the global limits</source>
        <translation>Estes não excederão os limites globais</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="132"/>
        <source>Upload:</source>
        <translation>Upload:</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="156"/>
        <source>Torrent share limits</source>
        <translation>Limites de compartilhamento do torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="162"/>
        <source>Use global share limit</source>
        <translation>Usar limite global de compartilhamento</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="172"/>
        <source>Set no share limit</source>
        <translation>Definir nenhum limite de compartilhamento</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="184"/>
        <source>Set share limit to</source>
        <translation>Definir limite de compartilhamento pra</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="194"/>
        <source>minutes</source>
        <translation>minutos</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="237"/>
        <source>ratio</source>
        <translation>proporção</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="251"/>
        <source>Disable DHT for this torrent</source>
        <translation>Desativar DHT pra este torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="258"/>
        <source>Download in sequential order</source>
        <translation>Baixar em ordem sequencial</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="278"/>
        <source>Disable PeX for this torrent</source>
        <translation>Desativar PeX pra este torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="285"/>
        <source>Download first and last pieces first</source>
        <translation>Baixar os primeiros e os últimos pedaços primeiro</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.ui" line="292"/>
        <source>Disable LSD for this torrent</source>
        <translation>Desativar LSD pra este torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.cpp" line="66"/>
        <source>Currently used categories</source>
        <translation>Categorias usadas atualmente</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.cpp" line="73"/>
        <location filename="../gui/torrentoptionsdialog.cpp" line="75"/>
        <source>Choose save path</source>
        <translation>Escolha o caminho do salvamento</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.cpp" line="338"/>
        <source>Not applicable to private torrents</source>
        <translation>Não aplicável a torrents privados</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.cpp" line="406"/>
        <source>No share limit method selected</source>
        <translation>Nenhum método de limite de compartilhamento selecionado</translation>
    </message>
    <message>
        <location filename="../gui/torrentoptionsdialog.cpp" line="406"/>
        <source>Please select a limit method first</source>
        <translation>Por favor selecione um método limite primeiro</translation>
    </message>
</context>
<context>
    <name>TorrentsController</name>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="726"/>
        <source>Error: &apos;%1&apos; is not a valid torrent file.</source>
        <translation>Erro: &apos;%1&apos; não é um arquivo torrent válido.</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="889"/>
        <source>Priority must be an integer</source>
        <translation>A prioridade deve ser um inteiro</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="892"/>
        <source>Priority is not valid</source>
        <translation>A prioridade não é válida</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="898"/>
        <source>Torrent&apos;s metadata has not yet downloaded</source>
        <translation>Os metadados do torrent ainda não foram baixados</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="907"/>
        <source>File IDs must be integers</source>
        <translation>As IDs dos arquivos devem ser inteiras</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="909"/>
        <source>File ID is not valid</source>
        <translation>A ID do arquivo não é válida</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1052"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="1063"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="1074"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="1085"/>
        <source>Torrent queueing must be enabled</source>
        <translation>Os torrents na fila devem estar ativados</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1099"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="1126"/>
        <source>Save path cannot be empty</source>
        <translation>O caminho do salvamento não pode estar vazio</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1130"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="1154"/>
        <source>Cannot create target directory</source>
        <translation>Não pôde criar a pasta de destino</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1235"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="1260"/>
        <source>Category cannot be empty</source>
        <translation>A categoria não pode estar vazia</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1251"/>
        <source>Unable to create category</source>
        <translation>Incapaz de criar a categoria</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1273"/>
        <source>Unable to edit category</source>
        <translation>Incapaz de editar a categoria</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1103"/>
        <source>Cannot make save path</source>
        <translation>Não pôde criar o caminho do salvamento</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="300"/>
        <source>&apos;sort&apos; parameter is invalid</source>
        <translation>O parâmetro &apos;sort&apos; é inválido</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="551"/>
        <source>&quot;%1&quot; is not a valid file index.</source>
        <translation>&quot;%1&quot; não é um arquivo de índice válido.</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="553"/>
        <source>Index %1 is out of bounds.</source>
        <translation>O índice %1 está fora dos limites.</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1107"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="1134"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="1158"/>
        <source>Cannot write to directory</source>
        <translation>Não pôde gravar no diretório</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1111"/>
        <source>WebUI Set location: moving &quot;%1&quot;, from &quot;%2&quot; to &quot;%3&quot;</source>
        <translation>Definir local da interface de usuário da web: movendo &quot;%1&quot;, de &quot;%2&quot; pra &quot;%3&quot;</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1176"/>
        <source>Incorrect torrent name</source>
        <translation>Nome incorreto do torrent</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1225"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="1238"/>
        <source>Incorrect category name</source>
        <translation>Nome incorreto da categoria</translation>
    </message>
</context>
<context>
    <name>TrackerEntriesDialog</name>
    <message>
        <location filename="../gui/trackerentriesdialog.ui" line="14"/>
        <source>Edit trackers</source>
        <translation>Editar trackers</translation>
    </message>
    <message>
        <location filename="../gui/trackerentriesdialog.ui" line="20"/>
        <source>One tracker URL per line.

- You can split the trackers into groups by inserting blank lines.
- All trackers within the same group will belong to the same tier.
- The group on top will be tier 0, the next group tier 1 and so on.
- Below will show the common subset of trackers of the selected torrents.</source>
        <translation>Uma URL de tracker por linha.

- Você pode dividir os trackers em grupos inserindo linhas em branco.
- Todos os trackers do mesmo grupo pertencerão ao mesmo nível.
- O grupo no topo será nível 0, o próximo grupo será nível 1 e assim por diante.
- Abaixo mostrará o sub-conjunto comum de trackers dos torrents selecionados.</translation>
    </message>
</context>
<context>
    <name>TrackerFiltersList</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="368"/>
        <source>All (0)</source>
        <comment>this is for the tracker filter</comment>
        <translation>Todos (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="371"/>
        <source>Trackerless (0)</source>
        <translation>Sem tracker (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="374"/>
        <source>Error (0)</source>
        <translation>Erro (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="377"/>
        <source>Warning (0)</source>
        <translation>Aviso (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="422"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="511"/>
        <source>Trackerless (%1)</source>
        <translation>Sem tracker (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="473"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="600"/>
        <source>Error (%1)</source>
        <translation>Erro (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="487"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="601"/>
        <source>Warning (%1)</source>
        <translation>Aviso (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="659"/>
        <source>Resume torrents</source>
        <translation>Resumir torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="661"/>
        <source>Pause torrents</source>
        <translation>Pausar torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="663"/>
        <source>Delete torrents</source>
        <translation>Apagar torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="688"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="702"/>
        <source>All (%1)</source>
        <comment>this is for the tracker filter</comment>
        <translation>Todos (%1)</translation>
    </message>
</context>
<context>
    <name>TrackerListWidget</name>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="276"/>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="385"/>
        <source>Working</source>
        <translation>Funcionando</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="277"/>
        <source>Disabled</source>
        <translation>Desativado</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="278"/>
        <source>Disabled for this torrent</source>
        <translation>Desativado pra este torrent</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="307"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="182"/>
        <source>This torrent is private</source>
        <translation>Este torrent é privado</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="388"/>
        <source>Updating...</source>
        <translation>Atualizando...</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="391"/>
        <source>Not working</source>
        <translation>Não funciona</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="394"/>
        <source>Not contacted yet</source>
        <translation>Não contactado ainda</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="402"/>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="405"/>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="408"/>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="411"/>
        <source>N/A</source>
        <translation>N/D</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="505"/>
        <source>Tracker editing</source>
        <translation>Editando o tracker</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="505"/>
        <source>Tracker URL:</source>
        <translation>URL do tracker:</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="511"/>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="522"/>
        <source>Tracker editing failed</source>
        <translation>Falhou em editar o tracker</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="511"/>
        <source>The tracker URL entered is invalid.</source>
        <translation>A URL inserida do tracker é inválida.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="522"/>
        <source>The tracker URL already exists.</source>
        <translation>A URL do tracker já existe.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="581"/>
        <source>Add a new tracker...</source>
        <translation>Adicionar um novo tracker...</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="586"/>
        <source>Edit tracker URL...</source>
        <translation>Editar URL do tracker...</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="588"/>
        <source>Remove tracker</source>
        <translation>Remover tracker</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="590"/>
        <source>Copy tracker URL</source>
        <translation>Copiar URL do tracker</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="596"/>
        <source>Force reannounce to selected trackers</source>
        <translation>Forçar re-anúncio para os trackers selecionados</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="599"/>
        <source>Force reannounce to all trackers</source>
        <translation>Forçar re-anúncio para todos os trackers</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="625"/>
        <source>Tier</source>
        <translation>Camada</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="626"/>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="627"/>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="629"/>
        <source>Seeds</source>
        <translation>Seeds</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="674"/>
        <source>Resize columns</source>
        <translation>Redimensionar colunas</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="683"/>
        <source>Resize all non-hidden columns to the size of their contents</source>
        <translation>Redimensionar todas as colunas não ocultas para o tamanho do conteúdo delas</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="628"/>
        <source>Peers</source>
        <translation>Peers</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="630"/>
        <source>Leeches</source>
        <translation>Leeches</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="631"/>
        <source>Downloaded</source>
        <translation>Baixados</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="632"/>
        <source>Message</source>
        <translation>Mensagem</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="652"/>
        <source>Column visibility</source>
        <translation>Visibilidade da coluna</translation>
    </message>
</context>
<context>
    <name>TrackersAdditionDialog</name>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.ui" line="14"/>
        <source>Trackers addition dialog</source>
        <translation>Diálogo de adição dos trackers</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.ui" line="20"/>
        <source>List of trackers to add (one per line):</source>
        <translation>Lista de trackers pra adicionar (um por linha):</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.ui" line="37"/>
        <source>µTorrent compatible list URL:</source>
        <translation>URL da lista compatível com µTorrent:</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.cpp" line="129"/>
        <source>No change</source>
        <translation>Nenhuma mudança</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.cpp" line="129"/>
        <source>No additional trackers were found.</source>
        <translation>Não foram achados trackers adicionais.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.cpp" line="88"/>
        <source>Download error</source>
        <translation>Erro do download</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.cpp" line="89"/>
        <source>The trackers list could not be downloaded, reason: %1</source>
        <translation>A lista de trackers não pôde ser baixada, motivo: %1</translation>
    </message>
</context>
<context>
    <name>TransferListFiltersWidget</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="771"/>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="779"/>
        <source>Categories</source>
        <translation>Categorias</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="798"/>
        <source>Tags</source>
        <translation>Etiquetas</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="816"/>
        <source>Trackers</source>
        <translation>Trackers</translation>
    </message>
</context>
<context>
    <name>TransferListModel</name>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="112"/>
        <source>Downloading</source>
        <translation>Baixando</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="113"/>
        <source>Stalled</source>
        <comment>Torrent is waiting for download to begin</comment>
        <translation>Parado</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="114"/>
        <source>Downloading metadata</source>
        <comment>Used when loading a magnet link</comment>
        <translation>Baixando metadados</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="115"/>
        <source>[F] Downloading metadata</source>
        <comment>Used when forced to load a magnet link. You probably shouldn&apos;t translate the F.</comment>
        <translation>[F] Baixando metadados</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="116"/>
        <source>[F] Downloading</source>
        <comment>Used when the torrent is forced started. You probably shouldn&apos;t translate the F.</comment>
        <translation>[F] Baixando</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="117"/>
        <location filename="../gui/transferlistmodel.cpp" line="118"/>
        <source>Seeding</source>
        <comment>Torrent is complete and in upload-only mode</comment>
        <translation>Seeding</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="119"/>
        <source>[F] Seeding</source>
        <comment>Used when the torrent is forced started. You probably shouldn&apos;t translate the F.</comment>
        <translation>[F] Seeding</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="120"/>
        <location filename="../gui/transferlistmodel.cpp" line="121"/>
        <source>Queued</source>
        <comment>Torrent is queued</comment>
        <translation>Na fila</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="122"/>
        <location filename="../gui/transferlistmodel.cpp" line="123"/>
        <source>Checking</source>
        <comment>Torrent local data is being checked</comment>
        <translation>Verificando</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="124"/>
        <source>Checking resume data</source>
        <comment>Used when loading the torrents from disk after qbt is launched. It checks the correctness of the .fastresume file. Normally it is completed in a fraction of a second, unless loading many many torrents.</comment>
        <translation>Verificando os dados do resumo</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="125"/>
        <source>Paused</source>
        <translation>Pausado</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="126"/>
        <source>Completed</source>
        <translation>Completado</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="127"/>
        <source>Moving</source>
        <comment>Torrent local data are being moved/relocated</comment>
        <translation>Movendo</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="128"/>
        <source>Missing Files</source>
        <translation>Arquivos ausentes</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="129"/>
        <source>Errored</source>
        <comment>Torrent status, the torrent has an error</comment>
        <translation>Com erro</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="172"/>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="173"/>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation>Tamanho</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="174"/>
        <source>Progress</source>
        <comment>% Done</comment>
        <translation>Progresso</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="175"/>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation>Status</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="176"/>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation>Seeds</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="177"/>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation>Peers</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="178"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Velocidade de download</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="179"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Velocidade de upload</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="180"/>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation>Proporção</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="181"/>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation>Tempo restante</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="182"/>
        <source>Category</source>
        <translation>Categoria</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="183"/>
        <source>Tags</source>
        <translation>Etiquetas</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="184"/>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation>Adicionado em</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="185"/>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation>Completado em</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="186"/>
        <source>Tracker</source>
        <translation>Tracker</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="187"/>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation>Limite de download</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="188"/>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation>Limite de upload</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="189"/>
        <source>Downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation>Baixados</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="190"/>
        <source>Uploaded</source>
        <comment>Amount of data uploaded (e.g. in MB)</comment>
        <translation>Enviados</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="191"/>
        <source>Session Download</source>
        <comment>Amount of data downloaded since program open (e.g. in MB)</comment>
        <translation>Download da sessão</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="192"/>
        <source>Session Upload</source>
        <comment>Amount of data uploaded since program open (e.g. in MB)</comment>
        <translation>Upload da sessão</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="193"/>
        <source>Remaining</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation>Restante</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="194"/>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation>Tempo ativo</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="195"/>
        <source>Save path</source>
        <comment>Torrent save path</comment>
        <translation>Caminho do salvamento</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="196"/>
        <source>Completed</source>
        <comment>Amount of data completed (e.g. in MB)</comment>
        <translation>Completado</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="197"/>
        <source>Ratio Limit</source>
        <comment>Upload share ratio limit</comment>
        <translation>Limite da proporção</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="198"/>
        <source>Last Seen Complete</source>
        <comment>Indicates the time when the torrent was last seen complete/whole</comment>
        <translation>Visto completo pela última vez</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="199"/>
        <source>Last Activity</source>
        <comment>Time passed since a chunk was downloaded/uploaded</comment>
        <translation>Última atividade</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="200"/>
        <source>Total Size</source>
        <comment>i.e. Size including unwanted data</comment>
        <translation>Tamanho total</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="201"/>
        <source>Availability</source>
        <comment>The number of distributed copies of the torrent</comment>
        <translation>Disponibilidade</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="253"/>
        <source>N/A</source>
        <translation>N/D</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="310"/>
        <source>%1 ago</source>
        <comment>e.g.: 1h 20m ago</comment>
        <translation>%1 atrás</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="323"/>
        <source>%1 (seeded for %2)</source>
        <comment>e.g. 4m39s (seeded for 3m10s)</comment>
        <translation>%1 (semeado por %2)</translation>
    </message>
</context>
<context>
    <name>TransferListWidget</name>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="637"/>
        <source>Column visibility</source>
        <translation>Visibilidade da coluna</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="606"/>
        <source>Recheck confirmation</source>
        <translation>Confirmação da nova verificação</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="606"/>
        <source>Are you sure you want to recheck the selected torrent(s)?</source>
        <translation>Você tem certeza que você quer verificar de novo o(s) torrent(s) selecionado(s)?</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="818"/>
        <source>Rename</source>
        <translation>Renomear</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="818"/>
        <source>New name:</source>
        <translation>Novo nome:</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="859"/>
        <source>Resume</source>
        <comment>Resume/start the torrent</comment>
        <translation>Resumir</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="863"/>
        <source>Force Resume</source>
        <comment>Force Resume/start the torrent</comment>
        <translation>Forçar o resumo</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="861"/>
        <source>Pause</source>
        <comment>Pause the torrent</comment>
        <translation>Pausar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="333"/>
        <source>Choose save path</source>
        <translation>Escolha o caminho do salvamento</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="586"/>
        <source>Unable to preview</source>
        <translation>Incapaz de pré-visualizar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="586"/>
        <source>The selected torrent &quot;%1&quot; does not contain previewable files</source>
        <translation>O torrent selecionado &quot;%1&quot; não contém arquivos pré-visualizáveis</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="663"/>
        <source>Resize columns</source>
        <translation>Redimensionar colunas</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="672"/>
        <source>Resize all non-hidden columns to the size of their contents</source>
        <translation>Redimensionar todas as colunas não ocultas para o tamanho do conteúdo delas</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="702"/>
        <source>Enable automatic torrent management</source>
        <translation>Ativar gerenciamento automático dos torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="703"/>
        <source>Are you sure you want to enable Automatic Torrent Management for the selected torrent(s)? They may be relocated.</source>
        <translation>Você tem certeza que você quer ativar o gerenciamento automático dos torrents para os torrents selecionados? Eles podem ser realocados.</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="721"/>
        <source>Add Tags</source>
        <translation>Adicionar etiquetas</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="764"/>
        <source>Remove All Tags</source>
        <translation>Remover todas as etiquetas</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="764"/>
        <source>Remove all tags from selected torrents?</source>
        <translation>Remover todas as etiquetas dos torrents selecionados?</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="779"/>
        <source>Comma-separated tags:</source>
        <translation>Etiquetas separadas por vírgulas:</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="788"/>
        <source>Invalid tag</source>
        <translation>Etiqueta inválida</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="789"/>
        <source>Tag name: &apos;%1&apos; is invalid</source>
        <translation>O nome da etiqueta &apos;%1&apos; é inválido</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="865"/>
        <source>Delete</source>
        <comment>Delete the torrent</comment>
        <translation>Apagar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="867"/>
        <source>Preview file...</source>
        <translation>Arquivo da pré-visualização...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="871"/>
        <source>Open destination folder</source>
        <translation>Abrir pasta de destino</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="873"/>
        <source>Move up</source>
        <comment>i.e. move up in the queue</comment>
        <translation>Mover pra cima</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="875"/>
        <source>Move down</source>
        <comment>i.e. Move down in the queue</comment>
        <translation>Mover pra baixo</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="877"/>
        <source>Move to top</source>
        <comment>i.e. Move to top of the queue</comment>
        <translation>Mover pro topo</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="879"/>
        <source>Move to bottom</source>
        <comment>i.e. Move to bottom of the queue</comment>
        <translation>Mover pro rodapé</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="881"/>
        <source>Set location...</source>
        <translation>Definir local...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="885"/>
        <source>Force reannounce</source>
        <translation>Forçar re-anúncio</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="887"/>
        <source>Magnet link</source>
        <translation>Link magnet</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="889"/>
        <source>Torrent ID</source>
        <translation>ID do torrent</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="891"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="901"/>
        <source>Download in sequential order</source>
        <translation>Baixar em ordem sequencial</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="903"/>
        <source>Download first and last pieces first</source>
        <translation>Baixar os primeiros e os últimos pedaços primeiro</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="905"/>
        <source>Automatic Torrent Management</source>
        <translation>Gerenciamento automático dos torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="906"/>
        <source>Automatic mode means that various torrent properties (e.g. save path) will be decided by the associated category</source>
        <translation>O modo automático significa que várias propriedades do torrent (ex: caminho do salvamento) serão decididas pela categoria associada</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1048"/>
        <source>Category</source>
        <translation>Categoria</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1050"/>
        <source>New...</source>
        <comment>New category...</comment>
        <translation>Nova...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1052"/>
        <source>Reset</source>
        <comment>Reset category</comment>
        <translation>Resetar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1152"/>
        <source>Can not force reannounce if torrent is Paused/Queued/Errored/Checking</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1158"/>
        <source>Queue</source>
        <translation>Fila</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1166"/>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="869"/>
        <source>Torrent options...</source>
        <translation>Opções do torrent...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="893"/>
        <source>Info hash v1</source>
        <translation>Informações do hash v1</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="895"/>
        <source>Info hash v2</source>
        <translation>Informações do hash v2</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="908"/>
        <source>Edit trackers...</source>
        <translation>Editar trackers...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1073"/>
        <source>Tags</source>
        <translation>Etiquetas</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1075"/>
        <source>Add...</source>
        <comment>Add / assign multiple tags...</comment>
        <translation>Adicionar...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1077"/>
        <source>Remove All</source>
        <comment>Remove all tags</comment>
        <translation>Remover tudo</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="883"/>
        <source>Force recheck</source>
        <translation>Forçar nova verificação</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="897"/>
        <source>Super seeding mode</source>
        <translation>Modo super seeding</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="899"/>
        <source>Rename...</source>
        <translation>Renomear...</translation>
    </message>
</context>
<context>
    <name>UIThemeManager</name>
    <message>
        <location filename="../gui/uithememanager.cpp" line="181"/>
        <source>Failed to load UI theme from file: &quot;%1&quot;</source>
        <translation>Falhou em carregar o tema da interface de usuário do arquivo: &quot;%1&quot;</translation>
    </message>
    <message>
        <location filename="../gui/uithememanager.cpp" line="77"/>
        <source>UITheme - Failed to open &quot;%1&quot;. Reason: %2</source>
        <translation>UITheme - Falhou em abrir o &quot;%1&quot;. Motivo: %2</translation>
    </message>
    <message>
        <location filename="../gui/uithememanager.cpp" line="324"/>
        <location filename="../gui/uithememanager.cpp" line="329"/>
        <source>&quot;%1&quot; has invalid format. Reason: %2</source>
        <translation>&quot;%1&quot; tem formato inválido. Motivo: %2</translation>
    </message>
    <message>
        <location filename="../gui/uithememanager.cpp" line="329"/>
        <source>Root JSON value is not an object</source>
        <translation>O Valor do JSON raiz não é um objeto</translation>
    </message>
    <message>
        <location filename="../gui/uithememanager.cpp" line="339"/>
        <source>Invalid color for ID &quot;%1&quot; is provided by theme</source>
        <translation>Cor inválida para a ID &quot;%1&quot; é fornecida pelo tema</translation>
    </message>
</context>
<context>
    <name>Utils::ForeignApps</name>
    <message>
        <location filename="../base/utils/foreignapps.cpp" line="85"/>
        <source>Python detected, executable name: &apos;%1&apos;, version: %2</source>
        <translation>Python detectado, nome do executável: &quot;%1&quot;, versão: %2</translation>
    </message>
    <message>
        <location filename="../base/utils/foreignapps.cpp" line="289"/>
        <source>Python not detected</source>
        <translation>Python não detectado</translation>
    </message>
</context>
<context>
    <name>WatchedFolderOptionsDialog</name>
    <message>
        <location filename="../gui/watchedfolderoptionsdialog.ui" line="14"/>
        <source>Watched Folder Options</source>
        <translation>Opções da pasta observada</translation>
    </message>
    <message>
        <location filename="../gui/watchedfolderoptionsdialog.ui" line="22"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Will watch the folder and all its subfolders. In Manual torrent management mode it will also add subfolder name to the selected Save path.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Observará a pasta e todas as suas sub-pastas. No modo de gerenciamento manual dos torrents ele também adicionará o nome da sub-pasta ao caminho do salvamento selecionado.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/watchedfolderoptionsdialog.ui" line="25"/>
        <source>Recursive mode</source>
        <translation>Modo recursivo</translation>
    </message>
    <message>
        <location filename="../gui/watchedfolderoptionsdialog.ui" line="69"/>
        <source>Torrent parameters</source>
        <translation>Parâmetros do torrent</translation>
    </message>
    <message>
        <location filename="../gui/watchedfolderoptionsdialog.ui" line="77"/>
        <source>Torrent Management Mode:</source>
        <translation>Modo de Gerenciamento dos Torrents:</translation>
    </message>
    <message>
        <location filename="../gui/watchedfolderoptionsdialog.ui" line="84"/>
        <source>Automatic mode means that various torrent properties(eg save path) will be decided by the associated category</source>
        <translation>O modo automático significa que várias propriedades do torrent (ex: caminho do salvamento) serão decididos pela categoria associada</translation>
    </message>
    <message>
        <location filename="../gui/watchedfolderoptionsdialog.ui" line="88"/>
        <source>Manual</source>
        <translation>Manual</translation>
    </message>
    <message>
        <location filename="../gui/watchedfolderoptionsdialog.ui" line="93"/>
        <source>Automatic</source>
        <translation>Automático</translation>
    </message>
    <message>
        <location filename="../gui/watchedfolderoptionsdialog.ui" line="116"/>
        <source>Save at</source>
        <translation>Salvar em</translation>
    </message>
    <message>
        <location filename="../gui/watchedfolderoptionsdialog.ui" line="125"/>
        <source>Use another path for incomplete torrents</source>
        <translation>Usar outro caminho pros torrents incompletos</translation>
    </message>
    <message>
        <location filename="../gui/watchedfolderoptionsdialog.ui" line="148"/>
        <source>Category:</source>
        <translation>Categoria:</translation>
    </message>
    <message>
        <location filename="../gui/watchedfolderoptionsdialog.ui" line="188"/>
        <source>Start torrent</source>
        <translation>Iniciar torrent</translation>
    </message>
    <message>
        <location filename="../gui/watchedfolderoptionsdialog.ui" line="212"/>
        <source>Skip hash check</source>
        <translation>Ignorar a verificação do hash</translation>
    </message>
    <message>
        <location filename="../gui/watchedfolderoptionsdialog.ui" line="236"/>
        <source>Content layout:</source>
        <translation>Layout do conteúdo:</translation>
    </message>
    <message>
        <location filename="../gui/watchedfolderoptionsdialog.ui" line="247"/>
        <source>Original</source>
        <translation>Original</translation>
    </message>
    <message>
        <location filename="../gui/watchedfolderoptionsdialog.ui" line="252"/>
        <source>Create subfolder</source>
        <translation>Criar sub-pasta</translation>
    </message>
    <message>
        <location filename="../gui/watchedfolderoptionsdialog.ui" line="257"/>
        <source>Don&apos;t create subfolder</source>
        <translation>Não criar sub-pasta</translation>
    </message>
    <message>
        <location filename="../gui/watchedfolderoptionsdialog.cpp" line="53"/>
        <location filename="../gui/watchedfolderoptionsdialog.cpp" line="58"/>
        <source>Choose save path</source>
        <translation>Escolher o caminho do salvameto</translation>
    </message>
</context>
<context>
    <name>WatchedFoldersModel</name>
    <message>
        <location filename="../gui/watchedfoldersmodel.cpp" line="77"/>
        <source>Watched Folder</source>
        <translation>Pasta Observada</translation>
    </message>
    <message>
        <location filename="../gui/watchedfoldersmodel.cpp" line="106"/>
        <source>Watched folder path cannot be empty.</source>
        <translation>O caminho da pasta observada não pode estar vazio.</translation>
    </message>
    <message>
        <location filename="../gui/watchedfoldersmodel.cpp" line="109"/>
        <source>Watched folder path cannot be relative.</source>
        <translation>O caminho da pasta observada não pode ser relativo.</translation>
    </message>
    <message>
        <location filename="../gui/watchedfoldersmodel.cpp" line="112"/>
        <source>Folder &apos;%1&apos; is already in watch list.</source>
        <translation>A pasta &apos;%1&apos; já está na lista de observação.</translation>
    </message>
    <message>
        <location filename="../gui/watchedfoldersmodel.cpp" line="116"/>
        <source>Folder &apos;%1&apos; doesn&apos;t exist.</source>
        <translation>A pasta &apos;%1&apos; não existe.</translation>
    </message>
    <message>
        <location filename="../gui/watchedfoldersmodel.cpp" line="118"/>
        <source>Folder &apos;%1&apos; isn&apos;t readable.</source>
        <translation>A pasta &apos;%1&apos; não é legível.</translation>
    </message>
</context>
<context>
    <name>WebApplication</name>
    <message>
        <location filename="../webui/webapplication.cpp" line="182"/>
        <source>Unacceptable file type, only regular file is allowed.</source>
        <translation>Tipo de arquivo inaceitável, só o arquivo regular é permitido.</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="191"/>
        <source>Symlinks inside alternative UI folder are forbidden.</source>
        <translation>Os links simbólicos dentro da pasta alternativa da interface do usuário são proibidos.</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="324"/>
        <source>Using built-in Web UI.</source>
        <translation>Usando a interface de usuário da web embutida.</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="326"/>
        <source>Using custom Web UI. Location: &quot;%1&quot;.</source>
        <translation>Usando a interface personalizada de usuário da web. Local: &quot;%1&quot;.</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="338"/>
        <source>Web UI translation for selected locale (%1) has been successfully loaded.</source>
        <translation>A tradução da interface de usuário da web pro idioma selecionado (%1) foi carregada com sucesso.</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="343"/>
        <source>Couldn&apos;t load Web UI translation for selected locale (%1).</source>
        <translation>Não pôde carregar a tradução da interface de usuário da web pro idioma selecionado (%1).</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="391"/>
        <source>Missing &apos;:&apos; separator in WebUI custom HTTP header: &quot;%1&quot;</source>
        <translation>Separador &apos;:&apos; ausente no cabeçalho HTTP personalizado da interface de usuário da web: &quot;%1&quot;</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="456"/>
        <source>Exceeded the maximum allowed file size (%1)!</source>
        <translation>Excedeu o tamanho máximo permitido do arquivo (%1)!</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="667"/>
        <source>WebUI: Origin header &amp; Target origin mismatch! Source IP: &apos;%1&apos;. Origin header: &apos;%2&apos;. Target origin: &apos;%3&apos;</source>
        <translation>WebUI: O cabeçalho de origem &amp; e a origem do alvo não combinam! IP de origem: &apos;%1&apos;. Cabeçalho de origem: &apos;%2&apos;. Origem do alvo: &apos;%3&apos;</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="677"/>
        <source>WebUI: Referer header &amp; Target origin mismatch! Source IP: &apos;%1&apos;. Referer header: &apos;%2&apos;. Target origin: &apos;%3&apos;</source>
        <translation>WebUI : O cabeçalho do referenciador &amp; e de origem do alvo não combinam! IP de origem: &apos;%1&apos;. Cabeçalho do referenciador: &apos;%2&apos;. Origem do alvo: &apos;%3&apos;</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="695"/>
        <source>WebUI: Invalid Host header, port mismatch. Request source IP: &apos;%1&apos;. Server port: &apos;%2&apos;. Received Host header: &apos;%3&apos;</source>
        <translation>WebUI: Cabeçalho do hospedeiro inválido, a porta não combina. IP de origem da requisição: &apos;%1&apos;. Porta do servidor &apos;%2&apos;. Cabeçalho recebido do hospedeiro: &apos;%3&apos;</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="716"/>
        <source>WebUI: Invalid Host header. Request source IP: &apos;%1&apos;. Received Host header: &apos;%2&apos;</source>
        <translation>WebUI: Cabeçalho inválido do hospedeiro. IP de origem da requisição: &apos;%1&apos;. Cabeçalho recebido do hospedeiro: &apos;%2&apos;</translation>
    </message>
</context>
<context>
    <name>WebUI</name>
    <message>
        <location filename="../webui/webui.cpp" line="104"/>
        <source>Web UI: HTTPS setup successful</source>
        <translation>WebUI: HTTPS configurado com sucesso</translation>
    </message>
    <message>
        <location filename="../webui/webui.cpp" line="106"/>
        <source>Web UI: HTTPS setup failed, fallback to HTTP</source>
        <translation>WebUI: falhou em configurar o HTTPS, revertendo pro HTTP</translation>
    </message>
    <message>
        <location filename="../webui/webui.cpp" line="120"/>
        <source>Web UI: Now listening on IP: %1, port: %2</source>
        <translation>WebUI: Escutando agora no IP: %1, porta: %2</translation>
    </message>
    <message>
        <location filename="../webui/webui.cpp" line="124"/>
        <source>Web UI: Unable to bind to IP: %1, port: %2. Reason: %3</source>
        <translation>WebUI: Incapaz de vincular ao IP: %1, porta: %2. Motivo: %3</translation>
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <location filename="../base/utils/misc.cpp" line="74"/>
        <source>B</source>
        <comment>bytes</comment>
        <translation>Bs</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="75"/>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation>KBs</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="76"/>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation>MBs</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="77"/>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation>GBs</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="78"/>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation>TBs</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="79"/>
        <source>PiB</source>
        <comment>pebibytes (1024 tebibytes)</comment>
        <translation>PBs</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="80"/>
        <source>EiB</source>
        <comment>exbibytes (1024 pebibytes)</comment>
        <translation>EBs</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="258"/>
        <source>/s</source>
        <comment>per second</comment>
        <translation>/s</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="375"/>
        <source>%1h %2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation>%1h %2m</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="382"/>
        <source>%1d %2h</source>
        <comment>e.g: 2days 10hours</comment>
        <translation>%1d %2h</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="387"/>
        <source>%1y %2d</source>
        <comment>e.g: 2years 10days</comment>
        <translation>%1a %2d</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="266"/>
        <source>Unknown</source>
        <comment>Unknown (size)</comment>
        <translation>Desconhecido</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="145"/>
        <source>qBittorrent will shutdown the computer now because all downloads are complete.</source>
        <translation>O qBIttorrent desligará o computador agora porque todos os downloads estão completos.</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="365"/>
        <source>&lt; 1m</source>
        <comment>&lt; 1 minute</comment>
        <translation>&lt; 1 minuto</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="369"/>
        <source>%1m</source>
        <comment>e.g: 10minutes</comment>
        <translation>%1m</translation>
    </message>
</context>
</TS>
